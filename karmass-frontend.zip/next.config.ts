import type { NextConfig } from "next";

const nextConfig: NextConfig = {
    experimental: {
        agentFeedback: true,
    },

    cacheComponents: true,
    partialPrefetching: true,

    images: {
        remotePatterns: [
            {
                protocol: "https",
                hostname: "res.cloudinary.com",
                pathname: "/**",
            },
        ],
    },

    turbopack: {
        rules: {
            "*.css": {
                loaders: ["@tailwindcss/turbopack"],
                as: "*.css",
            },
        },
    },
};

export default nextConfig;