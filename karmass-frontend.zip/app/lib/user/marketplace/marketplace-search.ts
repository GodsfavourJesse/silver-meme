import type { MarketplaceCondition, MarketplaceSearchParams } from "@/app/types/user/marketplace.types";
export { NIGERIAN_STATES } from "@/app/lib/constants/nigeria";

// CONSTANTS
export const PAGE_SIZE = 12;

export type SortOption = NonNullable<MarketplaceSearchParams["sort"]>;

export const SORT_OPTIONS: {
    label: string;
    value: SortOption;
}[] = [
    {
        label: "Newest first",
        value: "newest",
    },
    {
        label: "Price: low to high",
        value: "price_asc",
    },
    {
        label: "Price: high to low",
        value: "price_desc",
    },
    {
        label: "Most relevant",
        value: "relevance",
    },
];

export const CONDITION_OPTIONS = [
    "BRAND_NEW",
    "FOREIGN_USED",
    "NIGERIAN_USED",
] as const satisfies readonly MarketplaceCondition[];

export const FUEL_OPTIONS = [
    "PETROL",
    "DIESEL",
    "HYBRID",
    "PLUG_IN_HYBRID",
    "ELECTRIC",
    "CNG",
    "LPG",
];

export const TRANSMISSION_OPTIONS = [
    "AUTOMATIC",
    "MANUAL",
    "CVT",
    "DCT",
    "AMT",
];

export const BODY_STYLE_OPTIONS = [
    "SUV",
    "SEDAN",
    "HATCHBACK",
    "COUPE",
    "TRUCK",
    "VAN",
    "WAGON",
    "MPV",
    "PICKUP",
    "CONVERTIBLE",
    "BUS",
];

/*
 * ============================================================
 * FILTER STATE
 * ============================================================
 */

export type MarketplaceFilterState = {
    make: string;
    model: string;
    variant: string;

    minPrice: string;
    maxPrice: string;

    minMileage: string;
    maxMileage: string;

    minYear: string;
    maxYear: string;

    condition: MarketplaceCondition | "";
    fuelType: string;
    transmission: string;
    bodyStyle: string;

    state: string;
    city: string;

    dealerOnly: boolean;
    verifiedDealerOnly: boolean;
};

export const INITIAL_FILTERS: MarketplaceFilterState = {
    make: "",
    model: "",
    variant: "",

    minPrice: "",
    maxPrice: "",

    minMileage: "",
    maxMileage: "",

    minYear: "",
    maxYear: "",

    condition: "",
    fuelType: "",
    transmission: "",
    bodyStyle: "",

    state: "",
    city: "",

    dealerOnly: false,
    verifiedDealerOnly: false,
};

export type MarketplaceFilterKey = keyof MarketplaceFilterState;

function isMarketplaceCondition(
    value: string | null,
): value is MarketplaceCondition {
    return (
        value === "BRAND_NEW" ||
        value === "FOREIGN_USED" ||
        value === "NIGERIAN_USED"
    );
}


export function countActiveFilters(
    filters: MarketplaceFilterState,
): number {
    return Object.entries(filters).filter(([key, value]) => {
        if (
            key === "dealerOnly" ||
            key === "verifiedDealerOnly"
        ) {
            return value === true;
        }

        return (
            typeof value === "string" &&
            value.trim() !== ""
        );
    }).length;
}

/*
 * ============================================================
 * FILTER LABELS
 * ============================================================
 */

function formatOptionLabel(value: string): string {
    const labels: Record<string, string> = {
        BRAND_NEW: "Brand New",
        FOREIGN_USED: "Foreign Used",
        NIGERIAN_USED: "Nigerian Used",

        PETROL: "Petrol",
        DIESEL: "Diesel",
        ELECTRIC: "Electric",
        HYBRID: "Hybrid",
        PLUG_IN_HYBRID: "Plug-in hybrid",
        CNG: "CNG",
        LPG: "LPG",

        AUTOMATIC: "Automatic",
        MANUAL: "Manual",
        CVT: "CVT",
        DCT: "DCT",
        AMT: "AMT",

        SUV: "SUV",
        SEDAN: "Sedan",
        HATCHBACK: "Hatchback",
        COUPE: "Coupe",
        TRUCK: "Truck",
        VAN: "Van",
        WAGON: "Wagon",
        MPV: "MPV",
        PICKUP: "Pickup",
        CONVERTIBLE: "Convertible",
        BUS: "Bus",
    };

    return (
        labels[value] ??
        value
            .toLowerCase()
            .replaceAll("_", " ")
            .replace(/\b\w/g, (letter) =>
                letter.toUpperCase(),
            )
    );
}

function formatNaira(value: string): string {
    const amount = Number(value);

    if (!Number.isFinite(amount)) {
        return value;
    }

    return `₦${amount.toLocaleString("en-NG", {
        maximumFractionDigits: 2,
    })}`;
}

function formatMileage(value: string): string {
    const mileage = Number(value);

    if (!Number.isFinite(mileage)) {
        return value;
    }

    return `${mileage.toLocaleString("en-NG")} km`;
}

/*
 * ============================================================
 * ACTIVE FILTER CHIPS
 * ============================================================
 */

export interface ActiveMarketplaceFilter {
    key: MarketplaceFilterKey;
    label: string;
}

export interface MarketplaceVehicleFilterLabels {
    make?: string;
    model?: string;
    variant?: string;
}

export function getActiveMarketplaceFilters(
    filters: MarketplaceFilterState,
    vehicleLabels: MarketplaceVehicleFilterLabels = {},
): ActiveMarketplaceFilter[] {
    const activeFilters: ActiveMarketplaceFilter[] = [];

    if (filters.make) {
        activeFilters.push({ key: "make", label: filters.make });
    }

    if (filters.model) {
        activeFilters.push({ key: "model", label: filters.model });
    }

    if (filters.variant) {
        activeFilters.push({ key: "variant", label: filters.variant });
    }

    /*
     * Price range.
     */

    if (filters.minPrice && filters.maxPrice) {
        activeFilters.push({
            key: "minPrice",
            label: `${formatNaira(filters.minPrice)} – ${formatNaira(filters.maxPrice)}`,
        });
    } else {
        if (filters.minPrice) {
            activeFilters.push({
                key: "minPrice",
                label: `From ${formatNaira(filters.minPrice)}`,
            });
        }

        if (filters.maxPrice) {
            activeFilters.push({
                key: "maxPrice",
                label: `Up to ${formatNaira(filters.maxPrice)}`,
            });
        }
    }

    /*
     * Mileage range.
     */

    if (filters.minMileage && filters.maxMileage) {
        activeFilters.push({
            key: "minMileage",
            label: `${formatMileage(filters.minMileage)} – ${formatMileage(filters.maxMileage)}`,
        });
    } else {
        if (filters.minMileage) {
            activeFilters.push({
                key: "minMileage",
                label: `From ${formatMileage(filters.minMileage)}`,
            });
        }

        if (filters.maxMileage) {
            activeFilters.push({
                key: "maxMileage",
                label: `Up to ${formatMileage(filters.maxMileage)}`,
            });
        }
    }

    /*
     * Model year range.
     */

    if (filters.minYear && filters.maxYear) {
        activeFilters.push({
            key: "minYear",
            label: `${filters.minYear} – ${filters.maxYear}`,
        });
    } else {
        if (filters.minYear) {
            activeFilters.push({
                key: "minYear",
                label: `From ${filters.minYear}`,
            });
        }

        if (filters.maxYear) {
            activeFilters.push({
                key: "maxYear",
                label: `Up to ${filters.maxYear}`,
            });
        }
    }

    /*
     * Vehicle condition and specifications.
     */

    const optionFilters: {
        key: MarketplaceFilterKey;
        value: string;
    }[] = [
        {
            key: "condition",
            value: filters.condition,
        },
        {
            key: "fuelType",
            value: filters.fuelType,
        },
        {
            key: "transmission",
            value: filters.transmission,
        },
        {
            key: "bodyStyle",
            value: filters.bodyStyle,
        },
    ];

    for (const filter of optionFilters) {
        if (!filter.value) {
            continue;
        }

        activeFilters.push({
            key: filter.key,
            label: formatOptionLabel(filter.value),
        });
    }

    /*
     * Location.
     */

    if (filters.state.trim()) {
        activeFilters.push({
            key: "state",
            label: filters.state.trim(),
        });
    }

    if (filters.city.trim()) {
        activeFilters.push({
            key: "city",
            label: `LGA: ${filters.city.trim()}`,
        });
    }

    /*
     * Dealer filters.
     */

    if (filters.dealerOnly) {
        activeFilters.push({
            key: "dealerOnly",
            label: "Dealers only",
        });
    }

    if (filters.verifiedDealerOnly) {
        activeFilters.push({
            key: "verifiedDealerOnly",
            label: "Verified dealers",
        });
    }

    return activeFilters;
}

/*
 * ============================================================
 * QUERY BUILDING
 * ============================================================
 */

function toNumber(
    value: string,
): number | undefined {
    if (!value.trim()) {
        return undefined;
    }

    const number = Number(value);

    return Number.isFinite(number)
        ? number
        : undefined;
}

export function buildSearchParams(
    query: string,
    filters: MarketplaceFilterState,
    sort: SortOption,
    page: number,
): MarketplaceSearchParams {
    const params: MarketplaceSearchParams = {
        page,
        limit: PAGE_SIZE,
        sort,
    };

    const trimmedQuery = query.trim();

    if (trimmedQuery) {
        params.q = trimmedQuery;
    }

    /*
     * External vehicle catalogue labels.
     */
    if (filters.make) params.make = filters.make;
    if (filters.model) params.model = filters.model;
    if (filters.variant) params.variant = filters.variant;

    /*
     * Numeric filters.
     */

    const numericFilters: {
        key:
            | "minPrice"
            | "maxPrice"
            | "minMileage"
            | "maxMileage"
            | "minYear"
            | "maxYear";
        value: string;
    }[] = [
        {
            key: "minPrice",
            value: filters.minPrice,
        },
        {
            key: "maxPrice",
            value: filters.maxPrice,
        },
        {
            key: "minMileage",
            value: filters.minMileage,
        },
        {
            key: "maxMileage",
            value: filters.maxMileage,
        },
        {
            key: "minYear",
            value: filters.minYear,
        },
        {
            key: "maxYear",
            value: filters.maxYear,
        },
    ];

    for (const filter of numericFilters) {
        const value = toNumber(filter.value);

        if (value !== undefined) {
            params[filter.key] = value;
        }
    }

    /*
     * Vehicle specifications.
     */

    if (filters.condition) {
        params.condition = filters.condition;
    }

    if (filters.fuelType) {
        params.fuelType = filters.fuelType;
    }

    if (filters.transmission) {
        params.transmission = filters.transmission;
    }

    if (filters.bodyStyle) {
        params.bodyStyle = filters.bodyStyle;
    }

    /*
     * Location.
     */

    if (filters.state.trim()) {
        params.state = filters.state.trim();
    }

    if (filters.city.trim()) {
        params.city = filters.city.trim();
    }

    /*
     * Dealer filters.
     */

    if (filters.dealerOnly) {
        params.dealerOnly = true;
    }

    if (filters.verifiedDealerOnly) {
        params.verifiedDealerOnly = true;
    }

    return params;
}

/*
 * ============================================================
 * URL SYNCHRONIZATION
 * ============================================================
 */

export function readFiltersFromUrl(): {
    query: string;
    filters: MarketplaceFilterState;
    sort: SortOption;
    page: number;
} {
    const params = new URLSearchParams(
        window.location.search,
    );

    const requestedCondition = params.get("condition");

    const condition: MarketplaceCondition | "" =
        isMarketplaceCondition(requestedCondition)
            ? requestedCondition
            : "";

    const filters: MarketplaceFilterState = {
        make: params.get("make") ?? "",
        model: params.get("model") ?? "",
        variant: params.get("variant") ?? "",

        minPrice: params.get("minPrice") ?? "",
        maxPrice: params.get("maxPrice") ?? "",

        minMileage: params.get("minMileage") ?? "",
        maxMileage: params.get("maxMileage") ?? "",

        minYear: params.get("minYear") ?? "",
        maxYear: params.get("maxYear") ?? "",

        condition,
        fuelType: params.get("fuelType") ?? "",
        transmission: params.get("transmission") ?? "",
        bodyStyle: params.get("bodyStyle") ?? "",

        state: params.get("state") ?? "",
        city: params.get("city") ?? "",

        dealerOnly: params.get("dealerOnly") === "true",
        verifiedDealerOnly:
            params.get("verifiedDealerOnly") === "true",
    };

    const requestedSort = params.get("sort");

    const validSort = SORT_OPTIONS.some(
        (option) => option.value === requestedSort,
    );

    const requestedPage = Number(
        params.get("page") ?? "1",
    );

    return {
        query: params.get("q") ?? "",
        filters,
        sort: validSort
            ? (requestedSort as SortOption)
            : (params.get("q")?.trim() ? "relevance" : "newest"),
        page:
            Number.isInteger(requestedPage) &&
            requestedPage > 0
                ? requestedPage
                : 1,
    };
}
