export const queryKeys = {
    auth: {
        all: ["auth"] as const,
            currentUser: () =>
                [...queryKeys.auth.all, "current-user"] as const,
    },

    profile: {
        all: ["profile"] as const,

        details: () =>
            [...queryKeys.profile.all, "details"] as const,

        privacy: () =>
            [...queryKeys.profile.all, "privacy"] as const,
    },

} as const;
