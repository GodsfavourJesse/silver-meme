"use client";

import {
    useQuery,
    type UseQueryResult,
} from "@tanstack/react-query";

import { queryKeys } from "@/app/lib/query/query-keys";
import { ApiError } from "@/app/lib/api/api-error";
import { authService } from "@/app/services/user/auth/auth.service";
import type { AuthUser } from "@/app/types/user/auth.types";

export function useCurrentUser(): UseQueryResult<AuthUser | null> {
    return useQuery({
        queryKey: queryKeys.auth.currentUser(),

        queryFn: async (): Promise<AuthUser | null> => {
            try {
                const response =
                    await authService.getCurrentUser();

                return response.data.user;
            } catch (error: unknown) {
                /*
                 * An expired or missing session means
                 * the visitor is not authenticated.
                 */
                if (
                    error instanceof ApiError &&
                    error.status === 401
                ) {
                    return null;
                }

                /*
                 * Preserve other errors, including network
                 * failures and server errors, so the UI
                 * can offer a retry instead of redirecting.
                 */
                throw error;
            }
        },

        retry: false,

        staleTime: 30_000,

        refetchOnWindowFocus: true,
    });
}