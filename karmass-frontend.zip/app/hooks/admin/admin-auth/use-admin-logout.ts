"use client";

import {
    useMutation,
    useQueryClient,
} from "@tanstack/react-query";

import { adminAuthService } from "../../../services/admin/admin-auth.service";

export function useAdminLogout() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (
            csrfToken: string,
        ) => adminAuthService.logout(csrfToken),

        onSuccess: async () => {
            queryClient.clear();
        },
    });
}
