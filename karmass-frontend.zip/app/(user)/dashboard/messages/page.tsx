import { Suspense } from "react";

import type { Metadata } from "next";

import { MessagesInbox } from "@/app/components/userComponents/messaging/MessagingInbox";

export const metadata: Metadata = {
    title: "Messages | KARMASS",
    description:
        "Manage your conversations with buyers and sellers on KARMASS.",
};

function MessagesLoading() {
    return (
        <main className="min-h-screen bg-[#0a0912] px-4 py-6 text-white sm:px-6 sm:py-8">
            <div className="mx-auto max-w-7xl animate-pulse">
                <div className="mb-8 space-y-3">
                    <div className="h-3 w-36 rounded bg-white/10" />
                    <div className="h-8 w-48 rounded-lg bg-white/10" />
                    <div className="h-4 w-72 max-w-full rounded bg-white/[0.06]" />
                </div>

                <div className="h-[650px] rounded-2xl border border-white/[0.08] bg-white/[0.025]" />
            </div>
        </main>
    );
}

export default function MessagesPage() {
    return (
        <Suspense fallback={<MessagesLoading />}>
            <MessagesInbox />
        </Suspense>
    );
}