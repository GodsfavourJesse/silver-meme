import UserProfilePage from "@/app/components/userComponents/profile/ProfilePage";
import type { Metadata } from "next";


export const instant = false;

export const metadata: Metadata = {
    title: "My Profile | KARMASS",
    description:
        "Manage your KARMASS personal information, account details, privacy settings, and account preferences.",
    robots: {
        index: false,
        follow: false,
    },
};

export default function UserProfileRoute() {
    return <UserProfilePage />;
}