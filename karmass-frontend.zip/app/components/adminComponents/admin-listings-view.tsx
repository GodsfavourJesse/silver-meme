// "use client";

// import { useEffect, useMemo, useState } from "react";
// import {
//     AlertTriangle,
//     CheckCircle2,
//     Clock3,
//     Image as ImageIcon,
//     LoaderCircle,
//     RefreshCw,
//     Search,
//     ShieldCheck,
//     XCircle,
// } from "lucide-react";
// import { AdminAuthGuard } from "@/app/components/adminComponents/admin-auth-guard";
// import { adminFetch } from "@/app/lib/admin/admin-fetch";

// type ImageCheckStatus = "PENDING" | "PASSED" | "REVIEW" | "FAILED" | string;

// interface ListingImage {
//     id: string;
//     objectKey: string;
//     originalName?: string | null;
//     mimeType?: string | null;
//     width?: number | null;
//     height?: number | null;
//     imageCheckStatus: ImageCheckStatus;
//     similarityScore?: string | number | null;
//     matchedImageId?: string | null;
//     matchedListingId?: string | null;
//     checkReason?: string | null;
//     sortOrder: number;
// }

// interface PendingListing {
//     listing: {
//         id: string;
//         title: string;
//         description: string;
//         price: string | number;
//         currency: string;
//         status: string;
//         condition?: string;
//         mileage?: number | null;
//         city?: string | null;
//         state?: string | null;
//         createdAt: string;
//         sellerId: string;
//     };
//     vehicleMake?: { name: string };
//     vehicleModel?: { name: string };
//     vehicleGeneration?: { name: string };
//     vehicleVariant?: { name: string; year: number };
//     seller?: {
//         email?: string;
//         firstName?: string;
//         lastName?: string;
//         accountType?: string;
//     };
//     images: ListingImage[];
//     history?: Array<{
//         action?: string;
//         reason?: string | null;
//         createdAt?: string;
//     }>;
// }

// const PUBLIC_STORAGE_URL =
//     process.env.NEXT_PUBLIC_STORAGE_PUBLIC_URL?.replace(/\/+$/, "");

// function formatMoney(value: string | number, currency = "NGN") {
//     const amount = Number(value);
//     if (!Number.isFinite(amount)) return `${currency} ${value}`;
//     return new Intl.NumberFormat("en-NG", {
//         style: "currency",
//         currency,
//         maximumFractionDigits: 0,
//     }).format(amount);
// }

// function vehicleLabel(item: PendingListing) {
//     return [
//         item.vehicleVariant?.year,
//         item.vehicleMake?.name,
//         item.vehicleModel?.name,
//         item.vehicleGeneration?.name,
//         item.vehicleVariant?.name,
//     ].filter(Boolean).join(" ");
// }

// function imageStatus(status: ImageCheckStatus) {
//     if (status === "PASSED") return {
//         label: "Passed",
//         icon: CheckCircle2,
//         style: "border-emerald-400/25 bg-emerald-400/10 text-emerald-300",
//     };
//     if (status === "FAILED") return {
//         label: "Failed",
//         icon: XCircle,
//         style: "border-red-400/25 bg-red-400/10 text-red-300",
//     };
//     if (status === "REVIEW") return {
//         label: "Needs review",
//         icon: AlertTriangle,
//         style: "border-amber-400/25 bg-amber-400/10 text-amber-200",
//     };
//     return {
//         label: "Scanning",
//         icon: Clock3,
//         style: "border-sky-400/25 bg-sky-400/10 text-sky-200",
//     };
// }

// function canApprove(item: PendingListing) {
//     return item.images.length > 0 &&
//         item.images.every((image) => image.imageCheckStatus === "PASSED");
// }

// export function AdminListingsView() {
//     const [items, setItems] = useState<PendingListing[]>([]);
//     const [selectedId, setSelectedId] = useState("");
//     const [search, setSearch] = useState("");
//     const [rejectionReason, setRejectionReason] = useState("");
//     const [loading, setLoading] = useState(true);
//     const [detailLoading, setDetailLoading] = useState(false);
//     const [actionLoading, setActionLoading] = useState(false);
//     const [error, setError] = useState("");
//     const [notice, setNotice] = useState("");

//     const selected = useMemo(
//         () => items.find((item) => item.listing.id === selectedId) ?? null,
//         [items, selectedId],
//     );

//     const hasPendingImageChecks = selected?.images.some(
//         (image) => image.imageCheckStatus === "PENDING",
//     ) ?? false;

//     const filteredItems = useMemo(() => {
//         const term = search.trim().toLowerCase();
//         if (!term) return items;
//         return items.filter((item) => [
//             item.listing.title,
//             item.listing.id,
//             item.seller?.email,
//             vehicleLabel(item),
//         ].some((value) => String(value ?? "").toLowerCase().includes(term)));
//     }, [items, search]);

//     async function loadPending(preferredId?: string) {
//         setLoading(true);
//         setError("");
//         try {
//             const response = await adminFetch<{ listings: PendingListing[] }>(
//                 "/listings/moderation/pending",
//             );
//             const nextItems = response.data?.listings ?? [];
//             setItems(nextItems);
//             const nextId = preferredId && nextItems.some((item) => item.listing.id === preferredId)
//                 ? preferredId
//                 : nextItems[0]?.listing.id ?? "";
//             setSelectedId(nextId);
//         } catch (e) {
//             setError(e instanceof Error ? e.message : "Unable to load listings awaiting review.");
//         } finally {
//             setLoading(false);
//         }
//     }

//     async function refreshSelected() {
//         if (!selectedId) return loadPending();
//         setDetailLoading(true);
//         setError("");
//         try {
//             const response = await adminFetch<{ listing: PendingListing }>(
//                 `/listings/moderation/${encodeURIComponent(selectedId)}`,
//             );
//             const detailed = response.data?.listing;
//             if (detailed) {
//                 setItems((current) => current.map((item) =>
//                     item.listing.id === selectedId ? detailed : item,
//                 ));
//             }
//         } catch (e) {
//             setError(e instanceof Error ? e.message : "Unable to refresh listing analysis.");
//         } finally {
//             setDetailLoading(false);
//         }
//     }

//     useEffect(() => {
//         void loadPending();
//         // Initial queue load only; manual refresh is handled by the button.
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, []);

//     /*
//      * Image-intelligence runs asynchronously. Poll the selected listing
//      * while any image remains PENDING so the admin sees updated scan
//      * results without needing to reload the page manually.
//      */
//     useEffect(() => {
//         if (!selectedId || !hasPendingImageChecks) return;

//         const timer = window.setInterval(() => {
//             void (async () => {
//                 try {
//                     const response = await adminFetch<{ listing: PendingListing }>(
//                         `/listings/moderation/${encodeURIComponent(selectedId)}`,
//                     );
//                     const detailed = response.data?.listing;
//                     if (detailed) {
//                         setItems((current) => current.map((item) =>
//                             item.listing.id === selectedId ? detailed : item,
//                         ));
//                     }
//                 } catch {
//                     // Keep the current view intact; manual refresh surfaces errors.
//                 }
//             })();
//         }, 10000);

//         return () => window.clearInterval(timer);
//     }, [selectedId, hasPendingImageChecks]);

//     async function approve() {
//         if (!selected || !canApprove(selected)) return;
//         setActionLoading(true);
//         setError("");
//         setNotice("");
//         try {
//             const response = await adminFetch<{ listing: { id: string } }>(
//                 `/listings/moderation/${encodeURIComponent(selected.listing.id)}/approve`,
//                 { method: "POST", body: {} },
//             );
//             setNotice(response.message ?? "Listing approved and published.");
//             await loadPending();
//         } catch (e) {
//             setError(e instanceof Error ? e.message : "Listing approval failed.");
//             await refreshSelected();
//         } finally {
//             setActionLoading(false);
//         }
//     }

//     async function reject() {
//         if (!selected || rejectionReason.trim().length < 5) return;
//         setActionLoading(true);
//         setError("");
//         setNotice("");
//         try {
//             const response = await adminFetch<{ listing: { id: string } }>(
//                 `/listings/moderation/${encodeURIComponent(selected.listing.id)}/reject`,
//                 { method: "POST", body: { reason: rejectionReason.trim() } },
//             );
//             setNotice(response.message ?? "Listing rejected.");
//             setRejectionReason("");
//             await loadPending();
//         } catch (e) {
//             setError(e instanceof Error ? e.message : "Listing rejection failed.");
//         } finally {
//             setActionLoading(false);
//         }
//     }

//     return (
//         <AdminAuthGuard>
//             <div className="space-y-6">
//                 <header className="flex flex-wrap items-end justify-between gap-4">
//                     <div>
//                         <p className="text-[11px] font-medium uppercase tracking-[0.3em] text-kar-accent">
//                             Marketplace moderation
//                         </p>
//                         <h1 className="mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">
//                             Listing review
//                         </h1>
//                         <p className="mt-2 max-w-2xl text-sm leading-6 text-kar-muted">
//                             Review submitted vehicle listings alongside the automated image-intelligence results before approving or rejecting them.
//                         </p>
//                     </div>
//                     <button
//                         type="button"
//                         onClick={() => void loadPending(selectedId)}
//                         disabled={loading}
//                         className="inline-flex items-center gap-2 rounded-full border border-kar-border bg-kar-surface px-4 py-2.5 text-sm hover:border-kar-accent/50 disabled:opacity-50"
//                     >
//                         <RefreshCw size={15} className={loading ? "animate-spin" : ""} />
//                         Refresh queue
//                     </button>
//                 </header>

//                 {notice && (
//                     <div role="status" className="rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-4 text-sm text-emerald-200">
//                         {notice}
//                     </div>
//                 )}
//                 {error && (
//                     <div role="alert" className="flex items-start gap-3 rounded-xl border border-red-400/25 bg-red-400/10 p-4 text-sm text-red-200">
//                         <AlertTriangle size={18} className="mt-0.5 shrink-0" />
//                         <div className="flex-1">{error}</div>
//                         <button type="button" onClick={() => void loadPending(selectedId)} className="font-semibold underline">Retry</button>
//                     </div>
//                 )}

//                 <div className="grid gap-5 xl:grid-cols-[minmax(300px,0.85fr)_minmax(0,1.6fr)]">
//                     <section className="overflow-hidden rounded-2xl border border-kar-border bg-kar-surface">
//                         <div className="border-b border-kar-border p-4">
//                             <div className="flex items-center justify-between">
//                                 <h2 className="font-semibold">Awaiting review</h2>
//                                 <span className="rounded-full bg-kar-accent/10 px-2.5 py-1 text-xs font-semibold text-kar-accent">{items.length}</span>
//                             </div>
//                             <label className="mt-4 flex items-center gap-2 rounded-xl border border-kar-border bg-kar-bg px-3">
//                                 <Search size={16} className="text-kar-muted" />
//                                 <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search title, seller or vehicle" className="h-11 min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-kar-muted/70" />
//                             </label>
//                         </div>
//                         <div className="max-h-[72vh] overflow-y-auto p-2">
//                             {loading ? (
//                                 <div className="flex items-center justify-center gap-2 p-10 text-sm text-kar-muted">
//                                     <LoaderCircle size={17} className="animate-spin" /> Loading review queue…
//                                 </div>
//                             ) : filteredItems.length === 0 ? (
//                                 <div className="p-8 text-center">
//                                     <ShieldCheck size={28} className="mx-auto text-kar-accent" />
//                                     <p className="mt-3 text-sm font-medium">{items.length ? "No matches found" : "Review queue is clear"}</p>
//                                     <p className="mt-1 text-xs leading-5 text-kar-muted">{items.length ? "Try another search term." : "New listings appear here after sellers submit them for review."}</p>
//                                 </div>
//                             ) : filteredItems.map((item) => {
//                                 const isActive = selectedId === item.listing.id;
//                                 const passed = item.images.filter((image) => image.imageCheckStatus === "PASSED").length;
//                                 return (
//                                     <button
//                                         type="button"
//                                         key={item.listing.id}
//                                         onClick={() => {
//                                             setSelectedId(item.listing.id);
//                                             setError("");
//                                             setRejectionReason("");
//                                         }}
//                                         className={`mb-1 w-full rounded-xl border p-4 text-left transition ${isActive ? "border-kar-accent/40 bg-kar-accent/[0.06]" : "border-transparent hover:bg-kar-surface-raised"}`}
//                                     >
//                                         <div className="flex items-start justify-between gap-3">
//                                             <p className="line-clamp-2 text-sm font-semibold">{item.listing.title}</p>
//                                             <span className="shrink-0 rounded-full bg-amber-400/10 px-2 py-1 text-[10px] font-semibold text-amber-200">Pending</span>
//                                         </div>
//                                         <p className="mt-2 text-xs text-kar-muted">{vehicleLabel(item) || "Vehicle details unavailable"}</p>
//                                         <div className="mt-3 flex items-center justify-between gap-3 text-xs">
//                                             <span className="text-kar-text">{formatMoney(item.listing.price, item.listing.currency)}</span>
//                                             <span className="text-kar-muted">{passed}/{item.images.length} images passed</span>
//                                         </div>
//                                     </button>
//                                 );
//                             })}
//                         </div>
//                     </section>

//                     <section className="min-w-0 space-y-5">
//                         {!selected ? (
//                             <div className="flex min-h-72 items-center justify-center rounded-2xl border border-kar-border bg-kar-surface p-8 text-center text-sm text-kar-muted">
//                                 Select a listing from the queue to inspect its details and image checks.
//                             </div>
//                         ) : (
//                             <>
//                                 <div className="rounded-2xl border border-kar-border bg-kar-surface p-5 sm:p-6">
//                                     <div className="flex flex-wrap items-start justify-between gap-4">
//                                         <div className="min-w-0">
//                                             <p className="text-[10px] font-medium uppercase tracking-[0.25em] text-kar-accent">Listing details</p>
//                                             <h2 className="mt-2 text-xl font-semibold">{selected.listing.title}</h2>
//                                             <p className="mt-1 text-sm text-kar-muted">{vehicleLabel(selected) || "Vehicle details unavailable"}</p>
//                                         </div>
//                                         <p className="text-xl font-semibold">{formatMoney(selected.listing.price, selected.listing.currency)}</p>
//                                     </div>
//                                     <div className="mt-5 grid gap-3 sm:grid-cols-2">
//                                         <div className="rounded-xl bg-kar-bg p-3">
//                                             <p className="text-[10px] uppercase tracking-wider text-kar-muted">Seller</p>
//                                             <p className="mt-1 text-sm font-medium">{[selected.seller?.firstName, selected.seller?.lastName].filter(Boolean).join(" ") || "Seller"}</p>
//                                             <p className="mt-1 break-all text-xs text-kar-muted">{selected.seller?.email ?? selected.listing.sellerId}</p>
//                                             {selected.seller?.accountType && <p className="mt-1 text-xs text-kar-muted">Account: {selected.seller.accountType}</p>}
//                                         </div>
//                                         <div className="rounded-xl bg-kar-bg p-3">
//                                             <p className="text-[10px] uppercase tracking-wider text-kar-muted">Submitted</p>
//                                             <p className="mt-1 text-sm">{new Date(selected.listing.createdAt).toLocaleString()}</p>
//                                             <p className="mt-1 text-xs text-kar-muted">{[selected.listing.city, selected.listing.state].filter(Boolean).join(", ") || "Location not supplied"}</p>
//                                         </div>
//                                     </div>
//                                     <p className="mt-5 whitespace-pre-wrap text-sm leading-6 text-kar-muted">{selected.listing.description || "No description supplied."}</p>
//                                 </div>

//                                 <div className="rounded-2xl border border-kar-border bg-kar-surface p-5 sm:p-6">
//                                     <div className="flex flex-wrap items-center justify-between gap-3">
//                                         <div>
//                                             <h2 className="font-semibold">Image intelligence</h2>
//                                             <p className="mt-1 text-xs text-kar-muted">Automated scan results are shown per image. Approval is enabled only when every image has passed.</p>
//                                         </div>
//                                         <button type="button" onClick={() => void refreshSelected()} disabled={detailLoading} className="inline-flex items-center gap-2 rounded-full border border-kar-border px-3 py-2 text-xs hover:border-kar-accent/40 disabled:opacity-50">
//                                             <RefreshCw size={13} className={detailLoading ? "animate-spin" : ""} /> Refresh scan results
//                                         </button>
//                                     </div>

//                                     {selected.images.length === 0 ? (
//                                         <div className="mt-4 rounded-xl border border-red-400/20 bg-red-400/5 p-4 text-sm text-red-200">
//                                             No listing images found. This listing cannot be approved.
//                                         </div>
//                                     ) : (
//                                         <div className="mt-4 grid gap-3 md:grid-cols-2">
//                                             {selected.images.slice().sort((a, b) => a.sortOrder - b.sortOrder).map((image) => {
//                                                 const status = imageStatus(image.imageCheckStatus);
//                                                 const StatusIcon = status.icon;
//                                                 const src = PUBLIC_STORAGE_URL
//                                                     ? `${PUBLIC_STORAGE_URL}/${image.objectKey.split("/").map(encodeURIComponent).join("/")}`
//                                                     : null;
//                                                 return (
//                                                     <article key={image.id} className="overflow-hidden rounded-xl border border-kar-border bg-kar-bg">
//                                                         {src ? (
//                                                             // The public storage URL is optional; private buckets should use a signed-URL endpoint.
//                                                             // eslint-disable-next-line @next/next/no-img-element
//                                                             <img src={src} alt={image.originalName ?? "Vehicle listing image"} className="h-44 w-full object-cover" />
//                                                         ) : (
//                                                             <div className="flex h-32 flex-col items-center justify-center gap-2 border-b border-kar-border text-kar-muted">
//                                                                 <ImageIcon size={24} />
//                                                                 <span className="max-w-full truncate px-3 text-xs">{image.originalName ?? image.objectKey}</span>
//                                                                 <span className="text-[10px]">Configure NEXT_PUBLIC_STORAGE_PUBLIC_URL to show public images</span>
//                                                             </div>
//                                                         )}
//                                                         <div className="space-y-3 p-4">
//                                                             <div className="flex flex-wrap items-center justify-between gap-2">
//                                                                 <span className="truncate text-xs text-kar-muted">{image.originalName ?? `Image ${image.sortOrder + 1}`}</span>
//                                                                 <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-1 text-[10px] font-semibold ${status.style}`}>
//                                                                     <StatusIcon size={12} /> {status.label}
//                                                                 </span>
//                                                             </div>
//                                                             <p className="text-xs leading-5 text-kar-muted">{image.checkReason || (image.imageCheckStatus === "PASSED" ? "Automated image checks passed." : "Waiting for image-intelligence explanation.")}</p>
//                                                             {image.similarityScore !== null && image.similarityScore !== undefined && (
//                                                                 <p className="text-xs">Similarity score: <strong>{image.similarityScore}</strong></p>
//                                                             )}
//                                                             {image.matchedListingId && (
//                                                                 <div className="rounded-lg border border-amber-400/20 bg-amber-400/5 p-3 text-xs text-amber-100">
//                                                                     Possible duplicate listing detected.
//                                                                     <p className="mt-1 break-all text-amber-100/70">Matched listing: {image.matchedListingId}</p>
//                                                                 </div>
//                                                             )}
//                                                             {image.matchedImageId && (
//                                                                 <p className="break-all text-[10px] text-kar-muted">Matched image: {image.matchedImageId}</p>
//                                                             )}
//                                                         </div>
//                                                     </article>
//                                                 );
//                                             })}
//                                         </div>
//                                     )}

//                                     <div className="mt-5 rounded-xl border border-kar-border p-4">
//                                         <div className="flex items-center justify-between gap-3">
//                                             <p className="text-sm font-medium">Image-check summary</p>
//                                             <p className="text-xs text-kar-muted">
//                                                 {selected.images.filter((image) => image.imageCheckStatus === "PASSED").length} passed · {selected.images.filter((image) => image.imageCheckStatus === "PENDING").length} pending · {selected.images.filter((image) => image.imageCheckStatus === "REVIEW").length} review · {selected.images.filter((image) => image.imageCheckStatus === "FAILED").length} failed
//                                             </p>
//                                         </div>
//                                         {!canApprove(selected) && (
//                                             <p className="mt-2 text-xs leading-5 text-amber-200/90">
//                                                 Approval is blocked until all images have completed scanning and passed. Images marked “Needs review” or “Failed” must be handled through image review before this listing can be approved.
//                                             </p>
//                                         )}
//                                     </div>
//                                 </div>

//                                 <div className="rounded-2xl border border-kar-border bg-kar-surface p-5 sm:p-6">
//                                     <h2 className="font-semibold">Moderation decision</h2>
//                                     <p className="mt-1 text-xs leading-5 text-kar-muted">Approval publishes the listing. Rejection requires a clear reason that will be sent to the seller.</p>
//                                     <label className="mt-4 block text-xs font-medium text-kar-muted">
//                                         Rejection reason
//                                         <textarea
//                                             value={rejectionReason}
//                                             onChange={(event) => setRejectionReason(event.target.value)}
//                                             rows={3}
//                                             maxLength={2000}
//                                             placeholder="Explain what needs to be corrected…"
//                                             className="mt-2 w-full resize-y rounded-xl border border-kar-border bg-kar-bg p-3 text-sm text-kar-text outline-none focus:border-kar-accent/50"
//                                         />
//                                     </label>
//                                     <div className="mt-4 flex flex-wrap gap-3">
//                                         <button
//                                             type="button"
//                                             onClick={() => void approve()}
//                                             disabled={actionLoading || !canApprove(selected)}
//                                             className="inline-flex items-center justify-center gap-2 rounded-full bg-kar-accent px-5 py-3 text-sm font-semibold text-black transition hover:brightness-105 disabled:cursor-not-allowed disabled:opacity-40"
//                                             title={!canApprove(selected) ? "All listing images must pass image intelligence before approval." : undefined}
//                                         >
//                                             {actionLoading ? <LoaderCircle size={16} className="animate-spin" /> : <CheckCircle2 size={16} />}
//                                             Approve listing
//                                         </button>
//                                         <button
//                                             type="button"
//                                             onClick={() => void reject()}
//                                             disabled={actionLoading || rejectionReason.trim().length < 5}
//                                             className="inline-flex items-center justify-center gap-2 rounded-full border border-red-400/30 px-5 py-3 text-sm font-semibold text-red-200 transition hover:bg-red-400/10 disabled:cursor-not-allowed disabled:opacity-40"
//                                         >
//                                             <XCircle size={16} /> Reject listing
//                                         </button>
//                                     </div>
//                                 </div>
//                             </>
//                         )}
//                     </section>
//                 </div>
//             </div>
//         </AdminAuthGuard>
//     );
// }
