"use client";

import { useState, type KeyboardEvent } from "react";

import { Eye, EyeOff, LockKeyhole, TriangleAlert } from "lucide-react";

import { LoginField } from "./login-field";

interface PasswordFieldProps {
    value: string;
    onChange: (value: string) => void;
    disabled?: boolean;
}

export function PasswordField({
    value,
    onChange,
    disabled = false,
}: PasswordFieldProps) {
    const [showPassword, setShowPassword] = useState(false);
    const [capsLockOn, setCapsLockOn] = useState(false);

    function detectCapsLock(event: KeyboardEvent<HTMLInputElement>): void {
        setCapsLockOn(event.getModifierState("CapsLock"));
    }

    return (
        <LoginField
            id="admin-password"
            name="password"
            label="Password"
            icon={<LockKeyhole size={19} />}
            type={showPassword ? "text" : "password"}
            autoComplete="current-password"
            placeholder="Enter your password"
            value={value}
            onChange={(event) => onChange(event.target.value)}
            onKeyDown={detectCapsLock}
            onKeyUp={detectCapsLock}
            onBlur={() => setCapsLockOn(false)}
            required
            maxLength={128}
            disabled={disabled}
            trailing={
                <button
                    type="button"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                    aria-pressed={showPassword}
                    onClick={() => setShowPassword((current) => !current)}
                    disabled={disabled}
                    className="flex h-10 w-10 items-center justify-center rounded-full text-kar-muted transition hover:bg-kar-surface-raised hover:text-kar-text disabled:cursor-not-allowed"
                >
                    {showPassword ? <EyeOff size={19} /> : <Eye size={19} />}
                </button>
            }
            hint={
                capsLockOn ? (
                    <p
                        role="status"
                        className="flex items-center gap-2 text-xs text-amber-300"
                    >
                        <TriangleAlert size={14} />
                        Caps Lock is on.
                    </p>
                ) : null
            }
        />
    );
}