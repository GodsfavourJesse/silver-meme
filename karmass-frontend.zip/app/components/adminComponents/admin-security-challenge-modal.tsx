"use client";

import { adminSecurityChallengeService } from "@/app/services/admin/admin-security-challenge.service";
import { AdminSecurityChallengeQuestion, StartAdminSecurityChallengeResponse } from "@/app/types/admin/admin-security-challenge.types";
import {
    AlertCircle,
    ArrowRight,
    Check,
    CheckCircle2,
    LoaderCircle,
    LockKeyhole,
    RotateCcw,
    ShieldCheck,
    X,
} from "lucide-react";
import { useCallback, useEffect, useState, type FormEvent } from "react";


type Props = {
    open: boolean;
    onClose: () => void;
    onComplete: (challengeToken: string) => Promise<void> | void;
};

const STAGE_LABELS = [
    "Platform identity",
    "Platform purpose",
    "Administrator responsibility",
    "Security awareness",
    "Vehicle recognition",
];

export function AdminSecurityChallengeModal({ open, onClose, onComplete }: Props) {
    const [challenge, setChallenge] = useState<StartAdminSecurityChallengeResponse | null>(null);
    const [question, setQuestion] = useState<AdminSecurityChallengeQuestion | null>(null);
    const [selectedAnswer, setSelectedAnswer] = useState<string>("");
    const [completedStages, setCompletedStages] = useState(0);
    const [totalStages, setTotalStages] = useState(5);
    const [isStarting, setIsStarting] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isFinishing, setIsFinishing] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const reset = useCallback(() => {
        setChallenge(null);
        setQuestion(null);
        setSelectedAnswer("");
        setCompletedStages(0);
        setTotalStages(5);
        setIsStarting(false);
        setIsSubmitting(false);
        setIsFinishing(false);
        setError(null);
    }, []);

    const startChallenge = useCallback(async () => {
        setIsStarting(true);
        setError(null);
        try {
            const result = await adminSecurityChallengeService.start();
            setChallenge(result);
            setQuestion(result.question);
            setTotalStages(result.totalStages || 5);
            setCompletedStages(0);
            setSelectedAnswer("");
        } catch (cause) {
            setError(cause instanceof Error ? cause.message : "Unable to start the security challenge.");
        } finally {
            setIsStarting(false);
        }
    }, []);

    useEffect(() => {
        if (open && !challenge && !question && !isStarting && !error) {
            void startChallenge();
        }
    }, [open, challenge, question, isStarting, error, startChallenge]);

    useEffect(() => {
        if (!open) return;
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === "Escape" && !isSubmitting && !isFinishing) onClose();
        };
        window.addEventListener("keydown", handleKeyDown);
        return () => window.removeEventListener("keydown", handleKeyDown);
    }, [open, isSubmitting, isFinishing, onClose]);

    useEffect(() => {
        if (!open) reset();
    }, [open, reset]);

    if (!open) return null;

    async function handleAnswerSubmit(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        if (!challenge || !question || !selectedAnswer || isSubmitting || isFinishing) return;

        setIsSubmitting(true);
        setError(null);
        try {
            const result = await adminSecurityChallengeService.submitAnswer({
                challengeToken: challenge.challengeToken,
                answer: selectedAnswer,
            });
            setCompletedStages(result.completedStages);
            setTotalStages(result.totalStages || totalStages);
            if (result.completed) {
                setIsFinishing(true);
                await onComplete(challenge.challengeToken);
                return;
            }
            if (!result.nextQuestion) {
                throw new Error("The server did not return the next challenge question. Please restart the challenge.");
            }
            setQuestion(result.nextQuestion);
            setSelectedAnswer("");
        } catch (cause) {
            setError(cause instanceof Error ? cause.message : "Your answer could not be verified. Please try again.");
        } finally {
            setIsSubmitting(false);
            setIsFinishing(false);
        }
    }

    function handleClose() {
        if (isSubmitting || isFinishing) return;
        reset();
        onClose();
    }

    const stageNumber = question?.stage ?? Math.min(completedStages + 1, totalStages);
    const progress = Math.min(100, (completedStages / Math.max(totalStages, 1)) * 100);

    return (
        <div
            className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-black/75 p-3 backdrop-blur-md sm:p-6"
            onMouseDown={(event) => {
                if (event.target === event.currentTarget) handleClose();
            }}
        >
            <section
                role="dialog"
                aria-modal="true"
                aria-labelledby="admin-challenge-title"
                aria-describedby="admin-challenge-description"
                className="relative my-auto w-full max-w-2xl overflow-hidden rounded-[28px] border border-kar-border bg-[#100d1e] text-kar-text shadow-[0_30px_100px_rgba(0,0,0,0.65)]"
            >
                <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-[radial-gradient(ellipse_at_top,rgba(107,63,217,0.28),transparent_72%)]" />
                <header className="relative flex items-start justify-between gap-4 border-b border-kar-border/80 px-5 py-5 sm:px-8 sm:py-6">
                    <div className="flex items-start gap-3">
                        <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl border border-kar-accent/25 bg-kar-royal/20 text-kar-accent">
                            <ShieldCheck size={23} />
                        </span>
                        <div>
                            <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.24em] text-kar-accent">KARMASS · Restricted access</p>
                            <h2 id="admin-challenge-title" className="text-xl font-semibold tracking-tight sm:text-2xl">Security awareness check</h2>
                            <p id="admin-challenge-description" className="mt-1 max-w-lg text-sm leading-6 text-kar-muted">Complete all five stages to continue to administrator sign in.</p>
                        </div>
                    </div>
                    <button type="button" onClick={handleClose} disabled={isSubmitting || isFinishing} aria-label="Close security challenge" className="rounded-xl p-2 text-kar-muted transition hover:bg-white/5 hover:text-white disabled:opacity-40">
                        <X size={20} />
                    </button>
                </header>

                <div className="relative px-5 pb-6 pt-5 sm:px-8 sm:pb-8 sm:pt-6">
                    <div className="mb-6">
                        <div className="mb-3 flex items-center justify-between gap-3 text-xs">
                            <span className="font-medium text-kar-muted">STAGE {question ? question.stage : Math.min(completedStages + 1, totalStages)} OF {totalStages}</span>
                            <span className="text-kar-accent">{completedStages} completed</span>
                        </div>
                        <div className="h-1.5 overflow-hidden rounded-full bg-white/8">
                            <div className="h-full rounded-full bg-gradient-to-r from-kar-royal to-kar-accent transition-all duration-300" style={{ width: `${progress}%` }} />
                        </div>
                        <div className="mt-4 grid grid-cols-5 gap-2">
                            {Array.from({ length: totalStages }, (_, index) => {
                                const done = index < completedStages;
                                const active = index + 1 === stageNumber;
                                return (
                                    <div key={index} className={`min-w-0 rounded-xl border px-1 py-2 text-center ${done ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300" : active ? "border-kar-accent/50 bg-kar-royal/20 text-white" : "border-kar-border bg-white/[0.02] text-kar-muted/70"}`}>
                                        <div className="mx-auto mb-1 flex size-5 items-center justify-center rounded-full text-[10px] font-bold">
                                            {done ? <Check size={13} /> : index + 1}
                                        </div>
                                        <span className="hidden text-[9px] leading-3 sm:block">{STAGE_LABELS[index] ?? `Stage ${index + 1}`}</span>
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    {isStarting ? (
                        <div className="flex min-h-64 flex-col items-center justify-center text-center">
                            <LoaderCircle className="mb-4 animate-spin text-kar-accent" size={32} />
                            <h3 className="text-lg font-semibold">Preparing your challenge</h3>
                            <p className="mt-2 text-sm text-kar-muted">Connecting securely to the KARMASS server…</p>
                        </div>
                    ) : error && !question ? (
                        <div className="rounded-2xl border border-rose-400/20 bg-rose-400/[0.06] p-5 text-center">
                            <AlertCircle className="mx-auto mb-3 text-rose-300" size={28} />
                            <h3 className="font-semibold">We couldn't load the challenge</h3>
                            <p className="mt-2 text-sm leading-6 text-kar-muted">{error}</p>
                            <button type="button" onClick={() => { setError(null); void startChallenge(); }} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-kar-royal px-4 py-2.5 text-sm font-semibold hover:bg-kar-royal-hover">
                                <RotateCcw size={15} /> Try again
                            </button>
                        </div>
                    ) : question ? (
                        <form onSubmit={handleAnswerSubmit}>
                            <div className="mb-5">
                                <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-kar-accent">{question.type === "visual-match" ? "Visual recognition" : `Stage ${question.stage}`}</p>
                                <h3 className="text-xl font-semibold sm:text-2xl">{question.title}</h3>
                                <p className="mt-2 text-sm leading-6 text-kar-muted">{question.instruction}</p>
                            </div>

                            {question.type === "multiple-choice" ? (
                                <div className="grid gap-3 sm:grid-cols-2">
                                    {(question.options ?? []).map((option, index) => {
                                        const active = selectedAnswer === option.id;
                                        return (
                                            <button key={option.id} type="button" onClick={() => setSelectedAnswer(option.id)} className={`group flex min-h-[64px] items-center gap-3 rounded-2xl border p-4 text-left transition ${active ? "border-kar-accent bg-kar-royal/20 shadow-[0_0_0_1px_rgba(169,140,255,0.2)]" : "border-kar-border bg-white/[0.025] hover:border-kar-accent/50 hover:bg-white/[0.04]"}`}>
                                                <span className={`flex size-8 shrink-0 items-center justify-center rounded-xl border text-xs font-semibold ${active ? "border-kar-accent/40 bg-kar-royal text-white" : "border-kar-border bg-white/[0.03] text-kar-muted"}`}>{String.fromCharCode(65 + index)}</span>
                                                <span className="flex-1 text-sm font-medium leading-5">{option.label}</span>
                                                <span className={`flex size-5 shrink-0 items-center justify-center rounded-full border ${active ? "border-kar-accent bg-kar-accent text-[#100d1e]" : "border-kar-border text-transparent"}`}><Check size={12} /></span>
                                            </button>
                                        );
                                    })}
                                </div>
                            ) : (
                                <div className="grid gap-3 sm:grid-cols-2">
                                    <div className="rounded-2xl border border-kar-accent/30 bg-kar-royal/10 p-3 sm:col-span-2">
                                        <div className="mb-2 flex items-center justify-between gap-3">
                                            <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-kar-accent">Reference silhouette</span>
                                            <span className="rounded-full border border-kar-accent/20 px-2 py-1 text-[10px] text-kar-muted">Match this vehicle</span>
                                        </div>
                                        <div className="flex h-28 items-center justify-center rounded-xl bg-[#090811]/70 sm:h-32">
                                            <VehicleSilhouette assetId={question.referenceAsset ?? "vehicle-reference"} large />
                                        </div>
                                    </div>
                                    {(question.imageOptions ?? []).map((assetId, index) => {
                                        const active = selectedAnswer === assetId;
                                        return (
                                            <button key={`${assetId}-${index}`} type="button" onClick={() => setSelectedAnswer(assetId)} aria-label={`Select vehicle silhouette ${index + 1}`} className={`rounded-2xl border p-3 text-left transition ${active ? "border-kar-accent bg-kar-royal/20" : "border-kar-border bg-white/[0.025] hover:border-kar-accent/50"}`}>
                                                <div className="mb-2 flex items-center justify-between">
                                                    <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-kar-muted">Option {String.fromCharCode(65 + index)}</span>
                                                    <span className={`flex size-5 items-center justify-center rounded-full border ${active ? "border-kar-accent bg-kar-accent text-[#100d1e]" : "border-kar-border text-transparent"}`}><Check size={12} /></span>
                                                </div>
                                                <div className="flex h-24 items-center justify-center rounded-xl bg-[#090811]/70">
                                                    <VehicleSilhouette assetId={assetId} />
                                                </div>
                                            </button>
                                        );
                                    })}
                                </div>
                            )}

                            {error ? (
                                <div role="alert" className="mt-4 flex items-start gap-2 rounded-xl border border-rose-400/20 bg-rose-400/[0.06] p-3 text-sm text-rose-200">
                                    <AlertCircle size={17} className="mt-0.5 shrink-0" />
                                    <span>{error}</span>
                                </div>
                            ) : null}

                            <div className="mt-6 flex flex-col-reverse gap-3 border-t border-kar-border/70 pt-5 sm:flex-row sm:items-center sm:justify-between">
                                <p className="flex items-center gap-2 text-xs text-kar-muted"><LockKeyhole size={14} className="text-kar-accent" /> Answers are verified by the server.</p>
                                <button type="submit" disabled={!selectedAnswer || isSubmitting || isFinishing} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-kar-royal px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-kar-royal/20 transition hover:bg-kar-royal-hover disabled:cursor-not-allowed disabled:opacity-40">
                                    {isSubmitting || isFinishing ? <LoaderCircle size={17} className="animate-spin" /> : completedStages === totalStages - 1 ? <ShieldCheck size={17} /> : null}
                                    {isFinishing ? "Verifying access…" : isSubmitting ? "Checking answer…" : completedStages === totalStages - 1 ? "Complete challenge" : "Submit answer"}
                                    {!isSubmitting && !isFinishing && <ArrowRight size={16} />}
                                </button>
                            </div>
                        </form>
                    ) : null}

                    <div className="mt-5 flex items-center justify-center gap-2 text-[10px] text-kar-muted/70">
                        <CheckCircle2 size={13} className="text-kar-accent" /> This awareness check does not replace your administrator credentials.
                    </div>
                </div>
            </section>
        </div>
    );
}

function VehicleSilhouette({ assetId, large = false }: { assetId: string; large?: boolean }) {
    const value = assetId.toLowerCase();
    const isSuv = /suv|sport.?utility|crossover|jeep/.test(value);
    const isTruck = /truck|pickup|van/.test(value);
    const isSport = /sport|coupe|supercar/.test(value);
    const isHatch = /hatch|compact/.test(value);
    const roof = isTruck ? "M31 47 L39 27 L71 27 L81 47" : isSuv ? "M28 47 L36 24 L73 24 L88 47" : isSport ? "M29 47 L45 32 L69 29 L86 47" : isHatch ? "M29 47 L38 27 L70 27 L82 47" : "M28 47 L40 30 L70 30 L85 47";
    const body = isTruck ? "M15 48 L30 48 L39 27 L71 27 L82 43 L96 45 L101 52 L101 61 L12 61 L12 53 Z" : isSuv ? "M13 49 L27 49 L35 24 L74 24 L89 46 L100 49 L104 55 L104 61 L11 61 L11 54 Z" : isSport ? "M13 50 L29 47 L45 32 L69 29 L87 45 L100 49 L104 56 L104 61 L11 61 L11 55 Z" : "M12 50 L28 49 L40 30 L70 30 L85 46 L99 49 L104 55 L104 61 L11 61 L11 55 Z";
    return (
        <svg viewBox="0 0 116 82" aria-hidden="true" className={large ? "h-28 w-52 sm:h-32 sm:w-60" : "h-20 w-36"} fill="none">
            <defs><linearGradient id="car-metal" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#d7ccff" /><stop offset="1" stopColor="#7962bd" /></linearGradient></defs>
            <path d={body} fill="url(#car-metal)" fillOpacity=".16" stroke="#b9a4ff" strokeWidth="1.7" strokeLinejoin="round" />
            <path d={roof} stroke="#c8b8ff" strokeWidth="1.7" strokeLinejoin="round" />
            <path d={isTruck ? "M42 30 L39 44 L75 44 L69 30 Z" : isSuv ? "M39 27 L35 44 L82 44 L72 27 Z" : isSport ? "M47 33 L36 45 L82 45 L67 31 Z" : "M43 32 L34 45 L81 45 L69 32 Z"} fill="#a98cff" fillOpacity=".24" stroke="#a98cff" strokeOpacity=".7" strokeWidth="1" />
            <path d="M15 52 H101" stroke="#a98cff" strokeOpacity=".7" strokeWidth="1" />
            <circle cx="31" cy="61" r="8" fill="#0b0913" stroke="#c8b8ff" strokeWidth="1.8" />
            <circle cx="31" cy="61" r="3" fill="#a98cff" />
            <circle cx="85" cy="61" r="8" fill="#0b0913" stroke="#c8b8ff" strokeWidth="1.8" />
            <circle cx="85" cy="61" r="3" fill="#a98cff" />
            <path d="M17 54 H24 M95 53 H101" stroke="#eee9ff" strokeWidth="2" strokeLinecap="round" />
        </svg>
    );
}
