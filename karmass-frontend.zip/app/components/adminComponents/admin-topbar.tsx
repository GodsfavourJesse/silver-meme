"use client";

import { Menu, Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";

import type { AdminSession } from "@/app/types/admin/admin-dashboard.types";
import { NotificationBell } from "./notification-bell";
import { UserMenu } from "./user-menu";
import { CurrentDateLabel } from "./utils/current-date-label";

interface AdminTopbarProps {
    admin: AdminSession;
    onMenuClick: () => void;
}

export function AdminTopbar({ admin, onMenuClick }: AdminTopbarProps) {
    const [theme, setTheme] = useState<"dark" | "light">("dark");
    useEffect(() => {
        const saved = window.localStorage.getItem("karmass-admin-theme");
        const next = saved === "light" ? "light" : "dark";
        setTheme(next);
        document.documentElement.dataset.adminTheme = next;
    }, []);
    function toggleTheme() {
        const next = theme === "dark" ? "light" : "dark";
        setTheme(next);
        window.localStorage.setItem("karmass-admin-theme", next);
        document.documentElement.dataset.adminTheme = next;
    }
    return (
        <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between gap-4 border-b border-kar-border bg-kar-bg/80 px-4 backdrop-blur-xl sm:px-6 lg:px-8">
            <button
                type="button"
                aria-label="Open menu"
                onClick={onMenuClick}
                className="rounded-full border border-kar-border p-2.5 text-kar-muted hover:bg-kar-surface lg:hidden"
            >
                <Menu size={20} />
            </button>

            <p className="hidden text-sm text-kar-muted lg:block">
                <CurrentDateLabel />
            </p>

            <div className="ml-auto flex items-center gap-3">
                <button type="button" onClick={toggleTheme} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`} title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`} className="grid size-10 place-items-center rounded-xl border border-kar-border bg-kar-surface text-kar-muted transition hover:text-kar-text">
                    {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
                </button>
                <NotificationBell />
                <UserMenu admin={admin} />
            </div>
        </header>
    );
}