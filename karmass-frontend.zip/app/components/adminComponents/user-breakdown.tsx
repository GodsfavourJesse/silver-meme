import { formatNumber } from "@/app/lib/admin/format";
import type { AdminDashboardData } from "@/app/types/admin/admin-dashboard.types";

import { Panel } from "./panel";

const RADIUS = 52;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export function UserBreakdown({ data }: { data: AdminDashboardData }) {
    const { total, active, suspended } = data.users;

    const other = Math.max(total - active - suspended, 0);

    const segments = [
        { label: "Active", value: active, stroke: "var(--color-kar-accent)" },
        { label: "Suspended", value: suspended, stroke: "#fbbf24" },
        { label: "Deleted", value: other, stroke: "var(--color-kar-border)" },
    ];

    let offset = 0;

    return (
        <Panel title="Community" eyebrow="Accounts">
            <div className="flex items-center gap-6">
                <div className="relative h-36 w-36 shrink-0">
                    <svg
                        viewBox="0 0 128 128"
                        className="h-full w-full -rotate-90"
                        role="img"
                        aria-label="User status distribution"
                    >
                        <circle
                            cx="64"
                            cy="64"
                            r={RADIUS}
                            fill="none"
                            stroke="var(--color-kar-border)"
                            strokeWidth="12"
                            opacity="0.4"
                        />

                        {segments.map((segment) => {
                            const length =
                                total > 0
                                    ? (segment.value / total) * CIRCUMFERENCE
                                    : 0;

                            const circle = (
                                <circle
                                    key={segment.label}
                                    cx="64"
                                    cy="64"
                                    r={RADIUS}
                                    fill="none"
                                    stroke={segment.stroke}
                                    strokeWidth="12"
                                    strokeDasharray={`${length} ${CIRCUMFERENCE - length}`}
                                    strokeDashoffset={-offset}
                                />
                            );

                            offset += length;

                            return circle;
                        })}
                    </svg>

                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-2xl font-semibold tabular-nums">
                            {formatNumber(total)}
                        </span>

                        <span className="text-[11px] text-kar-muted">users</span>
                    </div>
                </div>

                <ul className="flex-1 space-y-3">
                    {segments.map((segment) => (
                        <li
                            key={segment.label}
                            className="flex items-center justify-between text-sm"
                        >
                            <span className="flex items-center gap-2 text-kar-muted">
                                <span
                                    className="h-2.5 w-2.5 rounded-full"
                                    style={{ background: segment.stroke }}
                                />
                                {segment.label}
                            </span>

                            <span className="font-semibold tabular-nums">
                                {formatNumber(segment.value)}
                            </span>
                        </li>
                    ))}
                </ul>
            </div>
        </Panel>
    );
}