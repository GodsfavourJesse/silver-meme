"use client";

import { useAdminSystemHealth } from "@/app/hooks/admin/use-admin-system-health";
import {
    formatMegabytes,
    formatUptime,
    timeAgo,
} from "@/app/lib/admin/format";

import { Panel } from "./panel";

function Row({ label, value }: { label: string; value: string }) {
    return (
        <div className="flex items-center justify-between py-2.5 text-sm">
            <span className="text-kar-muted">{label}</span>

            <span className="font-medium">{value}</span>
        </div>
    );
}

export function SystemHealthCard() {
    const { data, isPending, isError } = useAdminSystemHealth();

    const healthy = data?.status === "healthy";

    const heapPercent = data
        ? Math.min(
              100,
              (data.runtime.memory.heapUsedBytes /
                  Math.max(data.runtime.memory.heapTotalBytes, 1)) *
                  100,
          )
        : 0;

    return (
        <Panel
            title="System health"
            eyebrow="Live"
            className="h-full"
            action={
                data ? (
                    <span
                        className={`flex items-center gap-2 rounded-full px-3 py-1 text-xs font-medium ${
                            healthy
                                ? "bg-emerald-400/10 text-emerald-300"
                                : "bg-red-400/10 text-red-300"
                        }`}
                    >
                        <span className="relative flex h-2 w-2">
                            <span
                                className={`absolute inline-flex h-full w-full animate-ping rounded-full opacity-60 ${
                                    healthy ? "bg-emerald-400" : "bg-red-400"
                                }`}
                            />

                            <span
                                className={`relative inline-flex h-2 w-2 rounded-full ${
                                    healthy ? "bg-emerald-400" : "bg-red-400"
                                }`}
                            />
                        </span>

                        {healthy ? "All systems normal" : "Degraded"}
                    </span>
                ) : null
            }
        >
            {isPending ? (
                <div className="space-y-3">
                    {[0, 1, 2, 3].map((index) => (
                        <div
                            key={index}
                            className="h-8 animate-pulse rounded-xl bg-kar-surface-raised"
                        />
                    ))}
                </div>
            ) : null}

            {isError ? (
                <p className="text-sm text-red-300">
                    Health status could not be retrieved.
                </p>
            ) : null}

            {data ? (
                <>
                    <div className="divide-y divide-kar-border/60">
                        <Row
                            label="Database"
                            value={
                                data.database.status === "healthy"
                                    ? "Connected"
                                    : "Unavailable"
                            }
                        />

                        <Row
                            label="Uptime"
                            value={formatUptime(data.uptimeSeconds)}
                        />

                        <Row label="Environment" value={data.environment} />

                        <Row label="Node" value={data.runtime.nodeVersion} />
                    </div>

                    <div className="mt-4">
                        <div className="mb-2 flex justify-between text-xs text-kar-muted">
                            <span>Memory (heap)</span>

                            <span>
                                {formatMegabytes(
                                    data.runtime.memory.heapUsedBytes,
                                )}{" "}
                                /{" "}
                                {formatMegabytes(
                                    data.runtime.memory.heapTotalBytes,
                                )}
                            </span>
                        </div>

                        <div className="h-1.5 overflow-hidden rounded-full bg-kar-border/60">
                            <div
                                className="h-full rounded-full bg-linear-to-r from-kar-royal to-kar-accent"
                                style={{ width: `${heapPercent}%` }}
                            />
                        </div>
                    </div>

                    <p className="mt-4 text-[11px] text-kar-muted/70">
                        Checked {timeAgo(data.checkedAt)}
                    </p>
                </>
            ) : null}
        </Panel>
    );
}