"use client";

import { Mail, ShieldCheck } from "lucide-react";
import { useAdminLoginForm } from "@/app/hooks/admin/admin-auth/use-admin-login-form";
import { AdminSecurityChallengeModal } from "./admin-security-challenge-modal";
import { LoginErrorAlert } from "./login-error-alert";
import { LoginField } from "./login-field";
import { PasswordField } from "./password-field";
import { SubmitButton } from "./submit-button";
import { AdminLoginHero } from "./admin-login-hero";

export function AdminLoginForm() {
    const {
        email,
        password,
        formError,
        isSubmitting,
        challengeOpen,
        updateEmail,
        updatePassword,
        handleSubmit,
        closeChallenge,
        handleChallengeComplete,
    } = useAdminLoginForm();

    return (
        <>
            <section className="w-full rounded-[28px] border border-kar-accent/30 bg-linear-to-br from-kar-surface to-kar-bg p-7 shadow-2xl shadow-black/40 sm:p-8">
                <AdminLoginHero />

                {formError ? <LoginErrorAlert message={formError} /> : null}

                <form onSubmit={handleSubmit} className="space-y-5">
                    <LoginField
                        id="admin-email"
                        name="email"
                        label="Administrator email"
                        icon={<Mail size={19} />}
                        type="email"
                        autoComplete="username"
                        inputMode="email"
                        placeholder="admin@example.com"
                        value={email}
                        onChange={(event) => updateEmail(event.target.value)}
                        required
                        autoFocus
                        maxLength={254}
                        disabled={isSubmitting || challengeOpen}
                    />

                    <PasswordField
                        value={password}
                        onChange={updatePassword}
                        disabled={isSubmitting || challengeOpen}
                    />

                    <div className="pt-2">
                        <SubmitButton isSubmitting={isSubmitting} />
                    </div>
                </form>

                <p className="mt-6 flex items-center justify-center gap-2 text-center text-xs text-kar-muted">
                    <ShieldCheck size={15} className="shrink-0 text-kar-accent" />
                    Protected session, verified by the KARMASS backend.
                </p>
            </section>

            <AdminSecurityChallengeModal
                open={challengeOpen}
                onClose={closeChallenge}
                onComplete={handleChallengeComplete}
            />
        </>
    );
}
