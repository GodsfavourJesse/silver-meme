import type { ReactNode } from "react";

interface PanelProps {
    title: string;
    eyebrow?: string;
    action?: ReactNode;
    children: ReactNode;
    className?: string;
}

export function Panel({
    title,
    eyebrow,
    action,
    children,
    className = "",
}: PanelProps) {
    return (
        <section
            className={`rounded-3xl border border-kar-border bg-linear-to-br from-kar-surface to-kar-bg p-6 ${className}`}
        >
            <div className="mb-5 flex items-start justify-between gap-4">
                <div>
                    {eyebrow ? (
                        <p className="text-[10px] font-medium uppercase tracking-[0.3em] text-kar-accent">
                            {eyebrow}
                        </p>
                    ) : null}

                    <h2 className="mt-1 text-lg font-semibold">{title}</h2>
                </div>

                {action}
            </div>

            {children}
        </section>
    );
}