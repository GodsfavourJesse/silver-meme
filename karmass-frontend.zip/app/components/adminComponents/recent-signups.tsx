"use client";

import Link from "next/link";

import { useAdminRecentUsers } from "@/app/hooks/admin/use-admin-recent-users";
import { fullName, initialsOf, timeAgo } from "@/app/lib/admin/format";
import { Panel } from "./panel";
import { ADMIN_BASE_PATH } from "@/app/lib/admin/path";

const DAY_IN_MS = 24 * 60 * 60 * 1000;

export function RecentSignups() {
    const { data, isPending, isError } = useAdminRecentUsers();

    return (
        <Panel
            title="Recent sign-ups"
            eyebrow="New members"
            action={
                <Link
                    href={`${ADMIN_BASE_PATH}/users`}
                    className="text-xs text-kar-accent transition hover:text-kar-text"
                >
                    View all
                </Link>
            }
        >
            {isPending ? (
                <div className="space-y-3">
                    {[0, 1, 2, 3].map((index) => (
                        <div
                            key={index}
                            className="h-12 animate-pulse rounded-2xl bg-kar-surface-raised"
                        />
                    ))}
                </div>
            ) : null}

            {isError ? (
                <p className="text-sm text-red-300">
                    Recent users could not be loaded.
                </p>
            ) : null}

            {data && data.length === 0 ? (
                <p className="py-6 text-center text-sm text-kar-muted">
                    No users have signed up yet.
                </p>
            ) : null}

            {data && data.length > 0 ? (
                <ul className="space-y-1">
                    {data.map((user) => {
                        const isNew =
                            Date.now() - new Date(user.createdAt).getTime() <
                            DAY_IN_MS;

                        return (
                            <li key={user.id}>
                                <Link
                                    href={`${ADMIN_BASE_PATH}/users/${user.id}`}
                                    className="flex items-center gap-3 rounded-2xl px-2 py-2.5 transition hover:bg-kar-surface-raised/60"
                                >
                                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-kar-royal/25 text-xs font-semibold text-kar-accent">
                                        {initialsOf(
                                            user.firstName,
                                            user.lastName,
                                        )}
                                    </span>

                                    <span className="min-w-0 flex-1">
                                        <span className="flex items-center gap-2">
                                            <span className="truncate text-sm font-medium">
                                                {fullName(
                                                    user.firstName,
                                                    user.lastName,
                                                )}
                                            </span>

                                            {isNew ? (
                                                <span className="rounded-full bg-kar-accent/15 px-2 py-0.5 text-[10px] font-semibold text-kar-accent">
                                                    NEW
                                                </span>
                                            ) : null}
                                        </span>

                                        <span className="block truncate text-xs text-kar-muted">
                                            {user.email}
                                        </span>
                                    </span>

                                    <span className="shrink-0 text-right">
                                        <span className="block text-[11px] text-kar-muted">
                                            {timeAgo(user.createdAt)}
                                        </span>

                                        <span className="block text-[10px] uppercase tracking-wider text-kar-muted/70">
                                            {user.accountType}
                                        </span>
                                    </span>
                                </Link>
                            </li>
                        );
                    })}
                </ul>
            ) : null}
        </Panel>
    );
}