import {
    Car,
    Crown,
    Rocket,
    Users,
    type LucideIcon,
} from "lucide-react";

import { formatNumber } from "@/app/lib/admin/format";
import type { AdminDashboardData } from "@/app/types/admin/admin-dashboard.types";

interface Kpi {
    label: string;
    value: number;
    detail: string;
    icon: LucideIcon;
}

export function KpiGrid({ data }: { data: AdminDashboardData }) {
    const kpis: Kpi[] = [
        {
            label: "Total users",
            value: data.users.total,
            detail: `${formatNumber(data.users.active)} active`,
            icon: Users,
        },
        {
            label: "Approved listings",
            value: data.listings.approved,
            detail: `of ${formatNumber(data.listings.total)} total`,
            icon: Car,
        },
        {
            label: "Active subscriptions",
            value: data.subscriptions.active,
            detail: "currently running",
            icon: Crown,
        },
        {
            label: "Active boosts",
            value: data.boosts.active,
            detail: `${formatNumber(data.boosts.pendingApproval)} awaiting approval`,
            icon: Rocket,
        },
    ];

    return (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {kpis.map((kpi) => {
                const Icon = kpi.icon;

                return (
                    <div
                        key={kpi.label}
                        className="rounded-3xl border border-kar-border bg-kar-surface p-5 transition hover:border-kar-accent/40"
                    >
                        <div className="flex items-center justify-between">
                            <p className="text-sm text-kar-muted">{kpi.label}</p>

                            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-kar-royal/20 text-kar-accent">
                                <Icon size={17} />
                            </span>
                        </div>

                        <p className="mt-4 text-4xl font-semibold tracking-tight tabular-nums">
                            {formatNumber(kpi.value)}
                        </p>

                        <p className="mt-1 text-xs text-kar-muted">
                            {kpi.detail}
                        </p>
                    </div>
                );
            })}
        </div>
    );
}