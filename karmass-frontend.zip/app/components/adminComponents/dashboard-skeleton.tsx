export function DashboardSkeleton() {
    return (
        <div aria-busy="true" className="space-y-6">
            <div className="grid gap-6 xl:grid-cols-5">
                <div className="h-96 animate-pulse rounded-3xl bg-kar-surface xl:col-span-3" />

                <div className="h-96 animate-pulse rounded-3xl bg-kar-surface xl:col-span-2" />
            </div>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {[0, 1, 2, 3].map((index) => (
                    <div
                        key={index}
                        className="h-36 animate-pulse rounded-3xl bg-kar-surface"
                    />
                ))}
            </div>
        </div>
    );
}