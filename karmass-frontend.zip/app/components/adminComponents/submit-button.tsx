import { LoaderCircle, LockKeyhole } from "lucide-react";

interface SubmitButtonProps {
    isSubmitting: boolean;
}

export function SubmitButton({ isSubmitting }: SubmitButtonProps) {
    return (
        <button
            type="submit"
            disabled={isSubmitting}
            className="flex h-14 w-full items-center justify-center gap-2 rounded-full bg-kar-royal px-6 font-semibold text-white shadow-lg shadow-kar-royal/30 transition hover:bg-kar-royal-hover focus:outline-none focus:ring-4 focus:ring-kar-accent/40 disabled:cursor-not-allowed disabled:opacity-70"
        >
            {isSubmitting ? (
                <>
                    <LoaderCircle size={19} className="animate-spin" />

                    <span>Verifying credentials...</span>
                </>
            ) : (
                <>
                    <LockKeyhole size={18} />

                    <span>Sign in securely</span>
                </>
            )}
        </button>
    );
}