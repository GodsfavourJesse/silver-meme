import { AlertCircle } from "lucide-react";

interface LoginErrorAlertProps {
    message: string;
}

export function LoginErrorAlert({ message }: LoginErrorAlertProps) {
    return (
        <div
            role="alert"
            aria-live="polite"
            className="mb-5 flex items-start gap-3 rounded-2xl border border-red-400/30 bg-red-500/10 p-4 text-sm leading-6 text-red-200"
        >
            <AlertCircle size={19} className="mt-0.5 shrink-0" />

            <p>{message}</p>
        </div>
    );
}