"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { X } from "lucide-react";

import { ADMIN_NAV } from "./admin-nav";
import { CurrentYear } from "./utils/current-year";
import { useAdminDashboard } from "@/app/hooks/admin/admin-dashboard/use-admin-dashboard";

interface AdminSidebarProps {
    open: boolean;
    onClose: () => void;
}

export function AdminSidebar({ open, onClose }: AdminSidebarProps) {
    const pathname = usePathname();
    const dashboard = useAdminDashboard();

    return (
        <>
            {open ? (
                <button
                    type="button"
                    aria-label="Close menu"
                    onClick={onClose}
                    className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm lg:hidden"
                />
            ) : null}

            <aside
                className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r border-kar-border bg-kar-surface transition-transform duration-200 lg:translate-x-0 ${
                    open ? "translate-x-0" : "-translate-x-full"
                }`}
            >
                <div className="flex h-[72px] items-center justify-between px-6">
                    <div>
                        <p className="text-lg font-bold tracking-[0.3em] text-kar-accent">
                            KARMASS
                        </p>

                        <p className="text-[10px] font-medium tracking-[0.4em] text-kar-muted">
                            ADMINISTRATION
                        </p>
                    </div>

                    <button
                        type="button"
                        aria-label="Close menu"
                        onClick={onClose}
                        className="rounded-full p-2 text-kar-muted hover:bg-kar-surface-raised lg:hidden"
                    >
                        <X size={18} />
                    </button>
                </div>

                <nav className="flex-1 space-y-7 overflow-y-auto px-3 py-4">
                    {ADMIN_NAV.map((group) => (
                        <div key={group.title}>
                            <p className="mb-2 px-3 text-[10px] font-medium uppercase tracking-[0.3em] text-kar-muted/70">
                                {group.title}
                            </p>

                            <ul className="space-y-1">
                                {group.items.map((item) => {
                                    const active =
                                        pathname === item.href ||
                                        pathname.startsWith(`${item.href}/`);

                                    const badge =
                                        item.badge && dashboard.data
                                            ? item.badge(dashboard.data)
                                            : 0;

                                    const Icon = item.icon;

                                    return (
                                        <li key={item.href}>
                                            <Link
                                                href={item.href}
                                                onClick={onClose}
                                                aria-current={
                                                    active ? "page" : undefined
                                                }
                                                className={`flex items-center gap-3 rounded-full px-4 py-2.5 text-sm transition ${
                                                    active
                                                        ? "bg-kar-royal text-white shadow-lg shadow-kar-royal/25"
                                                        : "text-kar-muted hover:bg-kar-surface-raised hover:text-kar-text"
                                                }`}
                                            >
                                                <Icon size={18} />

                                                <span className="flex-1">
                                                    {item.label}
                                                </span>

                                                {badge > 0 ? (
                                                    <span
                                                        className={`min-w-6 rounded-full px-2 py-0.5 text-center text-[11px] font-semibold ${
                                                            active
                                                                ? "bg-white/20 text-white"
                                                                : "bg-kar-accent/15 text-kar-accent"
                                                        }`}
                                                    >
                                                        {badge > 99
                                                            ? "99+"
                                                            : badge}
                                                    </span>
                                                ) : null}
                                            </Link>
                                        </li>
                                    );
                                })}
                            </ul>
                        </div>
                    ))}
                </nav>

                <p className="px-6 py-5 text-[11px] text-kar-muted/60">
                    © <CurrentYear /> KARMASS
                </p>
            </aside>
        </>
    );
}