import type { InputHTMLAttributes, ReactNode } from "react";

interface LoginFieldProps extends InputHTMLAttributes<HTMLInputElement> {
    id: string;
    label: string;
    icon: ReactNode;
    trailing?: ReactNode;
    hint?: ReactNode;
}

export function LoginField({
    id,
    label,
    icon,
    trailing,
    hint,
    ...inputProps
}: LoginFieldProps) {
    return (
        <div>
            <label
                htmlFor={id}
                className="mb-2 block text-sm font-medium text-kar-text"
            >
                {label}
            </label>

            <div className="relative">
                <span
                    aria-hidden="true"
                    className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-kar-muted"
                >
                    {icon}
                </span>

                <input
                    id={id}
                    {...inputProps}
                    className={`h-12 w-full rounded-xl border border-kar-border bg-kar-surface pl-12 text-sm text-kar-text outline-none transition placeholder:text-kar-muted/60 hover:border-kar-accent/40 focus:border-kar-accent focus:ring-4 focus:ring-kar-royal/25 disabled:cursor-not-allowed disabled:opacity-60 ${
                        trailing ? "pr-14" : "pr-4"
                    }`}
                />

                {trailing ? (
                    <div className="absolute right-2 top-1/2 -translate-y-1/2">
                        {trailing}
                    </div>
                ) : null}
            </div>

            {hint ? <div className="mt-2">{hint}</div> : null}
        </div>
    );
}