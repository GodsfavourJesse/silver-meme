"use client";

import { RefreshCw, TriangleAlert } from "lucide-react";
import { useAdminSession } from "@/app/hooks/admin/use-admin-session";
import { ApiError } from "@/app/lib/api/api-error";
import { timeAgo } from "@/app/lib/admin/format";
import { UserBreakdown } from "./user-breakdown";
import { AdminAuthGuard } from "./admin-auth-guard";
import { useAdminDashboard } from "@/app/hooks/admin/admin-dashboard/use-admin-dashboard";
import { DashboardSkeleton } from "./dashboard-skeleton";
import { AttentionQueue } from "./attention-queue";
import { SystemHealthCard } from "./system-health-card";
import { KpiGrid } from "./kpi-grid";
import { ListingPipeline } from "./listing-pipeline";
import { RevenuePanel } from "./revenue-panel";
import { RecentSignups } from "./recent-signups";
import { useEffect, useState } from "react";

function getGreeting(): string {
    const hour = new Date().getHours();

    if (hour < 12) {
        return "Good morning";
    }

    if (hour < 17) {
        return "Good afternoon";
    }

    return "Good evening";
}

export function DashboardView() {
    const session = useAdminSession();
    const dashboard = useAdminDashboard();

    const firstName = session.data?.firstName;

    const [greeting, setGreeting] = useState("Welcome");

    useEffect(() => {
        setGreeting(getGreeting());
    }, []);

    return (
        <AdminAuthGuard>
            <div className="space-y-6">
                <header className="flex flex-wrap items-end justify-between gap-4">
                    <div>
                        <p className="text-[11px] font-medium uppercase tracking-[0.3em] text-kar-accent">
                            Command center
                        </p>

                        <h1 className="mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">
                            {greeting}
                            {firstName ? `, ${firstName}` : ""}.
                        </h1>

                        <p className="mt-2 text-sm text-kar-muted">
                            Here is what is happening on KARMASS right now.
                        </p>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-kar-muted">
                        {dashboard.data ? (
                            <span>
                                Updated {timeAgo(dashboard.data.generatedAt)}
                            </span>
                        ) : null}

                        <button
                            type="button"
                            onClick={() => dashboard.refetch()}
                            disabled={dashboard.isFetching}
                            className="flex items-center gap-2 rounded-full border border-kar-border bg-kar-surface px-4 py-2 text-sm text-kar-text transition hover:border-kar-accent/50 disabled:opacity-60"
                        >
                            <RefreshCw
                                size={15}
                                className={dashboard.isFetching ? "animate-spin" : ""}
                            />
                            Refresh
                        </button>
                    </div>
                </header>

                {dashboard.isPending ? <DashboardSkeleton /> : null}

                {dashboard.isError ? (
                    <div className="flex items-start gap-3 rounded-2xl border border-red-400/30 bg-red-500/10 p-5 text-sm text-red-200">
                        <TriangleAlert size={19} className="mt-0.5 shrink-0" />

                        <div>
                            <p className="font-medium">
                                The dashboard could not be loaded.
                            </p>

                            <p className="mt-1 text-red-200/80">
                                {dashboard.error.message}
                            </p>

                            {dashboard.error instanceof ApiError && dashboard.error.requestId ? (
                                <p className="mt-2 text-xs text-red-200/60">
                                    Reference: {dashboard.error.requestId}
                                </p>
                            ) : null}

                            <button
                                type="button"
                                onClick={() => void dashboard.refetch()}
                                disabled={dashboard.isFetching}
                                className="mt-4 inline-flex items-center gap-2 rounded-full border border-red-200/30 px-4 py-2 font-medium text-red-100 transition hover:bg-red-500/10 disabled:cursor-not-allowed disabled:opacity-60"
                            >
                                <RefreshCw
                                    size={14}
                                    className={dashboard.isFetching ? "animate-spin" : ""}
                                />
                                {dashboard.isFetching ? "Retrying…" : "Try again"}
                            </button>
                        </div>
                    </div>
                ) : null}

                {dashboard.data ? (
                    <>
                        <div className="grid gap-6 xl:grid-cols-5">
                            <div className="xl:col-span-3">
                                <AttentionQueue data={dashboard.data} />
                            </div>

                            <div className="xl:col-span-2">
                                <SystemHealthCard />
                            </div>
                        </div>

                        <KpiGrid data={dashboard.data} />

                        <div className="grid gap-6 lg:grid-cols-5">
                            <div className="space-y-6 lg:col-span-3">
                                <ListingPipeline data={dashboard.data} />

                                <RevenuePanel data={dashboard.data} />
                            </div>

                            <div className="space-y-6 lg:col-span-2">
                                <UserBreakdown data={dashboard.data} />

                                <RecentSignups />
                            </div>
                        </div>
                    </>
                ) : null}
            </div>
        </AdminAuthGuard>
    );
}