import { formatNumber } from "@/app/lib/admin/format";
import type { AdminDashboardData } from "@/app/types/admin/admin-dashboard.types";

import { Panel } from "./panel";

export function ListingPipeline({ data }: { data: AdminDashboardData }) {
    const { listings } = data;

    const segments = [
        { label: "Approved", value: listings.approved, color: "bg-kar-accent" },
        { label: "Pending review", value: listings.pending, color: "bg-kar-royal" },
        { label: "Rejected", value: listings.rejected, color: "bg-red-400" },
        { label: "Suspended", value: listings.suspended, color: "bg-amber-400" },
    ];

    const counted = segments.reduce((sum, segment) => sum + segment.value, 0);

    return (
        <Panel title="Listing pipeline" eyebrow="Marketplace">
            <div className="flex items-end gap-3">
                <span className="text-4xl font-semibold tabular-nums">
                    {formatNumber(listings.total)}
                </span>

                <span className="pb-1 text-sm text-kar-muted">
                    listings in total
                </span>
            </div>

            <div
                role="img"
                aria-label="Listing status distribution"
                className="mt-5 flex h-3 overflow-hidden rounded-full bg-kar-border/60"
            >
                {segments.map((segment) =>
                    segment.value > 0 ? (
                        <div
                            key={segment.label}
                            className={`${segment.color} transition-all duration-700`}
                            style={{
                                width: `${(segment.value / Math.max(counted, 1)) * 100}%`,
                            }}
                        />
                    ) : null,
                )}
            </div>

            <ul className="mt-5 grid gap-3 sm:grid-cols-2">
                {segments.map((segment) => (
                    <li
                        key={segment.label}
                        className="flex items-center justify-between rounded-2xl bg-kar-surface-raised/50 px-4 py-3"
                    >
                        <span className="flex items-center gap-3 text-sm text-kar-muted">
                            <span
                                className={`h-2.5 w-2.5 rounded-full ${segment.color}`}
                            />
                            {segment.label}
                        </span>

                        <span className="text-sm font-semibold tabular-nums">
                            {formatNumber(segment.value)}
                        </span>
                    </li>
                ))}
            </ul>
        </Panel>
    );
}