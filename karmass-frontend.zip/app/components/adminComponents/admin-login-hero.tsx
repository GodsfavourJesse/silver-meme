function CarLine() {
    return (
        <svg
            viewBox="0 0 120 40"
            width="150"
            height="50"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
        >
            <path d="M6 31h108M14 31l6-12c2-4 6-6 10-6h40c5 0 9 2 12 6l8 8 14 4" />
            <circle cx="34" cy="32" r="6" />
            <circle cx="90" cy="32" r="6" />
        </svg>
    );
}

export function AdminLoginHero() {
    return (
        <div className="mb-7 flex flex-col gap-3">
            <p className="text-[11px] font-medium uppercase tracking-[0.3em] text-kar-accent">
                Restricted access
            </p>

            <h1 className="text-[2rem] font-semibold leading-[1.1] tracking-tight">
                Administrator
                <br />
                sign in
            </h1>

            <div className="flex items-end justify-between gap-4">
                <p className="max-w-[14rem] text-sm leading-6 text-kar-muted">
                    Use your authorized administrator credentials to continue.
                </p>

                <span className="text-kar-accent">
                    <CarLine />
                </span>
            </div>
        </div>
    );
}