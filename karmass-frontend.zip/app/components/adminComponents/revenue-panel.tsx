import { formatMoney, formatNumber } from "@/app/lib/admin/format";
import type {
    AdminDashboardData,
    CurrencyAmount,
} from "@/app/types/admin/admin-dashboard.types";

import { Panel } from "./panel";

function AmountList({ amounts }: { amounts: CurrencyAmount[] }) {
    if (amounts.length === 0) {
        return <p className="text-3xl font-semibold text-kar-muted">None yet</p>;
    }

    return (
        <ul className="space-y-1">
            {amounts.map((entry) => (
                <li
                    key={entry.currency}
                    className="text-3xl font-semibold tracking-tight tabular-nums"
                >
                    {formatMoney(entry.amount, entry.currency)}
                </li>
            ))}
        </ul>
    );
}

export function RevenuePanel({ data }: { data: AdminDashboardData }) {
    const { revenue, payments } = data;

    return (
        <Panel title="Revenue" eyebrow="Gross successful payments">
            <div className="grid gap-6 sm:grid-cols-2">
                <div>
                    <p className="mb-2 text-sm text-kar-muted">This month</p>

                    <AmountList
                        amounts={
                            revenue.grossSuccessfulPaymentsThisMonthByCurrency
                        }
                    />
                </div>

                <div>
                    <p className="mb-2 text-sm text-kar-muted">All time</p>

                    <AmountList
                        amounts={revenue.grossSuccessfulPaymentsByCurrency}
                    />
                </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3">
                <div className="rounded-2xl bg-kar-surface-raised/50 px-4 py-3">
                    <p className="text-xs text-kar-muted">Successful payments</p>

                    <p className="mt-1 text-lg font-semibold tabular-nums">
                        {formatNumber(revenue.successfulPaymentCount)}
                    </p>
                </div>

                <div className="rounded-2xl bg-kar-surface-raised/50 px-4 py-3">
                    <p className="text-xs text-kar-muted">Failed payments</p>

                    <p className="mt-1 text-lg font-semibold tabular-nums">
                        {formatNumber(payments.failed)}
                    </p>
                </div>
            </div>

            <p className="mt-5 text-xs leading-5 text-kar-muted/80">
                {revenue.note}
            </p>
        </Panel>
    );
}