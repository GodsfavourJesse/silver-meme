import Link from "next/link";

import {
    Car,
    CircleCheck,
    CreditCard,
    Flag,
    Rocket,
    ScanEye,
    Store,
    type LucideIcon,
} from "lucide-react";

import { formatNumber } from "@/app/lib/admin/format";
import type { AdminDashboardData } from "@/app/types/admin/admin-dashboard.types";
import { ADMIN_BASE_PATH } from "@/app/lib/admin/path";

interface QueueItem {
    label: string;
    description: string;
    count: number;
    href: string;
    icon: LucideIcon;
}

function buildQueue(data: AdminDashboardData): QueueItem[] {
    return [
        {
            label: "Listings awaiting review",
            description: "Approve or reject new listings",
            count: data.moderation.pendingListings,
            href: `${ADMIN_BASE_PATH}/listings`,
            icon: Car,
        },
        {
            label: "Dealer applications",
            description: "Verify businesses applying as dealers",
            count: data.dealers.pendingApplications,
            href: `${ADMIN_BASE_PATH}/dealers`,
            icon: Store,
        },
        {
            label: "Boosts to approve",
            description: "Boost requests waiting for approval",
            count: data.boosts.pendingApproval,
            href: `${ADMIN_BASE_PATH}/boosts`,
            icon: Rocket,
        },
        {
            label: "Images to check",
            description: "Photos flagged for manual review",
            count: data.moderation.pendingOrReviewImages,
            href: `${ADMIN_BASE_PATH}/image-review`,
            icon: ScanEye,
        },
        {
            label: "Reports to review",
            description: "Listings reported by users",
            count: data.moderation.pendingReports,
            href: `${ADMIN_BASE_PATH}/listings`,
            icon: Flag,
        },
        {
            label: "Refunds in progress",
            description: "Refund requests not yet settled",
            count: data.refunds.pendingOrProcessing,
            href: `${ADMIN_BASE_PATH}/payments`,
            icon: CreditCard,
        },
    ].sort((a, b) => b.count - a.count);
}

export function AttentionQueue({ data }: { data: AdminDashboardData }) {
    const queue = buildQueue(data);
    const total = queue.reduce((sum, item) => sum + item.count, 0);
    const max = Math.max(...queue.map((item) => item.count), 1);

    return (
        <section className="relative h-full overflow-hidden rounded-3xl border border-kar-accent/30 bg-linear-to-br from-kar-surface to-kar-bg p-6">
            <div
                aria-hidden="true"
                className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-kar-royal/30 blur-3xl"
            />

            <div className="relative">
                <p className="text-[10px] font-medium uppercase tracking-[0.3em] text-kar-accent">
                    Attention queue
                </p>

                <div className="mt-2 flex items-end gap-3">
                    <span className="text-6xl font-semibold leading-none tracking-tight">
                        {formatNumber(total)}
                    </span>

                    <span className="pb-1 text-sm text-kar-muted">
                        {total === 1 ? "item needs" : "items need"} you
                    </span>
                </div>

                {total === 0 ? (
                    <div className="mt-8 flex items-center gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-400/10 p-4 text-sm text-emerald-200">
                        <CircleCheck size={20} />
                        Everything is reviewed. Nothing is waiting on you.
                    </div>
                ) : (
                    <ul className="mt-6 space-y-2">
                        {queue.map((item) => {
                            const Icon = item.icon;
                            const empty = item.count === 0;

                            return (
                                <li key={item.label}>
                                    <Link
                                        href={item.href}
                                        className={`group flex items-center gap-4 rounded-2xl border border-transparent px-3 py-3 transition hover:border-kar-border hover:bg-kar-surface-raised/60 ${
                                            empty ? "opacity-45" : ""
                                        }`}
                                    >
                                        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-kar-royal/20 text-kar-accent">
                                            <Icon size={18} />
                                        </span>

                                        <span className="min-w-0 flex-1">
                                            <span className="flex items-baseline justify-between gap-3">
                                                <span className="truncate text-sm font-medium">
                                                    {item.label}
                                                </span>

                                                <span className="text-sm font-semibold tabular-nums">
                                                    {formatNumber(item.count)}
                                                </span>
                                            </span>

                                            <span className="mt-0.5 block truncate text-xs text-kar-muted">
                                                {item.description}
                                            </span>

                                            <span className="mt-2 block h-1.5 overflow-hidden rounded-full bg-kar-border/60">
                                                <span
                                                    className="block h-full rounded-full bg-linear-to-r from-kar-royal to-kar-accent transition-all duration-700"
                                                    style={{
                                                        width: `${(item.count / max) * 100}%`,
                                                    }}
                                                />
                                            </span>
                                        </span>
                                    </Link>
                                </li>
                            );
                        })}
                    </ul>
                )}
            </div>
        </section>
    );
}