"use client";

import {
    type FormEvent,
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";

import {
    useRouter,
    useSearchParams,
} from "next/navigation";

import {
    ArrowLeft,
    CheckCheck,
    LoaderCircle,
    MessageCircle,
    RefreshCw,
    Send,
} from "lucide-react";

import {
    ApiError,
} from "@/app/lib/api/api-error";

import {
    getSafeReturnTo,
} from "@/app/lib/user/auth/safe-redirect";

import {
    useAuth,
} from "@/app/hooks/user/auth/useAuth";

import {
    getMessagingConversations,
    getConversationMessages,
    markConversationAsRead,
    sendConversationMessage,
} from "@/app/services/user/messaging/messaging.service";

import type {
    MessagingConversation,
    MessagingMessage,
    MessagingParticipant,
} from "@/app/types/user/messaging.types";

const MAX_MESSAGE_LENGTH = 5000;

function formatConversationDate(
    value: string,
): string {
    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "";
    }

    const now = new Date();

    const sameDay =
        date.getFullYear() === now.getFullYear()
        && date.getMonth() === now.getMonth()
        && date.getDate() === now.getDate();

    if (sameDay) {
        return new Intl.DateTimeFormat(
            "en-NG",
            {
                hour: "2-digit",
                minute: "2-digit",
            },
        ).format(date);
    }

    const sameYear =
        date.getFullYear() === now.getFullYear();

    return new Intl.DateTimeFormat(
        "en-NG",
        {
            day: "numeric",
            month: "short",
            ...(sameYear ? {} : { year: "numeric" }),
        },
    ).format(date);
}

function formatMessageTime(
    value: string,
): string {
    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "";
    }

    return new Intl.DateTimeFormat(
        "en-NG",
        {
            hour: "2-digit",
            minute: "2-digit",
        },
    ).format(date);
}

function getOtherParticipant(
    conversation: MessagingConversation,
    currentUserId: string | null,
): MessagingParticipant | null {
    if (!currentUserId) {
        return conversation.participants[0] ?? null;
    }

    return (
        conversation.participants.find(
            (participant) =>
                participant.userId !== currentUserId,
        ) ?? null
    );
}

function getConversationName(
    conversation: MessagingConversation,
    currentUserId: string | null,
): string {
    const participant = getOtherParticipant(
        conversation,
        currentUserId,
    );

    if (!participant) {
        return conversation.type === "SUPPORT"
            ? "KARMASS Support"
            : "Conversation";
    }

    const name = [
        participant.firstName,
        participant.lastName,
    ]
        .filter(Boolean)
        .join(" ")
        .trim();

    if (name) {
        return name;
    }

    return conversation.type === "SUPPORT"
        ? "KARMASS Support"
        : "KARMASS User";
}

function getInitials(
    name: string,
): string {
    return name
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 2)
        .map((part) => part.charAt(0).toUpperCase())
        .join("");
}

function getErrorMessage(
    error: unknown,
): string {
    if (error instanceof ApiError) {
        if (error.status === 401) {
            return "Your session has expired. Please sign in again.";
        }

        if (error.status === 403) {
            return "You do not have permission to access this conversation.";
        }

        if (error.status === 404) {
            return "This conversation could not be found.";
        }

        if (error.status >= 500) {
            return "The messaging service is temporarily unavailable. Please try again.";
        }
    }

    return error instanceof Error
        ? error.message
        : "Something went wrong. Please try again.";
}

function isAuthenticationError(
    error: unknown,
): boolean {
    return (
        error instanceof ApiError
        && error.status === 401
    );
}

function getConversationReturnPath(
    conversationId: string | null,
): string {
    if (!conversationId) {
        return "/messages";
    }

    const params = new URLSearchParams();

    params.set(
        "conversationId",
        conversationId,
    );

    return `/messages?${params.toString()}`;
}

function Avatar({
    participant,
    name,
    size = "normal",
}: {
    participant: MessagingParticipant | null;
    name: string;
    size?: "normal" | "large";
}) {
    const sizeClasses =
        size === "large"
            ? "h-11 w-11"
            : "h-11 w-11";

    if (participant?.avatarUrl) {
        return (
            <img
                src={participant.avatarUrl}
                alt=""
                loading="lazy"
                referrerPolicy="no-referrer"
                className={`${sizeClasses} shrink-0 rounded-full border border-white/[0.08] bg-white/[0.04] object-cover`}
            />
        );
    }

    return (
        <span
            aria-hidden="true"
            className={`flex ${sizeClasses} shrink-0 items-center justify-center rounded-full border border-[#c8ff00]/15 bg-[#c8ff00]/[0.08] text-sm font-bold text-[#c8ff00]`}
        >
            {getInitials(name) || "K"}
        </span>
    );
}

export function MessagesInbox() {
    const router = useRouter();
    const searchParams = useSearchParams();

    const { user } = useAuth();

    const currentUserId = user?.id ?? null;

    const requestedConversationId =
        searchParams.get("conversationId");

    const [conversations, setConversations] =
        useState<MessagingConversation[]>([]);

    const [messages, setMessages] =
        useState<MessagingMessage[]>([]);

    const [selectedConversationId, setSelectedConversationId] =
        useState<string | null>(
            requestedConversationId,
        );

    const [draft, setDraft] = useState("");

    const [loadingConversations, setLoadingConversations] =
        useState(true);

    const [loadingMessages, setLoadingMessages] =
        useState(false);

    const [sending, setSending] =
        useState(false);

    const [error, setError] =
        useState<string | null>(null);

    const [messageError, setMessageError] =
        useState<string | null>(null);

    const [mobileConversationOpen, setMobileConversationOpen] =
        useState(Boolean(requestedConversationId));

    const bottomRef = useRef<HTMLDivElement | null>(null);

    const messagesRequestId = useRef(0);

    const redirectingToLogin = useRef(false);

    const selectedConversation = useMemo(
        () =>
            conversations.find(
                (conversation) =>
                    conversation.id === selectedConversationId,
            ) ?? null,
        [
            conversations,
            selectedConversationId,
        ],
    );

    const redirectToLogin = useCallback(
        (conversationId: string | null) => {
            if (redirectingToLogin.current) {
                return;
            }

            redirectingToLogin.current = true;

            const returnTo = getSafeReturnTo(
                getConversationReturnPath(
                    conversationId,
                ),
            );

            router.replace(
                `/login?next=${encodeURIComponent(returnTo)}`,
            );
        },
        [router],
    );

    const loadConversations = useCallback(
        async (
            preferredId?: string | null,
        ) => {
            setLoadingConversations(true);
            setError(null);

            try {
                const response =
                    await getMessagingConversations({
                        page: 1,
                        limit: 50,
                    });

                const items =
                    response.data.conversations;

                setConversations(items);

                const preferred =
                    preferredId
                    ?? selectedConversationId
                    ?? requestedConversationId;

                if (
                    preferred
                    && items.some(
                        (conversation) =>
                            conversation.id === preferred,
                    )
                ) {
                    setSelectedConversationId(preferred);
                } else if (items.length > 0) {
                    setSelectedConversationId(
                        (current) => {
                            if (
                                current
                                && items.some(
                                    (conversation) =>
                                        conversation.id === current,
                                )
                            ) {
                                return current;
                            }

                            return items[0]!.id;
                        },
                    );
                } else {
                    setSelectedConversationId(null);
                }
            } catch (loadError) {
                if (isAuthenticationError(loadError)) {
                    redirectToLogin(
                        selectedConversationId
                        ?? requestedConversationId,
                    );

                    return;
                }

                setError(
                    getErrorMessage(loadError),
                );
            } finally {
                setLoadingConversations(false);
            }
        },
        [
            redirectToLogin,
            requestedConversationId,
            selectedConversationId,
        ],
    );

    useEffect(() => {
        void loadConversations(
            requestedConversationId,
        );
    }, [
        loadConversations,
        requestedConversationId,
    ]);

    useEffect(() => {
        if (!requestedConversationId) {
            return;
        }

        setSelectedConversationId(
            requestedConversationId,
        );

        setMobileConversationOpen(true);
    }, [
        requestedConversationId,
    ]);

    useEffect(() => {
        const requestId = ++messagesRequestId.current;

        if (!selectedConversationId) {
            setMessages([]);
            setLoadingMessages(false);
            setMessageError(null);

            return;
        }

        let cancelled = false;

        async function loadMessages() {
            setLoadingMessages(true);
            setMessageError(null);
            setMessages([]);

            try {
                const response =
                    await getConversationMessages(
                        selectedConversationId!,
                        {
                            page: 1,
                            limit: 100,
                        },
                    );

                if (
                    cancelled
                    || requestId !== messagesRequestId.current
                ) {
                    return;
                }

                setMessages(
                    response.data.messages,
                );

                try {
                    await markConversationAsRead(
                        selectedConversationId!,
                    );

                    if (
                        !cancelled
                        && requestId === messagesRequestId.current
                    ) {
                        setConversations((current) =>
                            current.map((conversation) =>
                                conversation.id === selectedConversationId
                                    ? {
                                        ...conversation,
                                        unreadCount: 0,
                                    }
                                    : conversation,
                            ),
                        );
                    }
                } catch (readError) {
                    if (isAuthenticationError(readError)) {
                        redirectToLogin(
                            selectedConversationId,
                        );
                    }

                    /*
                     * The conversation remains readable even if
                     * updating its read receipt fails.
                     */
                }
            } catch (loadError) {
                if (
                    cancelled
                    || requestId !== messagesRequestId.current
                ) {
                    return;
                }

                if (isAuthenticationError(loadError)) {
                    redirectToLogin(
                        selectedConversationId,
                    );

                    return;
                }

                setMessageError(
                    getErrorMessage(loadError),
                );
            } finally {
                if (
                    !cancelled
                    && requestId === messagesRequestId.current
                ) {
                    setLoadingMessages(false);
                }
            }
        }

        void loadMessages();

        return () => {
            cancelled = true;
        };
    }, [
        redirectToLogin,
        selectedConversationId,
    ]);

    useEffect(() => {
        bottomRef.current?.scrollIntoView({
            behavior: "smooth",
            block: "end",
        });
    }, [
        messages,
        loadingMessages,
    ]);

    function selectConversation(
        conversationId: string,
    ) {
        setSelectedConversationId(conversationId);
        setMobileConversationOpen(true);
        setMessageError(null);
        setDraft("");

        const params = new URLSearchParams(
            searchParams.toString(),
        );

        params.set(
            "conversationId",
            conversationId,
        );

        router.replace(
            `/messages?${params.toString()}`,
            {
                scroll: false,
            },
        );
    }

    async function handleSendMessage(
        event: FormEvent<HTMLFormElement>,
    ) {
        event.preventDefault();

        if (
            !selectedConversationId
            || !draft.trim()
            || sending
        ) {
            return;
        }

        const body = draft.trim();

        if (body.length > MAX_MESSAGE_LENGTH) {
            setMessageError(
                "Messages cannot exceed 5,000 characters.",
            );

            return;
        }

        setSending(true);
        setMessageError(null);

        try {
            const response =
                await sendConversationMessage(
                    selectedConversationId,
                    body,
                );

            const sentMessage =
                response.data.message;

            setMessages((current) => {
                if (
                    current.some(
                        (message) =>
                            message.id === sentMessage.id,
                    )
                ) {
                    return current;
                }

                return [
                    ...current,
                    sentMessage,
                ];
            });

            setDraft("");

            setConversations((current) =>
                current.map((conversation) =>
                    conversation.id === selectedConversationId
                        ? {
                            ...conversation,
                            lastMessage: {
                                id: sentMessage.id,
                                senderId: sentMessage.senderId,
                                body: sentMessage.body,
                                createdAt: sentMessage.createdAt,
                            },
                            updatedAt: sentMessage.createdAt,
                        }
                        : conversation,
                ),
            );

            void loadConversations(
                selectedConversationId,
            );
        } catch (sendError) {
            if (isAuthenticationError(sendError)) {
                redirectToLogin(
                    selectedConversationId,
                );

                return;
            }

            setMessageError(
                getErrorMessage(sendError),
            );
        } finally {
            setSending(false);
        }
    }

    return (
        <main className="min-h-screen bg-[#0a0912] px-3 py-5 text-white sm:px-6 sm:py-8">
            <div className="mx-auto max-w-7xl">
                <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
                    <div>
                        <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#c8ff00]">
                            KARMASS Dashboard
                        </p>

                        <h1 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                            Messages
                        </h1>

                        <p className="mt-2 max-w-xl text-sm leading-6 text-white/50">
                            Keep your vehicle enquiries and conversations in one place.
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={() =>
                            void loadConversations(
                                selectedConversationId,
                            )
                        }
                        disabled={loadingConversations}
                        className="inline-flex items-center gap-2 rounded-xl border border-white/[0.09] bg-white/[0.04] px-4 py-2.5 text-sm font-semibold text-white/80 transition hover:border-[#c8ff00]/25 hover:bg-white/[0.07] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <RefreshCw
                            size={16}
                            className={
                                loadingConversations
                                    ? "animate-spin"
                                    : ""
                            }
                        />

                        Refresh
                    </button>
                </div>

                {error && (
                    <div
                        role="alert"
                        className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-red-400/20 bg-red-500/[0.08] px-4 py-3 text-sm text-red-200"
                    >
                        <span>{error}</span>

                        {error.includes("sign in") && (
                            <button
                                type="button"
                                onClick={() =>
                                    redirectToLogin(
                                        selectedConversationId
                                        ?? requestedConversationId,
                                    )
                                }
                                className="font-bold text-[#c8ff00] underline underline-offset-4"
                            >
                                Sign in
                            </button>
                        )}

                        <button
                            type="button"
                            onClick={() =>
                                void loadConversations(
                                    selectedConversationId,
                                )
                            }
                            className="font-semibold text-white underline underline-offset-4"
                        >
                            Try again
                        </button>
                    </div>
                )}

                <section className="grid min-h-[680px] overflow-hidden rounded-2xl border border-white/[0.08] bg-[#111019] shadow-[0_20px_80px_rgba(0,0,0,0.2)] lg:grid-cols-[340px_minmax(0,1fr)]">
                    <aside
                        className={[
                            "min-w-0 border-r border-white/[0.08]",
                            mobileConversationOpen
                                ? "hidden lg:block"
                                : "block",
                        ].join(" ")}
                    >
                        <div className="border-b border-white/[0.08] px-5 py-4">
                            <div className="flex items-center justify-between gap-3">
                                <h2 className="font-bold text-white">
                                    Your conversations
                                </h2>

                                <span className="flex h-7 min-w-7 items-center justify-center rounded-full border border-white/[0.08] bg-white/[0.04] px-2 text-xs font-semibold text-white/65">
                                    {conversations.length}
                                </span>
                            </div>

                            <p className="mt-1 text-xs text-white/40">
                                Your buyer, seller and support chats.
                            </p>
                        </div>

                        {loadingConversations && conversations.length === 0 ? (
                            <div className="space-y-3 p-4">
                                {[1, 2, 3, 4].map((item) => (
                                    <div
                                        key={item}
                                        className="flex animate-pulse gap-3 rounded-xl p-3"
                                    >
                                        <div className="h-11 w-11 rounded-full bg-white/[0.06]" />

                                        <div className="flex-1 space-y-2">
                                            <div className="h-3 w-28 rounded bg-white/[0.08]" />

                                            <div className="h-3 w-full rounded bg-white/[0.04]" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : conversations.length === 0 ? (
                            <div className="px-6 py-16 text-center">
                                <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-[#c8ff00]/15 bg-[#c8ff00]/[0.06] text-[#c8ff00]">
                                    <MessageCircle size={27} />
                                </span>

                                <h3 className="mt-4 font-semibold text-white">
                                    No conversations yet
                                </h3>

                                <p className="mt-2 text-sm leading-6 text-white/45">
                                    Contact a seller from a vehicle details page to start a conversation.
                                </p>

                                <button
                                    type="button"
                                    onClick={() =>
                                        router.push("/marketplace")
                                    }
                                    className="mt-5 rounded-xl bg-[#c8ff00] px-4 py-2.5 text-sm font-bold text-[#0a0912] transition hover:bg-[#d7ff4d]"
                                >
                                    Browse vehicles
                                </button>
                            </div>
                        ) : (
                            <div className="max-h-[720px] overflow-y-auto p-2">
                                {conversations.map((conversation) => {
                                    const name =
                                        getConversationName(
                                            conversation,
                                            currentUserId,
                                        );

                                    const participant =
                                        getOtherParticipant(
                                            conversation,
                                            currentUserId,
                                        );

                                    const active =
                                        conversation.id ===
                                        selectedConversationId;

                                    return (
                                        <button
                                            key={conversation.id}
                                            type="button"
                                            onClick={() =>
                                                selectConversation(
                                                    conversation.id,
                                                )
                                            }
                                            aria-current={
                                                active
                                                    ? "true"
                                                    : undefined
                                            }
                                            className={[
                                                "mb-1 flex w-full items-start gap-3 rounded-xl p-3 text-left transition-colors",
                                                active
                                                    ? "bg-[#c8ff00]/[0.07] ring-1 ring-inset ring-[#c8ff00]/20"
                                                    : "hover:bg-white/[0.035]",
                                            ].join(" ")}
                                        >
                                            <Avatar
                                                participant={participant}
                                                name={name}
                                            />

                                            <span className="min-w-0 flex-1">
                                                <span className="flex items-center justify-between gap-2">
                                                    <span
                                                        className={[
                                                            "truncate text-sm font-bold",
                                                            active
                                                                ? "text-[#c8ff00]"
                                                                : "text-white",
                                                        ].join(" ")}
                                                    >
                                                        {name}
                                                    </span>

                                                    <span className="shrink-0 text-[10px] text-white/35">
                                                        {formatConversationDate(
                                                            conversation.updatedAt,
                                                        )}
                                                    </span>
                                                </span>

                                                <span
                                                    className={[
                                                        "mt-1 block truncate text-xs",
                                                        conversation.unreadCount > 0
                                                            ? "font-semibold text-white/80"
                                                            : "text-white/45",
                                                    ].join(" ")}
                                                >
                                                    {conversation.lastMessage?.body
                                                        ?? "No messages yet"}
                                                </span>

                                                <span className="mt-2 flex items-center justify-between gap-2">
                                                    <span className="text-[10px] font-semibold uppercase tracking-wider text-white/35">
                                                        {conversation.type === "SUPPORT"
                                                            ? "Support"
                                                            : "Buyer / Seller"}
                                                    </span>

                                                    {conversation.unreadCount > 0 && (
                                                        <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#c8ff00] px-1.5 text-[10px] font-bold text-[#0a0912]">
                                                            {conversation.unreadCount}
                                                        </span>
                                                    )}
                                                </span>
                                            </span>
                                        </button>
                                    );
                                })}
                            </div>
                        )}
                    </aside>

                    <section
                        className={[
                            "min-w-0 flex-col",
                            mobileConversationOpen
                                ? "flex"
                                : "hidden lg:flex",
                        ].join(" ")}
                    >
                        {selectedConversation ? (
                            <>
                                {/*
                                    Resolve the participant again for the
                                    selected conversation. Never assume
                                    participants[0] is the other person.
                                */}
                                <header className="flex items-center gap-3 border-b border-white/[0.08] px-4 py-4 sm:px-6">
                                    <button
                                        type="button"
                                        onClick={() =>
                                            setMobileConversationOpen(false)
                                        }
                                        className="rounded-lg p-2 text-white/60 transition hover:bg-white/[0.06] hover:text-white lg:hidden"
                                        aria-label="Back to conversations"
                                    >
                                        <ArrowLeft size={19} />
                                    </button>

                                    <Avatar
                                        participant={getOtherParticipant(
                                            selectedConversation,
                                            currentUserId,
                                        )}
                                        name={getConversationName(
                                            selectedConversation,
                                            currentUserId,
                                        )}
                                        size="large"
                                    />

                                    <div className="min-w-0 flex-1">
                                        <h2 className="truncate font-bold text-white">
                                            {getConversationName(
                                                selectedConversation,
                                                currentUserId,
                                            )}
                                        </h2>

                                        <p className="mt-0.5 text-xs text-white/40">
                                            {selectedConversation.type === "SUPPORT"
                                                ? "KARMASS Support"
                                                : "Marketplace conversation"}
                                        </p>
                                    </div>
                                </header>

                                <div className="flex-1 space-y-4 overflow-y-auto bg-[#0d0c14] px-4 py-5 sm:px-6">
                                    {loadingMessages ? (
                                        <div className="flex h-full min-h-60 items-center justify-center">
                                            <LoaderCircle
                                                size={28}
                                                className="animate-spin text-[#c8ff00]"
                                            />
                                        </div>
                                    ) : messageError && messages.length === 0 ? (
                                        <div className="mx-auto max-w-md rounded-xl border border-red-400/15 bg-red-500/[0.06] p-5 text-center">
                                            <p
                                                role="alert"
                                                className="text-sm leading-6 text-red-200"
                                            >
                                                {messageError}
                                            </p>

                                            <button
                                                type="button"
                                                onClick={() =>
                                                    void loadConversations(
                                                        selectedConversation.id,
                                                    )
                                                }
                                                className="mt-3 text-sm font-bold text-[#c8ff00] underline underline-offset-4"
                                            >
                                                Try again
                                            </button>
                                        </div>
                                    ) : messages.length === 0 ? (
                                        <div className="flex min-h-60 flex-col items-center justify-center text-center">
                                            <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-[#c8ff00]/15 bg-[#c8ff00]/[0.06] text-[#c8ff00]">
                                                <MessageCircle size={28} />
                                            </span>

                                            <p className="mt-4 font-semibold text-white">
                                                Start the conversation
                                            </p>

                                            <p className="mt-1 text-sm text-white/45">
                                                Send a message to begin.
                                            </p>
                                        </div>
                                    ) : (
                                        messages.map((message) => {
                                            const isOwnMessage =
                                                currentUserId !== null
                                                && message.senderId === currentUserId;

                                            return (
                                                <article
                                                    key={message.id}
                                                    className={[
                                                        "flex w-full",
                                                        isOwnMessage
                                                            ? "justify-end"
                                                            : "justify-start",
                                                    ].join(" ")}
                                                >
                                                    <div
                                                        className={[
                                                            "max-w-[88%] rounded-2xl px-4 py-3 sm:max-w-[75%]",
                                                            isOwnMessage
                                                                ? "rounded-br-md bg-[#c8ff00] text-[#0a0912]"
                                                                : "rounded-bl-md border border-white/[0.08] bg-white/[0.045] text-white",
                                                        ].join(" ")}
                                                    >
                                                        <p className="whitespace-pre-wrap break-words text-sm leading-6">
                                                            {message.body}
                                                        </p>

                                                        <div
                                                            className={[
                                                                "mt-2 flex items-center justify-end gap-1.5 text-[10px]",
                                                                isOwnMessage
                                                                    ? "text-[#0a0912]/60"
                                                                    : "text-white/40",
                                                            ].join(" ")}
                                                        >
                                                            <span>
                                                                {formatMessageTime(
                                                                    message.createdAt,
                                                                )}
                                                            </span>

                                                            {isOwnMessage && (
                                                                <CheckCheck
                                                                    size={13}
                                                                    aria-label="Message sent"
                                                                />
                                                            )}
                                                        </div>
                                                    </div>
                                                </article>
                                            );
                                        })
                                    )}

                                    <div ref={bottomRef} />
                                </div>

                                {messageError && messages.length > 0 && (
                                    <div
                                        role="alert"
                                        className="border-t border-red-400/15 bg-red-500/[0.06] px-4 py-2 text-xs leading-5 text-red-200"
                                    >
                                        {messageError}
                                    </div>
                                )}

                                <form
                                    onSubmit={handleSendMessage}
                                    className="border-t border-white/[0.08] bg-[#111019] p-3 sm:p-4"
                                >
                                    <div className="flex items-end gap-2">
                                        <label
                                            htmlFor="message-draft"
                                            className="sr-only"
                                        >
                                            Write a message
                                        </label>

                                        <textarea
                                            id="message-draft"
                                            value={draft}
                                            onChange={(event) =>
                                                setDraft(
                                                    event.target.value,
                                                )
                                            }
                                            onKeyDown={(event) => {
                                                if (
                                                    event.key === "Enter"
                                                    && !event.shiftKey
                                                    && !event.nativeEvent.isComposing
                                                ) {
                                                    event.preventDefault();

                                                    event.currentTarget.form?.requestSubmit();
                                                }
                                            }}
                                            maxLength={MAX_MESSAGE_LENGTH}
                                            rows={2}
                                            disabled={sending}
                                            placeholder="Write your message..."
                                            className="max-h-36 min-h-12 flex-1 resize-y rounded-xl border border-white/[0.09] bg-white/[0.035] px-4 py-3 text-sm text-white outline-none transition placeholder:text-white/30 focus:border-[#c8ff00]/50 focus:bg-white/[0.05] focus:ring-2 focus:ring-[#c8ff00]/10 disabled:cursor-not-allowed disabled:opacity-60"
                                        />

                                        <button
                                            type="submit"
                                            disabled={
                                                sending
                                                || !draft.trim()
                                                || draft.trim().length > MAX_MESSAGE_LENGTH
                                            }
                                            className="inline-flex h-12 shrink-0 items-center justify-center gap-2 rounded-xl bg-[#c8ff00] px-4 text-sm font-bold text-[#0a0912] transition hover:bg-[#d7ff4d] disabled:cursor-not-allowed disabled:opacity-40"
                                        >
                                            {sending ? (
                                                <LoaderCircle
                                                    size={17}
                                                    className="animate-spin"
                                                />
                                            ) : (
                                                <Send size={17} />
                                            )}

                                            <span className="hidden sm:inline">
                                                Send
                                            </span>
                                        </button>
                                    </div>

                                    <div className="mt-2 flex items-center justify-between gap-3 text-[10px] text-white/35">
                                        <span>
                                            Enter to send · Shift + Enter for a new line
                                        </span>

                                        <span>
                                            {draft.length}/{MAX_MESSAGE_LENGTH}
                                        </span>
                                    </div>
                                </form>
                            </>
                        ) : (
                            <div className="flex min-h-[580px] flex-1 flex-col items-center justify-center px-6 text-center">
                                <span className="flex h-16 w-16 items-center justify-center rounded-2xl border border-[#c8ff00]/15 bg-[#c8ff00]/[0.06] text-[#c8ff00]">
                                    <MessageCircle size={30} />
                                </span>

                                <h2 className="mt-5 text-xl font-bold text-white">
                                    Your conversations
                                </h2>

                                <p className="mt-2 max-w-sm text-sm leading-6 text-white/45">
                                    Choose a conversation to read messages, or browse vehicles to contact a seller.
                                </p>

                                <button
                                    type="button"
                                    onClick={() =>
                                        router.push("/marketplace")
                                    }
                                    className="mt-5 rounded-xl bg-[#c8ff00] px-5 py-3 text-sm font-bold text-[#0a0912] transition hover:bg-[#d7ff4d]"
                                >
                                    Browse vehicles
                                </button>
                            </div>
                        )}
                    </section>
                </section>

                <p className="mt-4 flex items-start gap-2 text-xs leading-5 text-white/40">
                    <CheckCheck
                        size={15}
                        className="mt-0.5 shrink-0 text-[#c8ff00]"
                    />

                    <span>
                        Keep communication on KARMASS and verify the vehicle and seller independently before making payment.
                    </span>
                </p>
            </div>
        </main>
    );
}