"use client";

import Link from "next/link";
import {
    ArrowRight,
    BadgeCheck,
    CarFront,
    ChevronRight,
    Search,
    ShieldCheck,
    Sparkles,
    RefreshCw,
} from "lucide-react";
import { useEffect, useState } from "react";

import { DesktopNavbar } from "./DesktopNavbar";
import { MarketplaceFooter } from "./MarketplaceFooter";

import { searchMarketplace } from "@/app/services/user/marketplace/marketplace.service";

import type {
    MarketplaceSearchResult,
} from "@/app/types/user/marketplace.types";

const categories = [
    "SUVs",
    "Sedans",
    "Luxury",
    "Electric",
    "Pickup trucks",
];

const marketplaceSteps = [
    {
        number: "01",
        title: "Discover",
        description: "Explore vehicles that fit your lifestyle.",
    },
    {
        number: "02",
        title: "Compare",
        description: "Review details and contact sellers directly.",
    },
    {
        number: "03",
        title: "Drive away",
        description: "Make your next move with confidence.",
    },
];

const featuredLabels = [
    "Featured vehicle",
    "Find your next car",
    "Explore this vehicle",
];

function formatPrice(
    price: string | number,
    currency: string,
): string {
    const numericPrice =
        typeof price === "number" ? price : Number(price);

    if (!Number.isFinite(numericPrice)) {
        return "Price on request";
    }

    try {
        return new Intl.NumberFormat("en-NG", {
            style: "currency",
            currency: currency || "NGN",
            maximumFractionDigits: 0,
        }).format(numericPrice);
    } catch {
        return `${currency || "NGN"} ${numericPrice.toLocaleString("en-NG")}`;
    }
}

function getVehicleTitle(
    result: MarketplaceSearchResult,
): string {
    const listingTitle = result.listing.title?.trim();

    if (listingTitle) {
        return listingTitle;
    }

    return [
        result.make?.name,
        result.model?.name,
        result.variant?.year,
    ]
        .filter(Boolean)
        .join(" ") || "Vehicle listing";
}

function getVehicleDetails(
    result: MarketplaceSearchResult,
): string {
    const details = [
        result.variant?.year
            ? String(result.variant.year)
            : undefined,
        result.variant?.fuelType,
        result.variant?.transmission,
        result.listing.city,
        result.listing.state,
    ].filter(
        (value): value is string =>
            typeof value === "string" && value.trim().length > 0,
    );

    return [...new Set(details)].join(" · ");
}

function VehicleImagePlaceholder() {
    return (
        <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-slate-100 via-slate-50 to-violet-100 text-slate-400">
            <CarFront
                size={48}
                strokeWidth={1.2}
                aria-hidden="true"
            />

            <span className="mt-3 text-xs font-medium tracking-wide">
                Vehicle image unavailable
            </span>
        </div>
    );
}

function FeaturedVehicleCard({
    result,
    index,
}: {
    result: MarketplaceSearchResult;
    index: number;
}) {
    const title = getVehicleTitle(result);
    const details = getVehicleDetails(result);

    return (
        <Link
            href={`/marketplace?q=${encodeURIComponent(title)}`}
            className="group overflow-hidden rounded-3xl border border-slate-200 bg-white transition duration-300 hover:-translate-y-1 hover:border-violet-200 hover:shadow-xl"
        >
            <div className="relative h-56 overflow-hidden bg-slate-100">
                <VehicleImagePlaceholder />

                <span className="absolute left-4 top-4 rounded-full border border-white/70 bg-white/90 px-3 py-1.5 text-xs font-semibold text-slate-700 backdrop-blur">
                    {featuredLabels[index % featuredLabels.length]}
                </span>

                {result.boostPriority > 0 && (
                    <span className="absolute right-4 top-4 rounded-full bg-violet-700 px-3 py-1.5 text-xs font-semibold text-white">
                        Promoted
                    </span>
                )}
            </div>

            <div className="p-5">
                <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                        <h3 className="truncate text-lg font-semibold text-slate-950 transition group-hover:text-violet-700">
                            {title}
                        </h3>

                        <p className="mt-1 min-h-5 text-sm text-slate-500">
                            {details || "Explore vehicle details"}
                        </p>
                    </div>

                    <span className="grid size-10 shrink-0 place-items-center rounded-full bg-slate-100 text-slate-700 transition group-hover:bg-violet-700 group-hover:text-white">
                        <ArrowRight size={17} />
                    </span>
                </div>

                <div className="mt-5 border-t border-slate-100 pt-4">
                    <p className="text-lg font-bold text-violet-700">
                        {formatPrice(
                            result.listing.price,
                            result.listing.currency,
                        )}
                    </p>

                    {result.listing.mileage !== null && (
                        <p className="mt-1 text-xs text-slate-500">
                            {result.listing.mileage.toLocaleString("en-NG")} km
                        </p>
                    )}
                </div>
            </div>
        </Link>
    );
}

function VehicleCardSkeleton() {
    return (
        <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white">
            <div className="h-56 animate-pulse bg-slate-200" />

            <div className="space-y-3 p-5">
                <div className="h-5 w-3/4 animate-pulse rounded bg-slate-200" />
                <div className="h-4 w-1/2 animate-pulse rounded bg-slate-100" />
                <div className="mt-5 h-6 w-2/5 animate-pulse rounded bg-slate-200" />
            </div>
        </div>
    );
}

export function DesktopHome() {
    const [query, setQuery] = useState("");
    const [featuredVehicles, setFeaturedVehicles] = useState<
        MarketplaceSearchResult[]
    >([]);
    const [isLoading, setIsLoading] = useState(true);
    const [loadError, setLoadError] = useState<string | null>(null);
    const [retryCount, setRetryCount] = useState(0);

    useEffect(() => {
        let isMounted = true;

        async function loadFeaturedVehicles(): Promise<void> {
            setIsLoading(true);
            setLoadError(null);

            try {
                const response = await searchMarketplace({
                    page: 1,
                    limit: 6,
                    sort: "newest",
                });

                if (!isMounted) {
                    return;
                }

                setFeaturedVehicles(response.data.listings);
            } catch (error: unknown) {
                if (!isMounted) {
                    return;
                }

                setLoadError(
                    error instanceof Error
                        ? error.message
                        : "We couldn't load vehicles right now.",
                );
            } finally {
                if (isMounted) {
                    setIsLoading(false);
                }
            }
        }

        void loadFeaturedVehicles();

        return () => {
            isMounted = false;
        };
    }, [retryCount]);

    function handleSearch(
        event: React.FormEvent<HTMLFormElement>,
    ): void {
        event.preventDefault();

        const searchQuery = query.trim();

        const destination = searchQuery
            ? `/marketplace?q=${encodeURIComponent(searchQuery)}`
            : "/marketplace";

        window.location.assign(destination);
    }

    return (
        <div className="min-h-screen bg-[#f7f8fa] text-slate-950">
            <DesktopNavbar />

            <main>
                <section className="mx-auto grid max-w-[1440px] gap-10 px-6 pb-16 pt-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center lg:px-12 lg:pb-24 lg:pt-16">
                    <div className="relative z-10">
                        <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[.18em] text-slate-600">
                            <Sparkles
                                size={15}
                                className="text-violet-600"
                            />
                            The smarter way to buy and sell
                        </span>

                        <h1 className="mt-7 max-w-2xl text-5xl font-semibold leading-[1.04] tracking-[-.055em] sm:text-6xl xl:text-7xl">
                            Your next drive{" "}
                            <span className="text-violet-700">
                                starts here.
                            </span>
                        </h1>

                        <p className="mt-6 max-w-xl text-lg leading-8 text-slate-600">
                            Discover quality vehicles, compare your options,
                            and connect with trusted sellers across Nigeria.
                        </p>

                        <form
                            onSubmit={handleSearch}
                            className="mt-8 flex max-w-xl items-center gap-3 rounded-2xl border border-slate-200 bg-white p-2 shadow-[0_16px_50px_-30px_rgba(15,23,42,.35)]"
                        >
                            <Search
                                className="ml-3 shrink-0 text-slate-400"
                                size={21}
                            />

                            <input
                                value={query}
                                onChange={(event) =>
                                    setQuery(event.target.value)
                                }
                                placeholder="Search make, model or keyword"
                                aria-label="Search vehicles"
                                className="min-w-0 flex-1 bg-transparent px-1 py-3 text-sm outline-none placeholder:text-slate-400"
                            />

                            <button
                                type="submit"
                                className="inline-flex items-center gap-2 rounded-xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-violet-700"
                            >
                                Search
                                <ArrowRight size={16} />
                            </button>
                        </form>

                        <div className="mt-6 flex flex-wrap gap-2">
                            {categories.map((category) => (
                                <Link
                                    key={category}
                                    href={`/marketplace?q=${encodeURIComponent(category)}`}
                                    className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 transition hover:border-violet-300 hover:text-violet-700"
                                >
                                    {category}
                                </Link>
                            ))}
                        </div>

                        <div className="mt-9 flex flex-wrap gap-x-6 gap-y-3 text-sm text-slate-600">
                            <span className="flex items-center gap-2">
                                <ShieldCheck
                                    size={17}
                                    className="text-emerald-600"
                                />
                                Trusted seller journey
                            </span>

                            <span className="flex items-center gap-2">
                                <BadgeCheck
                                    size={17}
                                    className="text-violet-700"
                                />
                                Verified dealer profiles
                            </span>
                        </div>
                    </div>

                    <div className="relative min-h-[360px] overflow-hidden rounded-[2rem] bg-slate-200 sm:min-h-[500px]">
                        <img
                            src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1600&q=90"
                            alt="Premium sports car on a scenic road"
                            className="absolute inset-0 h-full w-full object-cover"
                        />

                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-slate-950/10" />

                        <div className="absolute bottom-6 left-6 right-6 rounded-2xl border border-white/25 bg-white/90 p-5 backdrop-blur-xl sm:bottom-8 sm:left-8 sm:right-8">
                            <p className="text-xs font-semibold uppercase tracking-[.16em] text-violet-700">
                                Find your kind of drive
                            </p>

                            <div className="mt-2 flex items-center justify-between gap-4">
                                <div>
                                    <h2 className="text-xl font-semibold">
                                        More choice. More confidence.
                                    </h2>

                                    <p className="mt-1 text-sm text-slate-600">
                                        A better way to shop for your next car.
                                    </p>
                                </div>

                                <Link
                                    href="/marketplace"
                                    aria-label="Browse marketplace"
                                    className="grid size-11 shrink-0 place-items-center rounded-full bg-slate-950 text-white transition hover:bg-violet-700"
                                >
                                    <ArrowRight size={19} />
                                </Link>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="border-y border-slate-200 bg-white">
                    <div className="mx-auto grid max-w-[1440px] gap-5 px-6 py-7 sm:grid-cols-3 lg:px-12">
                        {marketplaceSteps.map((step) => (
                            <div
                                key={step.number}
                                className="flex gap-4"
                            >
                                <span className="text-sm font-semibold text-violet-700">
                                    {step.number}
                                </span>

                                <div>
                                    <h3 className="font-semibold">
                                        {step.title}
                                    </h3>

                                    <p className="mt-1 text-sm text-slate-500">
                                        {step.description}
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

                <section className="mx-auto max-w-[1440px] px-6 py-16 lg:px-12 lg:py-20">
                    <div className="mb-8 flex items-end justify-between gap-4">
                        <div>
                            <p className="text-xs font-semibold uppercase tracking-[.18em] text-violet-700">
                                Explore the marketplace
                            </p>

                            <h2 className="mt-2 text-3xl font-semibold tracking-tight sm:text-4xl">
                                Start with a style you love
                            </h2>

                            <p className="mt-3 max-w-xl text-sm leading-6 text-slate-500">
                                Explore available vehicles listed on KARMASS.
                            </p>
                        </div>

                        <Link
                            href="/marketplace"
                            className="hidden items-center gap-2 text-sm font-semibold text-slate-700 hover:text-violet-700 sm:flex"
                        >
                            Browse cars
                            <ChevronRight size={17} />
                        </Link>
                    </div>

                    {isLoading ? (
                        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                            {Array.from({ length: 3 }, (_, index) => (
                                <VehicleCardSkeleton key={index} />
                            ))}
                        </div>
                    ) : loadError ? (
                        <div
                            role="alert"
                            className="rounded-3xl border border-rose-200 bg-white px-6 py-12 text-center"
                        >
                            <p className="font-semibold text-slate-900">
                                We couldn't load the vehicles.
                            </p>

                            <p className="mx-auto mt-2 max-w-lg text-sm leading-6 text-slate-500">
                                {loadError}
                            </p>

                            <button
                                type="button"
                                onClick={() =>
                                    setRetryCount((count) => count + 1)
                                }
                                className="mt-5 inline-flex items-center gap-2 rounded-xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-violet-700"
                            >
                                <RefreshCw size={16} />
                                Try again
                            </button>
                        </div>
                    ) : featuredVehicles.length === 0 ? (
                        <div className="rounded-3xl border border-slate-200 bg-white px-6 py-14 text-center">
                            <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-violet-50 text-violet-700">
                                <CarFront size={27} />
                            </div>

                            <h3 className="mt-5 text-lg font-semibold">
                                Your next car could be listed here.
                            </h3>

                            <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-500">
                                There are no vehicles to display right now.
                                Check back soon or explore the marketplace.
                            </p>

                            <Link
                                href="/marketplace"
                                className="mt-5 inline-flex items-center gap-2 rounded-xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-violet-700"
                            >
                                Explore marketplace
                                <ArrowRight size={16} />
                            </Link>
                        </div>
                    ) : (
                        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                            {featuredVehicles
                                .slice(0, 6)
                                .map((result, index) => (
                                    <FeaturedVehicleCard
                                        key={result.listing.id}
                                        result={result}
                                        index={index}
                                    />
                                ))}
                        </div>
                    )}

                    <div className="mt-8 rounded-3xl bg-slate-950 p-7 text-white sm:flex sm:items-center sm:justify-between sm:p-10">
                        <div>
                            <p className="text-xs font-semibold uppercase tracking-[.18em] text-violet-300">
                                Selling on KARMASS
                            </p>

                            <h2 className="mt-2 text-2xl font-semibold">
                                Ready to find the right buyer?
                            </h2>

                            <p className="mt-2 text-sm text-slate-300">
                                Create a listing and put your vehicle in front
                                of buyers.
                            </p>
                        </div>

                        <Link
                            href="/sell"
                            className="mt-5 inline-flex items-center gap-2 rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-violet-500 sm:mt-0"
                        >
                            Sell your car
                            <CarFront size={17} />
                        </Link>
                    </div>
                </section>
            </main>

            <MarketplaceFooter />
        </div>
    );
}