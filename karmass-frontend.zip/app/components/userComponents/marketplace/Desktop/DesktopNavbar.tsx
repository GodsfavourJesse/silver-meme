"use client";

import Link from "next/link";
import { CarFront, Menu, Search } from "lucide-react";
import { useState } from "react";

const navigationLinks = [
    { label: "Buy a car", href: "/marketplace" },
    { label: "Sell a car", href: "/sell" },
    { label: "Dealers", href: "/dealers" },
];

export function DesktopNavbar() {
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    return (
        <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur-xl">
            <div className="mx-auto flex h-[76px] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
                <Link
                    href="/"
                    aria-label="KARMASS home"
                    className="flex items-center gap-2"
                >
                    <span className="grid size-10 place-items-center rounded-xl bg-violet-700 text-white">
                        <CarFront size={23} />
                    </span>

                    <span className="text-xl font-extrabold tracking-[0.12em] text-slate-950">
                        KARMASS
                    </span>
                </Link>

                <nav className="hidden items-center gap-8 md:flex">
                    {navigationLinks.map((item) => (
                        <Link
                            key={item.label}
                            href={item.href}
                            className="text-sm font-medium text-slate-600 transition hover:text-violet-700"
                        >
                            {item.label}
                        </Link>
                    ))}
                </nav>

                <div className="hidden items-center gap-3 md:flex">
                    <Link
                        href="/sign-in"
                        className="rounded-xl px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-100"
                    >
                        Sign in
                    </Link>

                    <Link
                        href="/register"
                        className="rounded-xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:bg-violet-700"
                    >
                        Create account
                    </Link>
                </div>

                <button
                    type="button"
                    aria-label={
                        mobileMenuOpen
                            ? "Close navigation menu"
                            : "Open navigation menu"
                    }
                    aria-expanded={mobileMenuOpen}
                    onClick={() =>
                        setMobileMenuOpen((current) => !current)
                    }
                    className="grid size-11 place-items-center rounded-xl border border-slate-200 text-slate-800 transition hover:bg-slate-100 md:hidden"
                >
                    <Menu size={22} />
                </button>
            </div>

            {mobileMenuOpen && (
                <nav className="border-t border-slate-200 bg-white px-5 py-4 md:hidden">
                    <div className="mx-auto flex max-w-[1440px] flex-col gap-1">
                        {navigationLinks.map((item) => (
                            <Link
                                key={item.label}
                                href={item.href}
                                onClick={() => setMobileMenuOpen(false)}
                                className="rounded-xl px-4 py-3 text-sm font-medium text-slate-700 transition hover:bg-slate-100"
                            >
                                {item.label}
                            </Link>
                        ))}

                        <Link
                            href="/sign-in"
                            onClick={() => setMobileMenuOpen(false)}
                            className="rounded-xl px-4 py-3 text-sm font-medium text-slate-700 transition hover:bg-slate-100"
                        >
                            Sign in
                        </Link>

                        <Link
                            href="/register"
                            onClick={() => setMobileMenuOpen(false)}
                            className="mt-2 rounded-xl bg-slate-950 px-4 py-3 text-center text-sm font-semibold text-white"
                        >
                            Create account
                        </Link>
                    </div>
                </nav>
            )}
        </header>
    );
}