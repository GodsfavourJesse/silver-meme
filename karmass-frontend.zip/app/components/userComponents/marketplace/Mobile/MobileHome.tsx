"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import {
    ArrowRight,
    Bell,
    CarFront,
    Heart,
    Home,
    MapPin,
    MessageCircle,
    Search,
    SlidersHorizontal,
    UserRound,
    Zap,
} from "lucide-react";

import { searchMarketplace } from "@/app/services/user/marketplace/marketplace.service";

import type {
    MarketplaceSearchParams,
    MarketplaceSearchResult,
} from "@/app/types/user/marketplace.types";

const categories = [
    "All cars",
    "SUV",
    "Sedan",
    "Electric",
    "Luxury",
] as const;

type Category = (typeof categories)[number];

function formatPrice(
    price: string | number,
    currency: string,
): string {
    const numericPrice =
        typeof price === "number" ? price : Number(price);

    if (!Number.isFinite(numericPrice)) {
        return "Price on request";
    }

    if (currency === "NGN") {
        return new Intl.NumberFormat("en-NG", {
            style: "currency",
            currency: "NGN",
            maximumFractionDigits: 0,
        }).format(numericPrice);
    }

    try {
        return new Intl.NumberFormat("en-NG", {
            style: "currency",
            currency,
            maximumFractionDigits: 0,
        }).format(numericPrice);
    } catch {
        return `${currency} ${numericPrice.toLocaleString("en-NG")}`;
    }
}

function formatMileage(mileage: number | null): string {
    if (mileage === null || mileage === undefined) {
        return "";
    }

    return `${new Intl.NumberFormat("en-NG").format(mileage)} km`;
}

function getVehicleTitle(
    result: MarketplaceSearchResult,
): string {
    const title = result.listing.title?.trim();

    if (title) {
        return title;
    }

    return [
        result.make?.name,
        result.model?.name,
        result.variant?.name,
    ]
        .filter(Boolean)
        .join(" ") || "Vehicle listing";
}

function getVehicleYear(
    result: MarketplaceSearchResult,
): string | null {
    const year = result.variant?.year;

    return year ? String(year) : null;
}

function getVehicleDetails(
    result: MarketplaceSearchResult,
): string[] {
    const details: string[] = [];
    const year = getVehicleYear(result);
    const mileage = formatMileage(result.listing.mileage);
    const transmission = result.variant?.transmission;

    if (year) {
        details.push(year);
    }

    if (mileage) {
        details.push(mileage);
    }

    if (transmission) {
        details.push(transmission);
    }

    return details;
}

function getVehicleLocation(
    result: MarketplaceSearchResult,
): string {
    return [result.listing.city, result.listing.state]
        .filter(Boolean)
        .join(", ") || "Location not specified";
}

function getCategoryFilters(
    category: Category,
): Partial<MarketplaceSearchParams> {
    switch (category) {
        case "SUV":
            return {
                bodyStyle: "SUV",
            };

        case "Sedan":
            return {
                bodyStyle: "SEDAN",
            };

        case "Electric":
            return {
                fuelType: "ELECTRIC",
            };

        case "Luxury":
            return {
                sort: "price_desc",
            };

        default:
            return {};
    }
}

function ListingImagePlaceholder() {
    return (
        <div
            aria-label="Vehicle image unavailable"
            className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-neutral-100 via-neutral-200 to-neutral-100 text-neutral-400"
        >
            <CarFront size={44} strokeWidth={1.2} />

            <span className="mt-2 text-[10px] font-medium uppercase tracking-[0.16em]">
                KARMASS
            </span>
        </div>
    );
}

function ListingSkeleton() {
    return (
        <article className="overflow-hidden rounded-[1.5rem] border border-neutral-200 bg-white">
            <div className="h-48 animate-pulse bg-neutral-200" />

            <div className="space-y-3 p-4">
                <div className="h-4 w-2/3 animate-pulse rounded bg-neutral-200" />

                <div className="h-3 w-1/2 animate-pulse rounded bg-neutral-100" />

                <div className="h-4 w-1/3 animate-pulse rounded bg-neutral-200" />

                <div className="h-3 w-1/2 animate-pulse rounded bg-neutral-100" />
            </div>
        </article>
    );
}

function FeaturedCarCard({
    result,
}: {
    result: MarketplaceSearchResult;
}) {
    const listing = result.listing;
    const title = getVehicleTitle(result);
    const year = getVehicleYear(result);
    const details = getVehicleDetails(result);
    const location = getVehicleLocation(result);

    return (
        <article className="overflow-hidden rounded-[1.5rem] border border-neutral-200 bg-white transition-shadow duration-200 hover:shadow-md">
            <Link
                href={`/marketplace?q=${encodeURIComponent(title)}`}
                aria-label={`View ${title}`}
                className="relative block h-48 bg-neutral-100"
            >
                <ListingImagePlaceholder />

                {result.boostPriority > 0 && (
                    <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-amber-400 px-3 py-1.5 text-[10px] font-bold text-neutral-950">
                        <Zap size={12} />
                        Featured
                    </span>
                )}

                {result.boostPriority <= 0 && (
                    <span className="absolute left-3 top-3 rounded-full bg-white/95 px-3 py-1.5 text-[10px] font-semibold text-neutral-700 shadow-sm">
                        Available
                    </span>
                )}
            </Link>

            <div className="p-4">
                <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                        <Link
                            href={`/marketplace?q=${encodeURIComponent(title)}`}
                            className="line-clamp-2 font-semibold text-neutral-950 transition-colors hover:text-violet-700"
                        >
                            {title}
                        </Link>

                        {details.length > 0 && (
                            <p className="mt-1.5 text-xs leading-5 text-neutral-500">
                                {details.join(" · ")}
                            </p>
                        )}
                    </div>

                    <strong className="shrink-0 text-sm font-bold text-neutral-950">
                        {formatPrice(listing.price, listing.currency)}
                    </strong>
                </div>

                <p className="mt-3 flex items-center gap-1.5 text-xs text-neutral-500">
                    <MapPin size={14} className="shrink-0" />

                    <span className="truncate">
                        {location}
                    </span>
                </p>
            </div>
        </article>
    );
}

export function MobileHome() {
    const [query, setQuery] = useState("");
    const [category, setCategory] = useState<Category>("All cars");

    const [cars, setCars] = useState<MarketplaceSearchResult[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        let isActive = true;

        async function loadFeaturedCars() {
            setIsLoading(true);
            setError(null);

            try {
                const filters: MarketplaceSearchParams = {
                    page: 1,
                    limit: 6,
                    sort: category === "Luxury" ? "price_desc" : "newest",
                    ...getCategoryFilters(category),
                };

                const response = await searchMarketplace(filters);

                if (!isActive) {
                    return;
                }

                setCars(response.data.listings);
            } catch {
                if (!isActive) {
                    return;
                }

                setError(
                    "We couldn't load vehicles right now. Please try again.",
                );
            } finally {
                if (isActive) {
                    setIsLoading(false);
                }
            }
        }

        void loadFeaturedCars();

        return () => {
            isActive = false;
        };
    }, [category]);

    function handleSearch(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();

        const trimmedQuery = query.trim();

        window.location.href = trimmedQuery
            ? `/marketplace?q=${encodeURIComponent(trimmedQuery)}`
            : "/marketplace";
    }

    return (
        <main className="min-h-screen bg-[#f5f5f3] pb-28 text-neutral-950 md:hidden">
            <header className="flex items-center justify-between px-5 pb-4 pt-5">
                <Link
                    href="/"
                    className="flex items-center gap-2.5"
                    aria-label="KARMASS home"
                >
                    <span className="grid size-10 place-items-center rounded-2xl bg-neutral-950 text-lg font-bold text-white">
                        K
                    </span>

                    <span className="text-base font-bold tracking-[.12em]">
                        KARMASS

                        <span className="mt-0.5 block text-[9px] font-medium tracking-[.16em] text-neutral-500">
                            YOUR NEXT DRIVE
                        </span>
                    </span>
                </Link>

                <button
                    type="button"
                    aria-label="Notifications"
                    className="relative grid size-11 place-items-center rounded-full border border-neutral-200 bg-white"
                >
                    <Bell size={19} />

                    <span className="absolute right-2 top-2 size-2 rounded-full bg-violet-600" />
                </button>
            </header>

            <section className="mx-4 overflow-hidden rounded-[2rem] bg-gradient-to-br from-[#f7b7a2] via-[#f36a46] to-[#d83923] p-5 text-white shadow-lg shadow-orange-900/10">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-xs text-white/80">
                            YOUR NEXT DRIVE STARTS HERE
                        </p>

                        <p className="mt-1 text-sm font-semibold">
                            Find your next favourite
                        </p>
                    </div>

                    <span className="grid size-10 place-items-center rounded-full bg-white/20">
                        <CarFront size={21} />
                    </span>
                </div>

                <h1 className="mt-7 max-w-xs text-[2.6rem] font-semibold leading-[1.02] tracking-[-.05em]">
                    Find a car that{" "}
                    <span className="text-neutral-950">
                        moves you.
                    </span>
                </h1>

                <p className="mt-3 max-w-[260px] text-sm leading-6 text-white/90">
                    Discover quality vehicles from trusted sellers across Nigeria.
                </p>

                <div className="mt-5 flex gap-3">
                    <Link
                        href="/marketplace"
                        className="inline-flex items-center gap-2 rounded-full bg-neutral-950 px-5 py-3 text-sm font-semibold text-white"
                    >
                        Explore cars
                        <ArrowRight size={16} />
                    </Link>

                    <Link
                        href="/sell"
                        className="rounded-full border border-white/60 bg-white/15 px-5 py-3 text-sm font-semibold text-white"
                    >
                        Sell your car
                    </Link>
                </div>

                <div className="mt-6 flex h-28 items-center justify-center overflow-hidden rounded-2xl border border-white/20 bg-black/10">
                    <div className="flex items-center gap-3 text-white/80">
                        <CarFront size={34} strokeWidth={1.3} />

                        <span className="text-xs font-semibold tracking-[.18em]">
                            YOUR NEXT DRIVE
                        </span>
                    </div>
                </div>
            </section>

            <form
                onSubmit={handleSearch}
                className="mx-4 mt-5 flex items-center gap-3 rounded-2xl border border-neutral-200 bg-white p-2 pl-4 shadow-sm"
            >
                <Search
                    size={19}
                    className="shrink-0 text-neutral-500"
                />

                <input
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    placeholder="Make, model or keyword"
                    aria-label="Search vehicles"
                    className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none placeholder:text-neutral-400"
                />

                <button
                    aria-label="Search vehicles"
                    type="submit"
                    className="grid size-10 shrink-0 place-items-center rounded-xl bg-neutral-950 text-white"
                >
                    <SlidersHorizontal size={18} />
                </button>
            </form>

            <div
                aria-label="Vehicle categories"
                className="mt-5 flex gap-2 overflow-x-auto px-4 pb-1"
            >
                {categories.map((item) => (
                    <button
                        key={item}
                        type="button"
                        onClick={() => setCategory(item)}
                        aria-pressed={category === item}
                        className={`shrink-0 rounded-full px-4 py-2.5 text-xs font-semibold transition-colors ${
                            category === item
                                ? "bg-neutral-950 text-white"
                                : "border border-neutral-200 bg-white text-neutral-600"
                        }`}
                    >
                        {item === "Electric" && (
                            <Zap
                                size={13}
                                className="mr-1 inline"
                            />
                        )}

                        {item}
                    </button>
                ))}
            </div>

            <section className="mt-7 px-4">
                <div className="mb-4 flex items-end justify-between">
                    <div>
                        <p className="text-[10px] font-bold uppercase tracking-[.18em] text-violet-700">
                            Hand-picked for you
                        </p>

                        <h2 className="mt-1 text-2xl font-semibold tracking-tight">
                            Featured cars
                        </h2>
                    </div>

                    <Link
                        href="/marketplace"
                        className="flex items-center gap-1 text-xs font-semibold"
                    >
                        See all
                        <ArrowRight size={14} />
                    </Link>
                </div>

                {isLoading ? (
                    <div className="space-y-4" aria-label="Loading vehicles">
                        {Array.from({ length: 3 }).map((_, index) => (
                            <ListingSkeleton key={index} />
                        ))}
                    </div>
                ) : error ? (
                    <div
                        role="alert"
                        className="rounded-2xl border border-red-200 bg-white p-5"
                    >
                        <p className="text-sm font-semibold text-neutral-900">
                            Vehicles are temporarily unavailable
                        </p>

                        <p className="mt-2 text-sm leading-6 text-neutral-500">
                            {error}
                        </p>

                        <button
                            type="button"
                            onClick={() => setCategory((current) => current)}
                            className="mt-4 rounded-full bg-neutral-950 px-4 py-2.5 text-sm font-semibold text-white"
                        >
                            Try again
                        </button>
                    </div>
                ) : cars.length === 0 ? (
                    <div className="rounded-2xl border border-neutral-200 bg-white px-5 py-8 text-center">
                        <span className="mx-auto grid size-12 place-items-center rounded-2xl bg-neutral-100 text-neutral-500">
                            <CarFront size={24} />
                        </span>

                        <h3 className="mt-4 font-semibold">
                            No vehicles found yet
                        </h3>

                        <p className="mt-2 text-sm leading-6 text-neutral-500">
                            Try another category or explore all available listings.
                        </p>

                        <button
                            type="button"
                            onClick={() => setCategory("All cars")}
                            className="mt-4 rounded-full bg-neutral-950 px-4 py-2.5 text-sm font-semibold text-white"
                        >
                            View all cars
                        </button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {cars.map((result) => (
                            <FeaturedCarCard
                                key={result.listing.id}
                                result={result}
                            />
                        ))}
                    </div>
                )}
            </section>

            <section className="mx-4 mt-7 rounded-3xl bg-neutral-950 p-5 text-white">
                <p className="text-xs font-semibold uppercase tracking-[.15em] text-violet-300">
                    Sell with confidence
                </p>

                <h2 className="mt-2 text-xl font-semibold">
                    Your next buyer is out there.
                </h2>

                <p className="mt-2 text-sm leading-6 text-neutral-300">
                    List your vehicle and reach people looking for their next drive.
                </p>

                <Link
                    href="/sell"
                    className="mt-4 inline-flex items-center gap-2 rounded-full bg-white px-4 py-3 text-sm font-semibold text-neutral-950"
                >
                    Start selling
                    <ArrowRight size={16} />
                </Link>
            </section>

            <nav
                aria-label="Mobile navigation"
                className="fixed inset-x-3 bottom-3 z-40 grid grid-cols-5 rounded-[1.5rem] border border-neutral-200 bg-white/95 p-2 shadow-[0_12px_40px_-12px_rgba(0,0,0,.25)] backdrop-blur-xl"
            >
                <Link
                    href="/"
                    className="flex flex-col items-center gap-1 rounded-xl bg-neutral-950 py-2 text-white"
                >
                    <Home size={18} />
                    <span className="text-[9px] font-semibold">
                        Home
                    </span>
                </Link>

                <Link
                    href="/marketplace"
                    className="flex flex-col items-center gap-1 py-2 text-neutral-500"
                >
                    <Search size={18} />
                    <span className="text-[9px] font-medium">
                        Explore
                    </span>
                </Link>

                <Link
                    href="/sell"
                    className="flex flex-col items-center gap-1 py-2 text-neutral-500"
                >
                    <CarFront size={18} />
                    <span className="text-[9px] font-medium">
                        Sell
                    </span>
                </Link>

                <Link
                    href="/messages"
                    className="flex flex-col items-center gap-1 py-2 text-neutral-500"
                >
                    <MessageCircle size={18} />
                    <span className="text-[9px] font-medium">
                        Messages
                    </span>
                </Link>

                <Link
                    href="/account"
                    className="flex flex-col items-center gap-1 py-2 text-neutral-500"
                >
                    <UserRound size={18} />
                    <span className="text-[9px] font-medium">
                        Account
                    </span>
                </Link>
            </nav>
        </main>
    );
}