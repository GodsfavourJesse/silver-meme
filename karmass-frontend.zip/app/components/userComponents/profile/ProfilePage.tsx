"use client";

import {
    useEffect,
    useState,
    type FormEvent,
} from "react";

import { useRouter } from "next/navigation";

import {
    useQueryClient,
} from "@tanstack/react-query";

import {
    AlertCircle,
    ArrowLeft,
    Check,
    CheckCircle2,
    ChevronRight,
    Clock3,
    LoaderCircle,
    LockKeyhole,
    Mail,
    Phone,
    Save,
    ShieldCheck,
    Trash2,
    UserRound,
    X,
} from "lucide-react";

import {
    queryKeys,
} from "@/app/lib/query/query-keys";

import {
    useUserProfile,
} from "@/app/hooks/user/profile/useUserProfile";
import { useUserPrivacySettings } from "@/app/hooks/user/profile/useUserPrivacySettings";
import { useUpdateUserProfile } from "@/app/hooks/user/profile/useUpdateUserProfile";
import { useUpdateUserPrivacySettings } from "@/app/hooks/user/profile/useUpdateUserPrivacySettings";
import { useDeleteUserAccount } from "@/app/hooks/user/profile/useDeleteUserAccount";

const BRAND = "#7008E7";

interface Notice {
    type: "success" | "error";
    message: string;
}

interface PrivacyOption {
    key:
    | "showPhone"
    | "showEmail"
    | "allowDirectMessages"
    | "showOnlineStatus"
    | "allowMarketingEmails"
    | "allowMarketingSms";

    title: string;
    description: string;

}

const PRIVACY_OPTIONS: PrivacyOption[] = [
    {
        key: "showPhone",
        title: "Show my phone number",
        description:
        "Allow other users to see your phone number where your profile is displayed.",
    },
    {
        key: "showEmail",
        title: "Show my email address",
        description:
        "Allow your email address to be displayed publicly where supported.",
    },
    {
        key: "allowDirectMessages",
        title: "Allow direct messages",
        description:
        "Allow other users to contact you through the platform's messaging features.",
    },
    {
        key: "showOnlineStatus",
        title: "Show online status",
        description:
        "Allow other users to see your online status where supported.",
    },
    {
        key: "allowMarketingEmails",
        title: "Marketing emails",
        description:
        "Receive promotional emails and product updates from KARMASS.",
    },
    {
        key: "allowMarketingSms",
        title: "Marketing SMS",
        description:
        "Receive promotional text messages from KARMASS.",
    },
];

function getInitials(
    firstName?: string | null,
    lastName?: string | null,
): string {
    const first = firstName?.trim().charAt(0) ?? "";
    const last = lastName?.trim().charAt(0) ?? "";

    return `${first}${last}`.toUpperCase() || "K";
}

function getDisplayName(
    firstName?: string | null,
    lastName?: string | null,
): string {
    return [
        firstName?.trim(),
        lastName?.trim(),
    ]
    .filter(Boolean)
    .join(" ") || "KARMASS member";
}

function formatDate(
    value?: string | null,
): string {
    if (!value) {
        return "Not available";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "Not available";
    }

    return new Intl.DateTimeFormat(
        "en-NG",
        {
            day: "numeric",
            month: "long",
            year: "numeric",
        },
    ).format(date);
}

function getErrorMessage(
    error: unknown,
    fallback: string,
): string {
    if (
        error instanceof Error
        && error.message.trim()
    ) {
        return error.message;
    }

    return fallback;

}

function SectionHeading({
    eyebrow,
    title,
    description,
}: {
    eyebrow: string;
    title: string;
    description: string;
}) {
    return ( 
        <div className="mb-6"> 
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#7008E7]">
                {eyebrow} 
            </p>

            <h2 className="mt-2 text-xl font-semibold tracking-tight text-[#261936] sm:text-2xl">
                {title}
            </h2>

            <p className="mt-2 max-w-2xl text-sm leading-6 text-[#82768F]">
                {description}
            </p>
        </div>
    );
}

function StatusMessage({
    notice,
    onDismiss,
}: {
    notice: Notice;
    onDismiss?: () => void;
}) {
    const isSuccess = notice.type === "success";

return (
    <div
        role={isSuccess ? "status" : "alert"}
        className={[
            "flex items-start gap-3 rounded-2xl border p-4",
            isSuccess
                ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                : "border-red-200 bg-red-50 text-red-700",
        ].join(" ")}
    >
        {isSuccess ? (
            <CheckCircle2
                size={19}
                className="mt-0.5 shrink-0"
            />
        ) : (
            <AlertCircle
                size={19}
                className="mt-0.5 shrink-0"
            />
        )}

        <p className="min-w-0 flex-1 text-sm leading-6">
            {notice.message}
        </p>

        {onDismiss ? (
            <button
                type="button"
                onClick={onDismiss}
                aria-label="Dismiss message"
                className="rounded-lg p-1 transition hover:bg-black/5"
            >
                <X size={16} />
            </button>
        ) : null}
    </div>
);

}

function LoadingPanel({
message,
}: {
message: string;
}) {
return ( <div className="flex min-h-[220px] flex-col items-center justify-center rounded-3xl border border-[#eee5f7] bg-white px-6 py-12 text-center shadow-sm"> <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#f2eaff] text-[#7008E7]"> <LoaderCircle
                 size={23}
                 className="animate-spin"
             /> </div>

```
        <p className="mt-4 text-sm font-semibold text-[#352443]">
            {message}
        </p>

        <p className="mt-1 text-xs text-[#91849E]">
            Please wait a moment.
        </p>
    </div>
);

}

function Toggle({
checked,
disabled,
onChange,
label,
}: {
checked: boolean;
disabled?: boolean;
onChange: () => void;
label: string;
}) {
return (
<button
type="button"
role="switch"
aria-checked={checked}
aria-label={label}
disabled={disabled}
onClick={onChange}
className={[
"relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition-colors duration-200",
"focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#7008E7]/20",
checked
? "bg-[#7008E7]"
: "bg-[#d8d0e1]",
disabled
? "cursor-not-allowed opacity-50"
: "cursor-pointer",
].join(" ")}
>
<span
className={[
"absolute h-5 w-5 rounded-full bg-white shadow-sm transition-transform duration-200",
checked
? "translate-x-6"
: "translate-x-1",
].join(" ")}
/> </button>
);
}

export default function UserProfilePage() {
const router = useRouter();
const queryClient = useQueryClient();

const profileQuery = useUserProfile();
const privacyQuery = useUserPrivacySettings();

const updateProfile = useUpdateUserProfile();
const updatePrivacy = useUpdateUserPrivacySettings();
const deleteAccount = useDeleteUserAccount();

const user = profileQuery.data;
const privacy = privacyQuery.data;

const [firstName, setFirstName] = useState("");
const [lastName, setLastName] = useState("");
const [phone, setPhone] = useState("");

const [notice, setNotice] = useState<Notice | null>(null);

const [isDeleteDialogOpen, setIsDeleteDialogOpen] =
    useState(false);

const [deleteConfirmation, setDeleteConfirmation] =
    useState("");

const [deleteError, setDeleteError] =
    useState("");

const [privacyError, setPrivacyError] =
    useState("");

/*
 * Populate the form after the profile query resolves.
 */
useEffect(() => {
    if (!user) {
        return;
    }

    setFirstName(user.firstName ?? "");
    setLastName(user.lastName ?? "");
    setPhone(user.phone ?? "");
}, [
    user?.id,
    user?.firstName,
    user?.lastName,
    user?.phone,
]);

const isProfileDirty = Boolean(
    user
    && (
        firstName !== (user.firstName ?? "")
        || lastName !== (user.lastName ?? "")
        || phone !== (user.phone ?? "")
    ),
);

async function handleProfileSubmit(
    event: FormEvent<HTMLFormElement>,
): Promise<void> {
    event.preventDefault();

    if (!user || updateProfile.isPending) {
        return;
    }

    const normalizedFirstName = firstName.trim();
    const normalizedLastName = lastName.trim();
    const normalizedPhone = phone.trim();

    if (
        normalizedFirstName.length < 2
        || normalizedFirstName.length > 100
    ) {
        setNotice({
            type: "error",
            message:
                "First name must contain between 2 and 100 characters.",
        });

        return;
    }

    if (
        normalizedLastName.length < 2
        || normalizedLastName.length > 100
    ) {
        setNotice({
            type: "error",
            message:
                "Last name must contain between 2 and 100 characters.",
        });

        return;
    }

    if (
        normalizedPhone
        && (
            normalizedPhone.length < 7
            || normalizedPhone.length > 30
            || !/^[+0-9().\-\s]+$/.test(normalizedPhone)
        )
    ) {
        setNotice({
            type: "error",
            message:
                "Enter a valid phone number using digits and standard phone-number characters.",
        });

        return;
    }

    setNotice(null);

    try {
        await updateProfile.mutateAsync({
            firstName: normalizedFirstName,
            lastName: normalizedLastName,
            phone: normalizedPhone || null,
        });

        setNotice({
            type: "success",
            message: "Your profile has been updated successfully.",
        });

        /*
         * Refresh the authenticated user as well, because
         * dashboard greetings and other components may use it.
         */
        await queryClient.invalidateQueries({
            queryKey: queryKeys.auth.currentUser(),
        });
    } catch (error: unknown) {
        setNotice({
            type: "error",
            message: getErrorMessage(
                error,
                "We couldn't update your profile. Please try again.",
            ),
        });
    }
}

async function handlePrivacyChange(
    key: keyof NonNullable<typeof privacy>,
    nextValue: boolean,
): Promise<void> {
    if (!privacy || updatePrivacy.isPending) {
        return;
    }

    setPrivacyError("");

    try {
        await updatePrivacy.mutateAsync({
            [key]: nextValue,
        });

        setNotice({
            type: "success",
            message: "Your privacy settings have been saved.",
        });
    } catch (error: unknown) {
        setPrivacyError(
            getErrorMessage(
                error,
                "We couldn't save this privacy setting. Please try again.",
            ),
        );
    }
}

async function handleDeleteAccount(): Promise<void> {
    if (
        deleteConfirmation.trim() !== "DELETE"
        || deleteAccount.isPending
    ) {
        return;
    }

    setDeleteError("");

    try {
        await deleteAccount.mutateAsync();

        /*
         * The backend has deleted the account and cleared its
         * session cookie. Clear cached user data before redirecting.
         */
        await queryClient.cancelQueries();

        queryClient.clear();

        router.replace("/login");
        router.refresh();
    } catch (error: unknown) {
        setDeleteError(
            getErrorMessage(
                error,
                "We couldn't delete your account. Please try again.",
            ),
        );
    }
}

const profileLoadFailed =
    profileQuery.isError && !user;

const privacyLoadFailed =
    privacyQuery.isError && !privacy;

const displayName = getDisplayName(
    user?.firstName,
    user?.lastName,
);

const initials = getInitials(
    user?.firstName,
    user?.lastName,
);

return (
    <main className="min-h-screen bg-[#faf8fc] text-[#261936]">
        <div className="mx-auto w-full max-w-7xl px-4 pb-12 pt-6 sm:px-6 sm:pt-9 lg:px-8 lg:pb-16">
            {/* Page heading */}
            <div className="mb-8">
                <button
                    type="button"
                    onClick={() => router.push("/dashboard")}
                    className="mb-5 inline-flex items-center gap-2 rounded-xl text-sm font-medium text-[#81738F] transition hover:text-[#7008E7]"
                >
                    <ArrowLeft size={17} />
                    Back to dashboard
                </button>

                <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
                    <div>
                        <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.18em] text-[#7008E7]">
                            <span className="h-2 w-2 rounded-full bg-[#7008E7]" />
                            Account settings
                        </div>

                        <h1 className="mt-3 text-3xl font-semibold tracking-[-0.045em] text-[#261936] sm:text-4xl">
                            My profile
                        </h1>

                        <p className="mt-3 max-w-2xl text-sm leading-6 text-[#82768F] sm:text-base">
                            Manage your personal information, account
                            preferences, and privacy in one place.
                        </p>
                    </div>

                    {user ? (
                        <div className="flex items-center gap-3 self-start rounded-2xl border border-[#eee5f7] bg-white px-4 py-3 shadow-sm sm:self-auto">
                            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#f0e7ff] text-sm font-bold text-[#7008E7]">
                                {initials}
                            </div>

                            <div className="min-w-0">
                                <p className="max-w-[220px] truncate text-sm font-semibold text-[#352443]">
                                    {displayName}
                                </p>

                                <p className="max-w-[220px] truncate text-xs text-[#91849E]">
                                    {user.email}
                                </p>
                            </div>
                        </div>
                    ) : null}
                </div>
            </div>

            <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
                {/* Main content */}
                <div className="min-w-0 space-y-6">
                    {notice ? (
                        <StatusMessage
                            notice={notice}
                            onDismiss={() => setNotice(null)}
                        />
                    ) : null}

                    {/* Personal information */}
                    <section
                        id="personal-information"
                        className="rounded-3xl border border-[#eee5f7] bg-white p-5 shadow-[0_8px_35px_rgba(48,20,75,0.035)] sm:p-7"
                    >
                        <SectionHeading
                            eyebrow="Personal details"
                            title="Personal information"
                            description="Keep your name and contact information up to date."
                        />

                        {profileQuery.isLoading ? (
                            <LoadingPanel
                                message="Loading your profile"
                            />
                        ) : profileLoadFailed ? (
                            <StatusMessage
                                notice={{
                                    type: "error",
                                    message:
                                        "We couldn't load your profile. Check your connection and try again.",
                                }}
                            />
                        ) : user ? (
                            <form
                                onSubmit={handleProfileSubmit}
                                className="space-y-6"
                            >
                                <div className="flex flex-col gap-4 rounded-2xl bg-[#faf8fc] p-4 sm:flex-row sm:items-center">
                                    <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-[#f0e7ff] text-xl font-bold text-[#7008E7]">
                                        {initials}
                                    </div>

                                    <div className="min-w-0">
                                        <p className="font-semibold text-[#352443]">
                                            {displayName}
                                        </p>

                                        <p className="mt-1 text-sm text-[#91849E]">
                                            Your account identity
                                        </p>

                                        <p className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-[#6c5b7b]">
                                            <ShieldCheck
                                                size={14}
                                                className="text-[#7008E7]"
                                            />
                                            Personal account details
                                        </p>
                                    </div>
                                </div>

                                <div className="grid gap-5 sm:grid-cols-2">
                                    <div>
                                        <label
                                            htmlFor="firstName"
                                            className="mb-2 block text-sm font-semibold text-[#473753]"
                                        >
                                            First name
                                        </label>

                                        <div className="relative">
                                            <UserRound
                                                size={17}
                                                className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#9c8cac]"
                                            />

                                            <input
                                                id="firstName"
                                                name="firstName"
                                                type="text"
                                                autoComplete="given-name"
                                                required
                                                minLength={2}
                                                maxLength={100}
                                                value={firstName}
                                                onChange={(event) => {
                                                    setFirstName(
                                                        event.target.value,
                                                    );
                                                    setNotice(null);
                                                }}
                                                className="h-12 w-full rounded-xl border border-[#e9e0f1] bg-white pl-11 pr-4 text-sm text-[#352443] outline-none transition placeholder:text-[#b2a7bd] focus:border-[#7008E7] focus:ring-4 focus:ring-[#7008E7]/10"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label
                                            htmlFor="lastName"
                                            className="mb-2 block text-sm font-semibold text-[#473753]"
                                        >
                                            Last name
                                        </label>

                                        <div className="relative">
                                            <UserRound
                                                size={17}
                                                className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#9c8cac]"
                                            />

                                            <input
                                                id="lastName"
                                                name="lastName"
                                                type="text"
                                                autoComplete="family-name"
                                                required
                                                minLength={2}
                                                maxLength={100}
                                                value={lastName}
                                                onChange={(event) => {
                                                    setLastName(
                                                        event.target.value,
                                                    );
                                                    setNotice(null);
                                                }}
                                                className="h-12 w-full rounded-xl border border-[#e9e0f1] bg-white pl-11 pr-4 text-sm text-[#352443] outline-none transition placeholder:text-[#b2a7bd] focus:border-[#7008E7] focus:ring-4 focus:ring-[#7008E7]/10"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label
                                            htmlFor="profileEmail"
                                            className="mb-2 block text-sm font-semibold text-[#473753]"
                                        >
                                            Email address
                                        </label>

                                        <div className="relative">
                                            <Mail
                                                size={17}
                                                className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#9c8cac]"
                                            />

                                            <input
                                                id="profileEmail"
                                                type="email"
                                                value={user.email}
                                                readOnly
                                                aria-describedby="email-help"
                                                className="h-12 w-full cursor-not-allowed rounded-xl border border-[#eee7f4] bg-[#faf8fc] pl-11 pr-4 text-sm text-[#82768F] outline-none"
                                            />
                                        </div>

                                        <p
                                            id="email-help"
                                            className="mt-2 text-xs leading-5 text-[#91849E]"
                                        >
                                            Your email is used for account access.
                                            Email changes aren't available here.
                                        </p>
                                    </div>

                                    <div>
                                        <label
                                            htmlFor="profilePhone"
                                            className="mb-2 block text-sm font-semibold text-[#473753]"
                                        >
                                            Phone number
                                        </label>

                                        <div className="relative">
                                            <Phone
                                                size={17}
                                                className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#9c8cac]"
                                            />

                                            <input
                                                id="profilePhone"
                                                name="phone"
                                                type="tel"
                                                autoComplete="tel"
                                                maxLength={30}
                                                value={phone}
                                                onChange={(event) => {
                                                    setPhone(
                                                        event.target.value,
                                                    );
                                                    setNotice(null);
                                                }}
                                                placeholder="+234 800 000 0000"
                                                className="h-12 w-full rounded-xl border border-[#e9e0f1] bg-white pl-11 pr-4 text-sm text-[#352443] outline-none transition placeholder:text-[#b2a7bd] focus:border-[#7008E7] focus:ring-4 focus:ring-[#7008E7]/10"
                                            />
                                        </div>

                                        <p className="mt-2 text-xs leading-5 text-[#91849E]">
                                            Leave empty to remove your phone number.
                                        </p>
                                    </div>
                                </div>

                                <div className="flex flex-col gap-3 border-t border-[#f0e9f5] pt-5 sm:flex-row sm:items-center sm:justify-between">
                                    <p className="text-xs leading-5 text-[#91849E]">
                                        Changes are saved to your KARMASS account.
                                    </p>

                                    <button
                                        type="submit"
                                        disabled={
                                            !isProfileDirty
                                            || updateProfile.isPending
                                        }
                                        className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-[#7008E7] px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-[#5f05c9] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#7008E7]/20 disabled:cursor-not-allowed disabled:opacity-50"
                                    >
                                        {updateProfile.isPending ? (
                                            <LoaderCircle
                                                size={17}
                                                className="animate-spin"
                                            />
                                        ) : (
                                            <Save size={17} />
                                        )}

                                        {updateProfile.isPending
                                            ? "Saving changes..."
                                            : "Save changes"}
                                    </button>
                                </div>
                            </form>
                        ) : null}
                    </section>

                    {/* Account information */}
                    <section
                        id="account-information"
                        className="rounded-3xl border border-[#eee5f7] bg-white p-5 shadow-[0_8px_35px_rgba(48,20,75,0.035)] sm:p-7"
                    >
                        <SectionHeading
                            eyebrow="Account overview"
                            title="Account information"
                            description="Review the information associated with your KARMASS membership."
                        />

                        {profileQuery.isLoading ? (
                            <LoadingPanel
                                message="Loading account information"
                            />
                        ) : user ? (
                            <div className="divide-y divide-[#f1ebf6]">
                                <div className="flex items-center justify-between gap-4 py-4 first:pt-0">
                                    <div className="flex min-w-0 items-center gap-3">
                                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#f5efff] text-[#7008E7]">
                                            <Mail size={18} />
                                        </div>

                                        <div className="min-w-0">
                                            <p className="text-sm font-semibold text-[#473753]">
                                                Email verification
                                            </p>

                                            <p className="mt-1 text-xs text-[#91849E]">
                                                Your email address status
                                            </p>
                                        </div>
                                    </div>

                                    <span
                                        className={[
                                            "inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold",
                                            user.emailVerified
                                                ? "bg-emerald-50 text-emerald-700"
                                                : "bg-amber-50 text-amber-700",
                                        ].join(" ")}
                                    >
                                        {user.emailVerified ? (
                                            <Check size={13} />
                                        ) : (
                                            <Clock3 size={13} />
                                        )}

                                        {user.emailVerified
                                            ? "Verified"
                                            : "Not verified"}
                                    </span>
                                </div>

                                <div className="flex items-center justify-between gap-4 py-4">
                                    <div className="flex min-w-0 items-center gap-3">
                                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#f5efff] text-[#7008E7]">
                                            <ShieldCheck size={18} />
                                        </div>

                                        <div className="min-w-0">
                                            <p className="text-sm font-semibold text-[#473753]">
                                                Account type
                                            </p>

                                            <p className="mt-1 text-xs text-[#91849E]">
                                                Your membership category
                                            </p>
                                        </div>
                                    </div>

                                    <span className="max-w-[45%] truncate rounded-full bg-[#f5efff] px-3 py-1.5 text-xs font-semibold capitalize text-[#7008E7]">
                                        {user.accountType
                                            .replace(/[_-]+/g, " ")
                                            .toLowerCase()}
                                    </span>
                                </div>

                                <div className="flex items-center justify-between gap-4 py-4">
                                    <div className="flex min-w-0 items-center gap-3">
                                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#f5efff] text-[#7008E7]">
                                            <CheckCircle2 size={18} />
                                        </div>

                                        <div className="min-w-0">
                                            <p className="text-sm font-semibold text-[#473753]">
                                                Account status
                                            </p>

                                            <p className="mt-1 text-xs text-[#91849E]">
                                                Current account standing
                                            </p>
                                        </div>
                                    </div>

                                    <span className="shrink-0 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-semibold capitalize text-emerald-700">
                                        {user.status
                                            .replace(/[_-]+/g, " ")
                                            .toLowerCase()}
                                    </span>
                                </div>

                                <div className="flex items-center justify-between gap-4 py-4 last:pb-0">
                                    <div className="flex min-w-0 items-center gap-3">
                                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#f5efff] text-[#7008E7]">
                                            <Clock3 size={18} />
                                        </div>

                                        <div className="min-w-0">
                                            <p className="text-sm font-semibold text-[#473753]">
                                                Member since
                                            </p>

                                            <p className="mt-1 text-xs text-[#91849E]">
                                                When your account was created
                                            </p>
                                        </div>
                                    </div>

                                    <span className="shrink-0 text-right text-xs font-semibold text-[#473753] sm:text-sm">
                                        {formatDate(user.createdAt)}
                                    </span>
                                </div>
                            </div>
                        ) : profileLoadFailed ? (
                            <StatusMessage
                                notice={{
                                    type: "error",
                                    message:
                                        "Account information is currently unavailable.",
                                }}
                            />
                        ) : null}
                    </section>

                    {/* Privacy settings */}
                    <section
                        id="privacy-settings"
                        className="rounded-3xl border border-[#eee5f7] bg-white p-5 shadow-[0_8px_35px_rgba(48,20,75,0.035)] sm:p-7"
                    >
                        <SectionHeading
                            eyebrow="Your preferences"
                            title="Privacy settings"
                            description="Choose how your information and communication preferences are handled."
                        />

                        {privacyError ? (
                            <div className="mb-5">
                                <StatusMessage
                                    notice={{
                                        type: "error",
                                        message: privacyError,
                                    }}
                                />
                            </div>
                        ) : null}

                        {privacyQuery.isLoading ? (
                            <LoadingPanel
                                message="Loading privacy settings"
                            />
                        ) : privacyLoadFailed ? (
                            <div className="space-y-4">
                                <StatusMessage
                                    notice={{
                                        type: "error",
                                        message:
                                            "We couldn't load your privacy settings.",
                                    }}
                                />

                                <button
                                    type="button"
                                    onClick={() => {
                                        void privacyQuery.refetch();
                                    }}
                                    className="rounded-xl border border-[#e9e0f1] px-4 py-2.5 text-sm font-semibold text-[#7008E7] transition hover:bg-[#faf7ff]"
                                >
                                    Try again
                                </button>
                            </div>
                        ) : privacy ? (
                            <div className="divide-y divide-[#f1ebf6]">
                                {PRIVACY_OPTIONS.map((option) => (
                                    <div
                                        key={option.key}
                                        className="flex items-center justify-between gap-4 py-5 first:pt-0 last:pb-0"
                                    >
                                        <div className="min-w-0 pr-2">
                                            <p className="text-sm font-semibold text-[#473753]">
                                                {option.title}
                                            </p>

                                            <p className="mt-1.5 max-w-xl text-xs leading-5 text-[#91849E] sm:text-sm sm:leading-6">
                                                {option.description}
                                            </p>
                                        </div>

                                        <Toggle
                                            label={option.title}
                                            checked={privacy[option.key]}
                                            disabled={
                                                updatePrivacy.isPending
                                            }
                                            onChange={() => {
                                                void handlePrivacyChange(
                                                    option.key,
                                                    !privacy[option.key],
                                                );
                                            }}
                                        />
                                    </div>
                                ))}
                            </div>
                        ) : null}

                        <div className="mt-6 flex items-start gap-3 rounded-2xl border border-[#eee5f7] bg-[#faf8fc] p-4">
                            <LockKeyhole
                                size={18}
                                className="mt-0.5 shrink-0 text-[#7008E7]"
                            />

                            <p className="text-xs leading-5 text-[#82768F]">
                                Privacy preferences are saved to your account.
                                Public visibility also depends on how each
                                feature is implemented across KARMASS.
                            </p>
                        </div>
                    </section>

                    {/* Danger zone */}
                    <section
                        id="danger-zone"
                        className="overflow-hidden rounded-3xl border border-red-200 bg-white shadow-[0_8px_35px_rgba(48,20,75,0.035)]"
                    >
                        <div className="border-b border-red-100 bg-red-50/70 px-5 py-5 sm:px-7">
                            <div className="flex items-center gap-3">
                                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-red-100 text-red-600">
                                    <Trash2 size={20} />
                                </div>

                                <div>
                                    <h2 className="text-lg font-semibold text-red-800">
                                        Danger zone
                                    </h2>

                                    <p className="mt-1 text-xs leading-5 text-red-700/80">
                                        Actions that permanently affect your account access.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="flex flex-col gap-5 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-7">
                            <div className="max-w-xl">
                                <h3 className="text-sm font-semibold text-[#352443]">
                                    Delete my account
                                </h3>

                                <p className="mt-2 text-sm leading-6 text-[#82768F]">
                                    Your account will be anonymized, your
                                    active listings will be suspended, and
                                    your sessions will be revoked. This
                                    action cannot be undone through this page.
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={() => {
                                    setDeleteConfirmation("");
                                    setDeleteError("");
                                    setIsDeleteDialogOpen(true);
                                }}
                                className="inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-xl border border-red-200 bg-white px-4 py-3 text-sm font-semibold text-red-600 transition hover:border-red-300 hover:bg-red-50 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-red-100"
                            >
                                <Trash2 size={16} />
                                Delete account
                            </button>
                        </div>
                    </section>
                </div>

                {/* Desktop side panel */}
                <aside className="space-y-5 xl:sticky xl:top-6">
                    <div className="overflow-hidden rounded-3xl bg-[#2b1740] p-6 text-white shadow-[0_12px_40px_rgba(43,23,64,0.14)] hidden md:block">
                        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-white">
                            <ShieldCheck size={24} />
                        </div>

                        <h2 className="mt-5 text-xl font-semibold tracking-tight">
                            Your account,
                            <br />
                            your control.
                        </h2>

                        <p className="mt-3 text-sm leading-6 text-white/65">
                            Keep your information accurate and choose
                            the privacy preferences that work for you.
                        </p>

                        <div className="mt-6 space-y-4">
                            <a
                                href="#personal-information"
                                className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium transition hover:bg-white/10"
                            >
                                Personal information
                                <ChevronRight size={17} />
                            </a>

                            <a
                                href="#account-information"
                                className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium transition hover:bg-white/10"
                            >
                                Account information
                                <ChevronRight size={17} />
                            </a>

                            <a
                                href="#privacy-settings"
                                className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium transition hover:bg-white/10"
                            >
                                Privacy settings
                                <ChevronRight size={17} />
                            </a>
                        </div>
                    </div>

                    <div className="rounded-3xl border border-[#eee5f7] bg-white p-5 shadow-sm">
                        <div className="flex items-start gap-3">
                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#f5efff] text-[#7008E7]">
                                <LockKeyhole size={18} />
                            </div>

                            <div>
                                <h3 className="text-sm font-semibold text-[#352443]">
                                    Protect your account
                                </h3>

                                <p className="mt-2 text-xs leading-5 text-[#91849E]">
                                    Never share your password or
                                    verification codes with anyone.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="rounded-3xl border border-[#eee5f7] bg-white p-5 shadow-sm">
                        <div className="flex items-start gap-3">
                            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#f5efff] text-[#7008E7]">
                                <AlertCircle size={18} />
                            </div>

                            <div>
                                <h3 className="text-sm font-semibold text-[#352443]">
                                    Need help?
                                </h3>

                                <p className="mt-2 text-xs leading-5 text-[#91849E]">
                                    If you need assistance with your account,
                                    contact the KARMASS support team.
                                </p>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>
        </div>

        {/* Account deletion confirmation */}
        {isDeleteDialogOpen ? (
            <div
                className="fixed inset-0 z-500 flex items-end justify-center bg-[#1d1028]/60 p-0 backdrop-blur-sm sm:items-center sm:p-5"
                onMouseDown={(event) => {
                    if (
                        event.target === event.currentTarget
                        && !deleteAccount.isPending
                    ) {
                        setIsDeleteDialogOpen(false);
                    }
                }}
            >
                <section
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="delete-dialog-title"
                    className="w-full max-w-lg rounded-t-3xl border border-[#f1e7f7] bg-white p-5 shadow-2xl sm:rounded-3xl sm:p-7"
                >
                    <div className="flex items-start gap-4">
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-red-100 text-red-600">
                            <Trash2 size={23} />
                        </div>

                        <div className="min-w-0 flex-1">
                            <h2
                                id="delete-dialog-title"
                                className="text-xl font-semibold tracking-tight text-[#261936]"
                            >
                                Delete your account?
                            </h2>

                            <p className="mt-2 text-sm leading-6 text-[#82768F]">
                                This will deactivate your account,
                                anonymize your profile, suspend your
                                listings, and revoke your sessions.
                                You will be signed out.
                            </p>
                        </div>

                        <button
                            type="button"
                            aria-label="Close confirmation"
                            disabled={deleteAccount.isPending}
                            onClick={() => {
                                setIsDeleteDialogOpen(false);
                            }}
                            className="rounded-xl p-2 text-[#91849E] transition hover:bg-[#f5eff9] hover:text-[#352443] disabled:opacity-50"
                        >
                            <X size={19} />
                        </button>
                    </div>

                    <div className="mt-6 rounded-2xl border border-red-100 bg-red-50 p-4">
                        <p className="text-sm font-semibold text-red-800">
                            This action cannot be undone through your account.
                        </p>

                        <p className="mt-1.5 text-xs leading-5 text-red-700/80">
                            Your account records may be retained where
                            necessary for platform integrity and related
                            records. Your profile will be anonymized.
                        </p>
                    </div>

                    {deleteError ? (
                        <div className="mt-5">
                            <StatusMessage
                                notice={{
                                    type: "error",
                                    message: deleteError,
                                }}
                            />
                        </div>
                    ) : null}

                    <div className="mt-6">
                        <label
                            htmlFor="deleteConfirmation"
                            className="mb-2 block text-sm font-semibold text-[#473753]"
                        >
                            Type{" "}
                            <span className="font-bold text-red-600">
                                DELETE
                            </span>{" "}
                            to confirm
                        </label>

                        <input
                            id="deleteConfirmation"
                            type="text"
                            autoComplete="off"
                            spellCheck={false}
                            value={deleteConfirmation}
                            disabled={deleteAccount.isPending}
                            onChange={(event) => {
                                setDeleteConfirmation(
                                    event.target.value,
                                );
                            }}
                            placeholder="Type DELETE"
                            className="h-12 w-full rounded-xl border border-[#e9e0f1] bg-white px-4 text-sm text-[#352443] outline-none transition placeholder:text-[#b2a7bd] focus:border-red-400 focus:ring-4 focus:ring-red-100 disabled:bg-gray-50"
                        />
                    </div>

                    <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                        <button
                            type="button"
                            disabled={deleteAccount.isPending}
                            onClick={() => {
                                setIsDeleteDialogOpen(false);
                                setDeleteError("");
                            }}
                            className="inline-flex min-h-11 items-center justify-center rounded-xl border border-[#e9e0f1] px-5 py-3 text-sm font-semibold text-[#6e5e7d] transition hover:bg-[#faf8fc] disabled:opacity-50"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            disabled={
                                deleteConfirmation.trim() !== "DELETE"
                                || deleteAccount.isPending
                            }
                            onClick={() => {
                                void handleDeleteAccount();
                            }}
                            className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-red-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-red-700 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-red-200 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            {deleteAccount.isPending ? (
                                <LoaderCircle
                                    size={17}
                                    className="animate-spin"
                                />
                            ) : (
                                <Trash2 size={16} />
                            )}

                            {deleteAccount.isPending
                                ? "Deleting account..."
                                : "Delete my account"}
                        </button>
                    </div>
                </section>
            </div>
        ) : null}
    </main>
);

}
