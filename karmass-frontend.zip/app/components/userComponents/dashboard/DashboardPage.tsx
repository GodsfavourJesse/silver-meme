"use client";

import { useState } from "react";

import Link from "next/link";
import { useRouter } from "next/navigation";

import { useQueryClient } from "@tanstack/react-query";

import {
    ArrowRight,
    ArrowUpRight,
    Bell,
    Bookmark,
    CarFront,
    Check,
    CheckCircle2,
    ChevronRight,
    CircleHelp,
    CircleUserRound,
    CreditCard,
    LogOut,
    MessageCircle,
    Plus,
    Search,
    Settings2,
    ShieldCheck,
    Sparkles,
    Store,
    UserRound,
    WalletCards,
    type LucideIcon,
} from "lucide-react";

import { useAuth } from "@/app/hooks/user/auth/useAuth";

import { authService } from "@/app/services/user/auth/auth.service";

import { queryKeys } from "@/app/lib/query/query-keys";
import { CurrentYear } from "../../auth/CurrentYear";

const BRAND = "#7008E7";

interface DashboardAction {
    title: string;
    description: string;
    href: string;
    icon: LucideIcon;
    shortLabel: string;
}

const primaryActions: DashboardAction[] = [
    {
        title: "My listings",
        shortLabel: "My listings",
        description: "Manage your vehicle advertisements.",
        href: "/dashboard/my-listings",
        icon: CarFront,
    },
    {
        title: "Saved vehicles",
        shortLabel: "Saved",
        description: "Return to vehicles you have bookmarked.",
        href: "/saved-vehicles",
        icon: Bookmark,
    },
    {
        title: "Messages",
        shortLabel: "Messages",
        description: "Continue your buyer and seller conversations.",
        href: "/dashboard/messages",
        icon: MessageCircle,
    },
    {
        title: "Notifications",
        shortLabel: "Updates",
        description: "Review updates about your account.",
        href: "/notifications",
        icon: Bell,
    },
];

const accountActions: DashboardAction[] = [
    {
        title: "Subscriptions",
        shortLabel: "Subscriptions",
        description: "Review your subscription and billing details.",
        href: "/subscriptions",
        icon: CreditCard,
    },
    {
        title: "Account settings",
        shortLabel: "Settings",
        description: "Manage your personal information and preferences.",
        href: "/settings",
        icon: Settings2,
    },
];

function getInitials(
    firstName?: string | null,
    lastName?: string | null,
): string {
    const first = firstName?.trim().charAt(0) ?? "";
    const last = lastName?.trim().charAt(0) ?? "";

    return `${first}${last}`.toUpperCase() || "K";
}

function getDisplayName(
    firstName?: string | null,
    lastName?: string | null,
): string {
    const first = firstName?.trim() ?? "";
    const last = lastName?.trim() ?? "";

    return [first, last].filter(Boolean).join(" ") || "KARMASS member";
}

function DashboardHeader() {
    const { user } = useAuth();

    const router = useRouter();
    const queryClient = useQueryClient();

    const [isLoggingOut, setIsLoggingOut] = useState(false);
    const [logoutError, setLogoutError] = useState("");

    async function handleLogout(): Promise<void> {
        if (isLoggingOut) {
            return;
        }

        setIsLoggingOut(true);
        setLogoutError("");

        try {
            await authService.logout();
        } catch {
            setLogoutError(
                "We couldn't confirm that your session was closed. Please sign in again.",
            );
        } finally {
            await queryClient.cancelQueries({
                queryKey: queryKeys.auth.all,
            });

            queryClient.removeQueries({
                queryKey: queryKeys.auth.all,
            });

            queryClient.clear();

            router.replace("/login");
            router.refresh();
        }
    }

    const firstName = user?.firstName?.trim();
    const initials = getInitials(user?.firstName, user?.lastName);

    return (
        <>
            {/* Desktop header */}
            <header className="hidden items-center justify-between gap-6 xl:flex">
                <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.17em] text-[#8f7da3]">
                        <span className="h-2 w-2 rounded-full bg-[#7008E7]" />
                        Your personal dashboard
                    </div>

                    <h1 className="mt-3 text-[34px] font-semibold tracking-[-0.055em] text-[#261936] 2xl:text-[40px]">
                        Welcome back
                        {firstName ? (
                            <>
                                {", "}
                                <span className="text-[#7008E7]">
                                    {firstName}
                                </span>
                            </>
                        ) : null}
                        .
                    </h1>

                    <p className="mt-2 text-sm leading-6 text-[#8c8099]">
                        Everything you need for your automotive journey,
                        all in one place.
                    </p>
                </div>

                <div className="flex shrink-0 items-center gap-3">
                    <Link
                        href="/notifications"
                        aria-label="View notifications"
                        className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[#eee5f7] bg-white text-[#78668d] shadow-sm transition hover:border-[#d9c2fa] hover:text-[#7008E7]"
                    >
                        <Bell size={19} strokeWidth={1.8} />
                    </Link>

                    <div className="flex items-center gap-3 rounded-2xl border border-[#eee5f7] bg-white py-2 pl-2 pr-4 shadow-sm">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f0e7ff] text-sm font-bold text-[#7008E7]">
                            {initials}
                        </div>

                        <div className="min-w-0">
                            <p className="max-w-[180px] truncate text-sm font-semibold text-[#352443]">
                                {getDisplayName(
                                    user?.firstName,
                                    user?.lastName,
                                )}
                            </p>

                            <p className="max-w-[180px] truncate text-xs text-[#988ba5]">
                                {user?.email || "Your KARMASS account"}
                            </p>
                        </div>
                    </div>

                    <button
                        type="button"
                        onClick={handleLogout}
                        disabled={isLoggingOut}
                        className="inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl px-3 text-sm font-medium text-[#8b7b9b] transition hover:bg-white hover:text-[#7008E7] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <LogOut size={16} />
                        {isLoggingOut ? "Signing out..." : "Sign out"}
                    </button>
                </div>
            </header>

            {/* Mobile and tablet app header */}
            <header className="xl:hidden">
                <div className="flex items-center justify-between gap-3">
                    <Link
                        href="/dashboard"
                        aria-label="KARMASS dashboard"
                        className="flex min-w-0 items-center gap-2.5"
                    >
                        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[16px] bg-[#7008E7] text-white shadow-[0_6px_18px_rgba(112,8,231,0.2)]">
                            <CarFront size={23} strokeWidth={1.9} />
                        </span>

                        <span className="min-w-0">
                            <span className="block text-[17px] font-extrabold tracking-[-0.06em] text-[#2b1a3a]">
                                KAR<span className="text-[#7008E7]">MASS</span>
                            </span>

                            <span className="mt-0.5 block text-[10px] font-medium tracking-[0.11em] text-[#9b8ca8]">
                                YOUR AUTOMOTIVE SPACE
                            </span>
                        </span>
                    </Link>

                    <div className="flex shrink-0 items-center gap-2">
                        <Link
                            href="/notifications"
                            aria-label="Notifications"
                            className="relative flex h-11 w-11 items-center justify-center rounded-2xl border border-[#eee5f7] bg-white text-[#756486] shadow-[0_3px_12px_rgba(45,18,78,0.03)] transition hover:text-[#7008E7]"
                        >
                            <Bell size={19} strokeWidth={1.8} />
                        </Link>

                        <button
                            type="button"
                            onClick={handleLogout}
                            disabled={isLoggingOut}
                            aria-label="Sign out"
                            className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[#eee5f7] bg-white text-[#756486] transition hover:text-[#7008E7] disabled:opacity-50"
                        >
                            <LogOut size={18} />
                        </button>
                    </div>
                </div>

                <div className="mt-7 flex items-center gap-3">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[17px] border border-[#e5d5fb] bg-gradient-to-br from-[#f4eaff] to-[#e9d8ff] text-sm font-bold text-[#7008E7]">
                        {initials}
                    </div>

                    <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium text-[#95869f]">
                            Welcome back,
                        </p>

                        <h1 className="mt-0.5 truncate text-[23px] font-bold tracking-[-0.055em] text-[#2b1a3a]">
                            {firstName || "Driver"}
                            <span className="text-[#7008E7]">.</span>
                        </h1>
                    </div>

                    <Link
                        href="/settings"
                        aria-label="Account settings"
                        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white text-[#8c7a9d] ring-1 ring-[#eee5f7] transition hover:text-[#7008E7]"
                    >
                        <UserRound size={18} />
                    </Link>
                </div>
            </header>

            {logoutError && (
                <p
                    role="status"
                    className="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm leading-6 text-amber-800"
                >
                    {logoutError}
                </p>
            )}
        </>
    );
}

function DesktopWelcomeCard() {
    return (
        <section className="relative isolate overflow-hidden rounded-[30px] border border-[#e9dcfa] bg-gradient-to-br from-white via-[#fcf9ff] to-[#f0e5ff] p-7 shadow-[0_8px_32px_rgba(60,25,90,0.025)] lg:p-9 2xl:p-11">
            <div
                aria-hidden="true"
                className="pointer-events-none absolute -right-20 -top-24 -z-10 h-80 w-80 rounded-full bg-[#7008E7]/[0.09] blur-[85px]"
            />

            <div
                aria-hidden="true"
                className="pointer-events-none absolute -bottom-24 right-[25%] -z-10 h-52 w-52 rounded-full bg-[#c4a0ff]/[0.19] blur-[70px]"
            />

            <div className="grid items-center gap-8 lg:grid-cols-[minmax(0,1fr)_210px] 2xl:grid-cols-[minmax(0,1fr)_250px]">
                <div className="max-w-2xl">
                    <div className="inline-flex items-center gap-2 rounded-full border border-[#e7d7ff] bg-white/85 px-3 py-1.5 backdrop-blur">
                        <Sparkles size={14} className="text-[#7008E7]" />

                        <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#7008E7]">
                            Your journey, your way
                        </span>
                    </div>

                    <h2 className="mt-5 max-w-xl text-[30px] font-semibold leading-[1.17] tracking-[-0.055em] text-[#2b1a3a] lg:text-[36px] 2xl:text-[42px]">
                        Your next great drive starts{" "}
                        <span className="text-[#7008E7]">with a choice.</span>
                    </h2>

                    <p className="mt-4 max-w-xl text-sm leading-7 text-[#82748f] lg:text-[15px]">
                        Discover vehicles, manage your listings, and connect
                        with people who share your passion for the road.
                    </p>

                    <div className="mt-7 flex flex-wrap gap-3">
                        <Link
                            href="/marketplace"
                            className="group inline-flex min-h-12 items-center justify-center gap-2.5 rounded-2xl bg-[#7008E7] px-5 text-sm font-semibold text-white shadow-[0_8px_22px_rgba(112,8,231,0.18)] transition duration-200 hover:-translate-y-0.5 hover:bg-[#5f06c7] hover:shadow-[0_12px_26px_rgba(112,8,231,0.24)] active:translate-y-0"
                        >
                            <Search size={17} />
                            Explore marketplace
                            <ArrowUpRight
                                size={16}
                                className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                            />
                        </Link>

                        <Link
                            href="/dashboard/my-listings"
                            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl border border-[#e5d7f4] bg-white/90 px-5 text-sm font-semibold text-[#5b486d] transition hover:border-[#d5baf7] hover:text-[#7008E7]"
                        >
                            <Plus size={17} />
                            Manage listings
                        </Link>
                    </div>
                </div>

                <div
                    aria-hidden="true"
                    className="relative hidden h-[210px] items-center justify-center lg:flex"
                >
                    <div className="absolute h-[200px] w-[200px] rounded-full border border-[#d9c2fa]/80" />

                    <div className="absolute h-[155px] w-[155px] rounded-full border border-[#d9c2fa]/80" />

                    <div className="absolute h-[110px] w-[110px] rounded-[35px] bg-gradient-to-br from-[#7008E7] to-[#a15af5] shadow-[0_18px_45px_rgba(112,8,231,0.23)] transition-transform duration-500 hover:scale-105">
                        <div className="flex h-full items-center justify-center text-white">
                            <CarFront size={49} strokeWidth={1.4} />
                        </div>
                    </div>

                    <div className="absolute right-0 top-5 rounded-2xl border border-white/80 bg-white/90 px-3 py-2.5 shadow-[0_8px_25px_rgba(50,22,80,0.07)] backdrop-blur-xl">
                        <div className="flex items-center gap-2">
                            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#f0e7ff] text-[#7008E7]">
                                <CheckCircle2 size={15} />
                            </span>

                            <span className="text-[10px] font-semibold text-[#554366]">
                                Your account
                                <span className="mt-0.5 block text-[#8c7a9b]">
                                    All in one place
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

function MobileWelcomeCard() {
    return (
        <section className="relative isolate overflow-hidden rounded-[27px] bg-gradient-to-br from-[#7008E7] via-[#7916e7] to-[#9b51f1] p-5 text-white shadow-[0_14px_35px_rgba(112,8,231,0.19)] sm:p-7">
            <div
                aria-hidden="true"
                className="pointer-events-none absolute -right-16 -top-20 -z-10 h-56 w-56 rounded-full border border-white/[0.12]"
            />

            <div
                aria-hidden="true"
                className="pointer-events-none absolute -right-8 -top-12 -z-10 h-40 w-40 rounded-full border border-white/[0.12]"
            />

            <div
                aria-hidden="true"
                className="pointer-events-none absolute -bottom-20 left-[40%] -z-10 h-44 w-44 rounded-full bg-white/[0.07] blur-3xl"
            />

            <div className="relative">
                <div className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/[0.12] px-3 py-1.5 backdrop-blur-sm">
                    <Sparkles size={13} />

                    <span className="text-[10px] font-semibold uppercase tracking-[0.13em] text-white/95">
                        Made for the journey
                    </span>
                </div>

                <h2 className="mt-4 max-w-[310px] text-[27px] font-semibold leading-[1.16] tracking-[-0.05em] sm:text-[32px]">
                    Find your next
                    <br />
                    <span className="text-white/75">favourite drive.</span>
                </h2>

                <p className="mt-3 max-w-[300px] text-[12px] leading-6 text-white/80 sm:text-sm">
                    Explore vehicles and keep your automotive world organised.
                </p>

                <Link
                    href="/marketplace"
                    className="group mt-5 inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-white px-4 text-xs font-bold text-[#7008E7] shadow-sm transition hover:bg-[#faf6ff] active:scale-[0.98]"
                >
                    Explore marketplace
                    <ArrowRight
                        size={15}
                        className="transition-transform group-hover:translate-x-0.5"
                    />
                </Link>
            </div>

            <div
                aria-hidden="true"
                className="pointer-events-none absolute bottom-4 right-4 flex h-[86px] w-[86px] items-center justify-center rounded-[26px] border border-white/20 bg-white/[0.12] text-white/90 backdrop-blur-sm sm:bottom-6 sm:right-6 sm:h-[100px] sm:w-[100px]"
            >
                <CarFront size={43} strokeWidth={1.3} />
            </div>
        </section>
    );
}

function SectionHeading({
    eyebrow,
    title,
    description,
}: {
    eyebrow?: string;
    title: string;
    description?: string;
}) {
    return (
        <div className="min-w-0">
            {eyebrow && (
                <p className="mb-1.5 text-[10px] font-bold uppercase tracking-[0.17em] text-[#7008E7]">
                    {eyebrow}
                </p>
            )}

            <h2 className="text-[19px] font-semibold tracking-[-0.04em] text-[#30213f] sm:text-[21px]">
                {title}
            </h2>

            {description && (
                <p className="mt-1 text-xs leading-5 text-[#93879f] sm:text-sm sm:leading-6">
                    {description}
                </p>
            )}
        </div>
    );
}

function DesktopActionCard({
    action,
}: {
    action: DashboardAction;
}) {
    const Icon = action.icon;

    return (
        <Link
            href={action.href}
            className="group flex min-h-[164px] flex-col rounded-[23px] border border-[#eee7f5] bg-white p-5 shadow-[0_3px_12px_rgba(40,20,60,0.015)] transition duration-200 hover:-translate-y-1 hover:border-[#d9c2fa] hover:shadow-[0_14px_32px_rgba(65,31,99,0.07)] active:translate-y-0"
        >
            <div className="flex items-start justify-between gap-3">
                <span className="flex h-12 w-12 items-center justify-center rounded-[16px] bg-[#f3ebff] text-[#7008E7] transition duration-200 group-hover:scale-105 group-hover:bg-[#7008E7] group-hover:text-white">
                    <Icon size={21} strokeWidth={1.8} />
                </span>

                <span className="flex h-8 w-8 items-center justify-center rounded-full text-[#b2a4c0] transition group-hover:bg-[#7008E7]/[0.08] group-hover:text-[#7008E7]">
                    <ArrowUpRight size={17} />
                </span>
            </div>

            <div className="mt-auto pt-5">
                <h3 className="text-sm font-semibold text-[#352443] transition-colors group-hover:text-[#7008E7]">
                    {action.title}
                </h3>

                <p className="mt-1.5 text-xs leading-5 text-[#968ba2]">
                    {action.description}
                </p>
            </div>
        </Link>
    );
}

function MobileActionGrid() {
    return (
        <section>
            <div className="mb-4 flex items-end justify-between gap-3">
                <SectionHeading
                    title="Your shortcuts"
                    description="Everything you need, one tap away."
                />

                <Link
                    href="/settings"
                    className="mb-0.5 inline-flex shrink-0 items-center gap-1 text-xs font-semibold text-[#7008E7]"
                >
                    More
                    <ChevronRight size={14} />
                </Link>
            </div>

            <div className="grid grid-cols-4 gap-2.5 sm:gap-4">
                {primaryActions.map((action) => {
                    const Icon = action.icon;

                    return (
                        <Link
                            key={action.href}
                            href={action.href}
                            className="group flex min-w-0 flex-col items-center justify-start rounded-[19px] border border-[#eee7f5] bg-white px-1.5 py-4 text-center shadow-[0_3px_12px_rgba(40,20,60,0.02)] transition hover:border-[#d9c2fa] hover:bg-[#fdfbff] active:scale-[0.97] sm:rounded-[22px] sm:py-5"
                        >
                            <span className="flex h-11 w-11 items-center justify-center rounded-[15px] bg-[#f2eaff] text-[#7008E7] transition group-hover:bg-[#7008E7] group-hover:text-white sm:h-12 sm:w-12">
                                <Icon size={20} strokeWidth={1.8} />
                            </span>

                            <span className="mt-2.5 w-full break-words text-[10px] font-semibold leading-4 text-[#59466b] sm:text-xs">
                                {action.shortLabel}
                            </span>
                        </Link>
                    );
                })}
            </div>
        </section>
    );
}

function DesktopAccountCard() {
    return (
        <section className="rounded-[24px] border border-[#eee7f5] bg-white p-5">
            <div className="flex items-start gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[15px] bg-[#f0e8ff] text-[#7008E7]">
                    <ShieldCheck size={21} strokeWidth={1.8} />
                </span>

                <div className="min-w-0 flex-1">
                    <h3 className="text-sm font-semibold text-[#352443]">
                        Account overview
                    </h3>

                    <p className="mt-1 text-xs leading-5 text-[#93879f]">
                        Your account tools are ready when you need them.
                    </p>
                </div>
            </div>

            <div className="mt-5 flex items-center gap-3 rounded-2xl border border-[#e4f1e7] bg-[#f6fbf7] px-3.5 py-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#e4f4e8] text-[#31834b]">
                    <CheckCircle2 size={17} />
                </span>

                <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-[#326d43]">
                        Signed in
                    </p>

                    <p className="mt-0.5 text-[10px] leading-4 text-[#71927a]">
                        Your dashboard is available.
                    </p>
                </div>

                <Check size={16} className="text-[#31834b]" />
            </div>

            <Link
                href="/settings"
                className="mt-4 flex min-h-11 items-center justify-between rounded-xl px-2 text-xs font-semibold text-[#81728f] transition hover:text-[#7008E7]"
            >
                Manage account
                <ChevronRight size={16} />
            </Link>
        </section>
    );
}

function MobileAccountCard() {
    return (
        <section className="rounded-[22px] border border-[#eee7f5] bg-white p-4 sm:p-5">
            <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[15px] bg-[#f0e8ff] text-[#7008E7]">
                    <ShieldCheck size={20} />
                </span>

                <div className="min-w-0 flex-1">
                    <h3 className="text-sm font-semibold text-[#352443]">
                        Account status
                    </h3>

                    <p className="mt-1 text-xs text-[#93879f]">
                        You are signed in to KARMASS.
                    </p>
                </div>

                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#e8f7ec] text-[#31834b]">
                    <Check size={17} />
                </span>
            </div>

            <Link
                href="/settings"
                className="mt-4 flex min-h-11 items-center justify-between rounded-xl border border-[#eee7f5] px-3 text-xs font-semibold text-[#665272] transition hover:border-[#d9c2fa] hover:text-[#7008E7]"
            >
                Manage account settings
                <ChevronRight size={16} />
            </Link>
        </section>
    );
}

function DesktopHelpfulLinks() {
    const links = [
        {
            title: "Explore marketplace",
            href: "/marketplace",
            icon: Store,
        },
        {
            title: "Manage your listings",
            href: "/dashboard/my-listings",
            icon: CarFront,
        },
        {
            title: "Subscriptions and billing",
            href: "/subscriptions",
            icon: WalletCards,
        },
        {
            title: "Help and support",
            href: "/support",
            icon: CircleHelp,
        },
    ];

    return (
        <section className="rounded-[24px] border border-[#eee7f5] bg-white p-5">
            <SectionHeading
                title="Useful links"
                description="Quick access to your account tools."
            />

            <div className="mt-4 space-y-1">
                {links.map((link) => {
                    const Icon = link.icon;

                    return (
                        <Link
                            key={link.href}
                            href={link.href}
                            className="group flex min-h-[47px] items-center gap-3 rounded-xl px-2 transition hover:bg-[#faf7ff]"
                        >
                            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-[#f5efff] text-[#7008E7] transition group-hover:bg-[#7008E7] group-hover:text-white">
                                <Icon size={16} />
                            </span>

                            <span className="min-w-0 flex-1 text-xs font-medium text-[#71637f] transition group-hover:text-[#7008E7]">
                                {link.title}
                            </span>

                            <ChevronRight
                                size={15}
                                className="shrink-0 text-[#c2b5d0] transition group-hover:translate-x-0.5 group-hover:text-[#7008E7]"
                            />
                        </Link>
                    );
                })}
            </div>
        </section>
    );
}

function DealerCallout() {
    return (
        <section className="relative isolate overflow-hidden rounded-[24px] border border-[#e9dcfa] bg-gradient-to-br from-[#f8f2ff] via-white to-[#f1e7ff] p-5">
            <div
                aria-hidden="true"
                className="pointer-events-none absolute -right-8 -top-8 -z-10 h-32 w-32 rounded-full bg-[#7008E7]/[0.08] blur-2xl"
            />

            <span className="flex h-10 w-10 items-center justify-center rounded-[14px] bg-white text-[#7008E7] shadow-sm ring-1 ring-[#e9dcfa]">
                <Store size={19} />
            </span>

            <h3 className="mt-4 text-sm font-semibold text-[#352443]">
                Ready to sell?
            </h3>

            <p className="mt-2 text-xs leading-6 text-[#8c7d9b]">
                Manage your vehicle listings or explore the options available
                for sellers.
            </p>

            <Link
                href="/dashboard/my-listings"
                className="group mt-4 inline-flex min-h-10 w-full items-center justify-center gap-2 rounded-xl bg-[#7008E7] px-3 text-xs font-semibold text-white transition hover:bg-[#5f06c7] active:scale-[0.98]"
            >
                Manage listings
                <ArrowRight
                    size={14}
                    className="transition-transform group-hover:translate-x-0.5"
                />
            </Link>
        </section>
    );
}

function MobileAccountLinks() {
    const links = [
        {
            title: "Subscriptions",
            description: "Plans and billing",
            href: "/subscriptions",
            icon: CreditCard,
        },
        {
            title: "Account settings",
            description: "Your personal details",
            href: "/settings",
            icon: Settings2,
        },
        {
            title: "Help and support",
            description: "We're here to help",
            href: "/support",
            icon: CircleHelp,
        },
    ];

    return (
        <section>
            <SectionHeading
                title="Account & support"
                description="Keep your account organised."
            />

            <div className="mt-3 overflow-hidden rounded-[22px] border border-[#eee7f5] bg-white px-3">
                {links.map((link, index) => {
                    const Icon = link.icon;

                    return (
                        <Link
                            key={link.href}
                            href={link.href}
                            className={`group flex min-h-[69px] items-center gap-3 px-1 transition hover:bg-[#fdfbff] ${
                                index !== links.length - 1
                                    ? "border-b border-[#f1ebf7]"
                                    : ""
                            }`}
                        >
                            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[14px] bg-[#f4edff] text-[#7008E7]">
                                <Icon size={18} />
                            </span>

                            <span className="min-w-0 flex-1">
                                <span className="block text-sm font-semibold text-[#463454]">
                                    {link.title}
                                </span>

                                <span className="mt-1 block text-xs text-[#998da4]">
                                    {link.description}
                                </span>
                            </span>

                            <ChevronRight
                                size={17}
                                className="shrink-0 text-[#b9abc8] transition group-hover:translate-x-0.5 group-hover:text-[#7008E7]"
                            />
                        </Link>
                    );
                })}
            </div>
        </section>
    );
}

function DashboardFooter() {
    return (
        <footer className="mt-10 border-t border-[#ebe4f2] pb-3 pt-5">
            <div className="flex flex-col items-center justify-between gap-2 text-center sm:flex-row sm:text-left">
                <p className="text-[11px] text-[#a398af]">
                    © <CurrentYear /> KARMASS. All rights reserved.
                </p>

                <p className="text-[10px] font-medium uppercase tracking-[0.14em] text-[#b0a5bb]">
                    Discover. Connect. Drive.
                </p>
            </div>
        </footer>
    );
}

function DashboardSkeleton() {
    return (
        <div
            className="min-h-screen bg-[#faf8fd] px-4 py-6 sm:px-8 sm:py-8"
            aria-live="polite"
            aria-busy="true"
        >
            <div className="mx-auto max-w-[1440px]">
                <div className="flex items-center justify-between">
                    <div className="h-11 w-36 animate-pulse rounded-2xl bg-[#e9e0f2]" />
                    <div className="h-10 w-10 animate-pulse rounded-xl bg-[#eee8f5]" />
                </div>

                <div className="mt-8 h-7 w-48 animate-pulse rounded-lg bg-[#e9e0f2]" />

                <div className="mt-3 h-4 w-64 max-w-full animate-pulse rounded-full bg-[#eee8f5]" />

                <div className="mt-7 h-[245px] animate-pulse rounded-[27px] bg-[#eee8f5] sm:h-[280px] xl:mt-10 xl:h-[300px]" />

                <div className="mt-8 grid grid-cols-4 gap-2.5 sm:gap-4 xl:grid-cols-3">
                    {Array.from({ length: 4 }).map((_, index) => (
                        <div
                            key={index}
                            className="h-[100px] animate-pulse rounded-[19px] bg-[#eee8f5] xl:h-[160px]"
                        />
                    ))}
                </div>

                <div className="mt-8 h-28 animate-pulse rounded-[22px] bg-[#eee8f5]" />
            </div>
        </div>
    );
}

function SignInPrompt() {
    return (
        <div className="flex min-h-[70vh] items-center justify-center bg-[#faf8fd] px-5 py-10">
            <section className="w-full max-w-sm rounded-[28px] border border-[#eee7f5] bg-white p-7 text-center shadow-[0_8px_35px_rgba(45,18,78,0.04)]">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#f0e8ff] text-[#7008E7]">
                    <CircleUserRound size={26} />
                </div>

                <h1 className="mt-5 text-xl font-semibold tracking-tight text-[#30213f]">
                    Sign in to continue
                </h1>

                <p className="mt-2 text-sm leading-6 text-[#8d819a]">
                    Sign in to access your KARMASS dashboard and manage your
                    account.
                </p>

                <Link
                    href="/login"
                    className="mt-5 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#7008E7] px-4 text-sm font-semibold text-white transition hover:bg-[#5f06c7]"
                >
                    Go to sign in
                    <ArrowRight size={16} />
                </Link>
            </section>
        </div>
    );
}

function DesktopDashboard() {
    return (
        <div className="hidden min-h-screen bg-[#faf8fd] text-[#30213f] xl:block">
            <div className="pointer-events-none fixed inset-0 overflow-hidden">
                <div className="absolute -right-40 -top-40 h-[440px] w-[440px] rounded-full bg-[#7008E7]/[0.025] blur-[100px]" />

                <div className="absolute -left-40 top-[45%] h-[340px] w-[340px] rounded-full bg-[#b68aff]/[0.04] blur-[100px]" />
            </div>

            <div className="relative mx-auto w-full max-w-[1600px] px-7 py-9 2xl:px-12 2xl:py-10">
                <DashboardHeader />

                <div className="mt-9 2xl:mt-11">
                    <DesktopWelcomeCard />
                </div>

                <div className="mt-10 grid grid-cols-1 items-start gap-8 2xl:grid-cols-[minmax(0,1fr)_320px]">
                    <div className="min-w-0 space-y-10">
                        <section>
                            <div className="mb-5 flex items-end justify-between gap-4">
                                <SectionHeading
                                    eyebrow="YOUR PERSONAL SPACE"
                                    title="Your dashboard"
                                    description="Jump straight into the tools you use most."
                                />

                                <Link
                                    href="/dashboard/my-listings"
                                    className="group inline-flex min-h-10 shrink-0 items-center gap-2 rounded-xl px-2 text-xs font-semibold text-[#7008E7] transition hover:bg-[#7008E7]/[0.06]"
                                >
                                    View listings
                                    <ArrowRight
                                        size={15}
                                        className="transition-transform group-hover:translate-x-1"
                                    />
                                </Link>
                            </div>

                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 2xl:grid-cols-4">
                                {primaryActions.map((action) => (
                                    <DesktopActionCard
                                        key={action.href}
                                        action={action}
                                    />
                                ))}
                            </div>
                        </section>

                        <section>
                            <div className="mb-5">
                                <SectionHeading
                                    title="Account tools"
                                    description="Manage your plan and personal information."
                                />
                            </div>

                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                {accountActions.map((action) => (
                                    <DesktopActionCard
                                        key={action.href}
                                        action={action}
                                    />
                                ))}
                            </div>
                        </section>
                    </div>

                    <aside className="grid grid-cols-1 gap-5 sm:grid-cols-2 2xl:grid-cols-1">
                        <DesktopAccountCard />
                        <DealerCallout />
                        <DesktopHelpfulLinks />
                    </aside>
                </div>

                <DashboardFooter />
            </div>
        </div>
    );
}

function MobileDashboard() {
    return (
        <div className="min-h-screen overflow-x-clip bg-[#faf8fd] text-[#30213f] xl:hidden">
            <div
                aria-hidden="true"
                className="pointer-events-none fixed inset-x-0 top-0 h-[340px] bg-gradient-to-b from-[#f1e7ff]/60 via-[#faf8fd]/40 to-transparent"
            />

            <div className="relative mx-auto w-full max-w-2xl px-4 pb-7 pt-5 sm:px-7 sm:pt-7">
                <DashboardHeader />

                <div className="mt-6 sm:mt-8">
                    <MobileWelcomeCard />
                </div>

                <div className="mt-8">
                    <MobileActionGrid />
                </div>

                <div className="mt-7">
                    <MobileAccountCard />
                </div>

                <div className="mt-8">
                    <MobileAccountLinks />
                </div>

                <div className="mt-7">
                    <DealerCallout />
                </div>

                <footer className="mt-8 border-t border-[#ebe4f2] pb-2 pt-5 text-center">
                    <p className="text-[10px] font-medium text-[#a398af]">
                        © <CurrentYear /> KARMASS
                    </p>

                    <p className="mt-1.5 text-[9px] font-semibold uppercase tracking-[0.15em] text-[#b0a5bb]">
                        Discover. Connect. Drive.
                    </p>
                </footer>
            </div>
        </div>
    );
}

export default function DashboardPage() {
    return (
        <>
            <DesktopDashboard />
            <MobileDashboard />
        </>
    );
}