"use client";

import Link from "next/link";

import {
    ArrowRight,
    ArrowUpRight,
    Bell,
    Bookmark,
    CarFront,
    ChevronRight,
    CircleHelp,
    CreditCard,
    LayoutGrid,
    LogOut,
    MessageCircle,
    Plus,
    Search,
    Settings2,
    ShieldCheck,
    Sparkles,
    Store,
    type LucideIcon,
} from "lucide-react";

interface DashboardUser {
    firstName?: string | null;
    lastName?: string | null;
    email?: string | null;
}

interface DashboardDesktopProps {
    user: DashboardUser;
    onLogout: () => void;
    isLoggingOut: boolean;
}

interface DashboardLink {
    label: string;
    description: string;
    href: string;
    icon: LucideIcon;
}

const dashboardLinks: DashboardLink[] = [
    {
        label: "My listings",
        description: "Manage your vehicle advertisements.",
        href: "/dashboard/my-listings",
        icon: CarFront,
    },
    {
        label: "Saved vehicles",
        description: "Return to vehicles you've saved.",
        href: "/dashboard/saved-vehicles",
        icon: Bookmark,
    },
    {
        label: "Messages",
        description: "Continue your conversations.",
        href: "/dashboard/messages",
        icon: MessageCircle,
    },
    {
        label: "Notifications",
        description: "Review your account updates.",
        href: "/dashboard/notifications",
        icon: Bell,
    },
    {
        label: "Subscriptions",
        description: "Manage your subscription.",
        href: "/dashboard/subscriptions",
        icon: CreditCard,
    },
    {
        label: "Account settings",
        description: "Manage your personal information.",
        href: "/dashboard/settings",
        icon: Settings2,
    },
];

function DesktopSectionHeading({
    eyebrow,
    title,
    description,
}: {
    eyebrow: string;
    title: string;
    description: string;
}) {
    return (
        <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#7008E7]">
                {eyebrow}
            </p>

            <h2 className="mt-2 text-xl font-semibold tracking-[-0.04em] text-[#261936]">
                {title}
            </h2>

            <p className="mt-1.5 text-sm leading-6 text-[#8c819a]">
                {description}
            </p>
        </div>
    );
}

function DesktopActionCard({
    item,
}: {
    item: DashboardLink;
}) {
    const Icon = item.icon;

    return (
        <Link
            href={item.href}
            className="
                group relative flex min-h-[158px] flex-col
                rounded-[22px] border border-[#eee7f5]
                bg-white p-5
                transition-all duration-300
                hover:-translate-y-1 hover:border-[#d9c2fa]
                hover:shadow-[0_16px_36px_rgba(49,20,79,0.07)]
                focus-visible:outline-none
                focus-visible:ring-2 focus-visible:ring-[#7008E7]
                focus-visible:ring-offset-2
            "
        >
            <div className="flex items-start justify-between gap-3">
                <span className="
                    flex h-11 w-11 items-center justify-center
                    rounded-[15px] bg-[#f3ebff]
                    text-[#7008E7]
                    transition-transform duration-300
                    group-hover:scale-105
                ">
                    <Icon size={21} strokeWidth={1.8} />
                </span>

                <ArrowUpRight
                    size={17}
                    className="
                        text-[#b5a8c3]
                        transition-all duration-200
                        group-hover:-translate-y-0.5
                        group-hover:translate-x-0.5
                        group-hover:text-[#7008E7]
                    "
                />
            </div>

            <div className="mt-auto pt-5">
                <h3 className="
                    text-sm font-semibold text-[#342442]
                    transition-colors group-hover:text-[#7008E7]
                ">
                    {item.label}
                </h3>

                <p className="mt-1.5 text-xs leading-5 text-[#91869e]">
                    {item.description}
                </p>
            </div>
        </Link>
    );
}

function DesktopMarketplaceBanner({
    firstName,
}: {
    firstName: string;
}) {
    return (
        <section className="
            relative isolate overflow-hidden rounded-[28px]
            bg-gradient-to-br from-[#7008E7] via-[#7816e8] to-[#4f06aa]
            p-7 text-white
            shadow-[0_18px_50px_rgba(112,8,231,0.14)]
            lg:p-9
        ">
            <div
                aria-hidden="true"
                className="
                    pointer-events-none absolute -right-20 -top-28
                    -z-10 h-80 w-80 rounded-full
                    border border-white/[0.12]
                "
            />

            <div
                aria-hidden="true"
                className="
                    pointer-events-none absolute -right-8 -top-16
                    -z-10 h-64 w-64 rounded-full
                    border border-white/[0.12]
                "
            />

            <div
                aria-hidden="true"
                className="
                    pointer-events-none absolute -bottom-24 right-28
                    -z-10 h-56 w-56 rounded-full
                    bg-white/[0.08] blur-3xl
                "
            />

            <div className="relative grid items-center gap-8 lg:grid-cols-[minmax(0,1fr)_220px]">
                <div className="max-w-2xl">
                    <span className="
                        inline-flex items-center gap-2
                        rounded-full border border-white/20
                        bg-white/10 px-3 py-1.5
                        text-[10px] font-semibold uppercase
                        tracking-[0.16em] text-white/90
                        backdrop-blur-md
                    ">
                        <Sparkles size={13} />
                        Your automotive workspace
                    </span>

                    <h1 className="
                        mt-5 max-w-xl text-3xl font-semibold
                        leading-[1.15] tracking-[-0.05em]
                        sm:text-4xl
                    ">
                        {firstName
                            ? `Welcome back, ${firstName}.`
                            : "Welcome to KARMASS."}
                    </h1>

                    <p className="
                        mt-4 max-w-lg text-sm leading-7
                        text-white/75 sm:text-[15px]
                    ">
                        Discover exceptional vehicles, stay
                        connected with sellers, and manage your
                        automotive journey from one place.
                    </p>

                    <div className="mt-7 flex flex-wrap gap-3">
                        <Link
                            href="/marketplace"
                            className="
                                group inline-flex min-h-12
                                items-center justify-center gap-2
                                rounded-xl bg-white px-5
                                text-sm font-semibold text-[#7008E7]
                                transition-all duration-200
                                hover:-translate-y-0.5 hover:bg-[#faf6ff]
                            "
                        >
                            Explore marketplace

                            <ArrowRight
                                size={17}
                                className="transition-transform group-hover:translate-x-1"
                            />
                        </Link>

                        <Link
                            href="/dashboard/my-listings"
                            className="
                                inline-flex min-h-12 items-center
                                justify-center gap-2 rounded-xl
                                border border-white/25 bg-white/[0.08]
                                px-5 text-sm font-semibold text-white
                                backdrop-blur-md transition
                                hover:bg-white/[0.15]
                            "
                        >
                            <Plus size={17} />
                            My listings
                        </Link>
                    </div>
                </div>

                <div className="hidden lg:flex lg:justify-center">
                    <div className="
                        relative flex h-40 w-40 items-center
                        justify-center rounded-full
                        border border-white/20 bg-white/[0.08]
                        shadow-[0_0_80px_rgba(255,255,255,0.08)]
                        backdrop-blur-sm
                    ">
                        <div className="
                            flex h-24 w-24 items-center
                            justify-center rounded-[28px]
                            bg-white text-[#7008E7]
                            shadow-[0_15px_35px_rgba(30,0,70,0.2)]
                        ">
                            <CarFront size={46} strokeWidth={1.5} />
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

function DesktopNextStepCard() {
    return (
        <section className="
            relative overflow-hidden rounded-[24px]
            border border-[#e8ddf8]
            bg-gradient-to-br from-white to-[#f6efff]
            p-6
        ">
            <div className="flex items-start gap-4">
                <div className="
                    flex h-12 w-12 shrink-0 items-center
                    justify-center rounded-2xl
                    bg-[#7008E7] text-white
                    shadow-[0_8px_20px_rgba(112,8,231,0.18)]
                ">
                    <CarFront size={23} />
                </div>

                <div className="min-w-0 flex-1">
                    <h3 className="text-base font-semibold text-[#30213f]">
                        Thinking of selling?
                    </h3>

                    <p className="mt-2 max-w-lg text-sm leading-6 text-[#8b7d99]">
                        Put your vehicle in front of potential buyers.
                        Manage your listings and keep your information
                        up to date.
                    </p>

                    <Link
                        href="/dashboard/my-listings"
                        className="
                            mt-4 inline-flex min-h-10 items-center
                            gap-2 rounded-xl bg-white px-4
                            text-xs font-semibold text-[#7008E7]
                            ring-1 ring-[#e4d5f7]
                            transition hover:bg-[#7008E7]
                            hover:text-white hover:ring-[#7008E7]
                        "
                    >
                        Manage my listings
                        <ArrowRight size={15} />
                    </Link>
                </div>
            </div>
        </section>
    );
}

function DesktopAccountPanel({
    user,
    onLogout,
    isLoggingOut,
}: DashboardDesktopProps) {
    return (
        <div className="space-y-5">
            <section className="
                rounded-[24px] border border-[#eee7f5]
                bg-white p-5
            ">
                <div className="flex items-center gap-3">
                    <div className="
                        flex h-12 w-12 shrink-0 items-center
                        justify-center rounded-2xl
                        bg-[#f1e8ff] text-lg font-bold
                        text-[#7008E7]
                    ">
                        {user.firstName?.charAt(0).toUpperCase() || "K"}
                    </div>

                    <div className="min-w-0">
                        <h2 className="text-sm font-semibold text-[#30213f]">
                            Your account
                        </h2>

                        <p className="mt-1 truncate text-xs text-[#9589a1]">
                            {user.email || "KARMASS member"}
                        </p>
                    </div>
                </div>

                <div className="
                    mt-5 flex items-center gap-3 rounded-2xl
                    border border-[#e4f0e6] bg-[#f7fbf7] p-3.5
                ">
                    <ShieldCheck
                        size={20}
                        className="shrink-0 text-[#32834a]"
                    />

                    <div>
                        <p className="text-xs font-semibold text-[#326d43]">
                            Signed in
                        </p>

                        <p className="mt-1 text-[11px] leading-5 text-[#77947d]">
                            Your account session is active.
                        </p>
                    </div>
                </div>

                <Link
                    href="/dashboard/settings"
                    className="
                        mt-3 flex min-h-11 items-center
                        justify-between rounded-xl px-2
                        text-xs font-semibold text-[#776b85]
                        transition hover:text-[#7008E7]
                    "
                >
                    Account settings
                    <ChevronRight size={16} />
                </Link>

                <button
                    type="button"
                    onClick={onLogout}
                    disabled={isLoggingOut}
                    className="
                        flex min-h-10 w-full items-center gap-2
                        rounded-xl px-2 text-xs font-medium
                        text-[#8c8198] transition
                        hover:bg-[#fff5f5] hover:text-[#c24141]
                        disabled:cursor-not-allowed disabled:opacity-50
                    "
                >
                    <LogOut size={15} />
                    {isLoggingOut ? "Signing out..." : "Sign out"}
                </button>
            </section>

            <section className="
                rounded-[24px] border border-[#eee7f5]
                bg-white p-5
            ">
                <div className="flex items-center gap-2">
                    <CircleHelp size={19} className="text-[#7008E7]" />

                    <h2 className="text-sm font-semibold text-[#30213f]">
                        Need a hand?
                    </h2>
                </div>

                <p className="mt-3 text-xs leading-6 text-[#8c819a]">
                    Find help with your account, listings, and
                    automotive marketplace experience.
                </p>

                <Link
                    href="/support"
                    className="
                        mt-4 flex min-h-10 items-center
                        justify-between rounded-xl
                        bg-[#f7f2ff] px-3
                        text-xs font-semibold text-[#7008E7]
                        transition hover:bg-[#efe3ff]
                    "
                >
                    Visit support
                    <ArrowUpRight size={15} />
                </Link>
            </section>
        </div>
    );
}

export default function DashboardDesktop(
    props: DashboardDesktopProps,
) {
    const firstName = props.user.firstName?.trim() || "";

    return (
        <div className="min-h-screen bg-[#faf8fd] text-[#30213f]">
            <div
                aria-hidden="true"
                className="pointer-events-none fixed inset-0 overflow-hidden"
            >
                <div className="
                    absolute -right-40 -top-40 h-[420px] w-[420px]
                    rounded-full bg-[#7008E7]/[0.025] blur-[100px]
                " />
            </div>

            <div className="
                relative mx-auto w-full max-w-[1600px]
                px-7 py-9 lg:px-10 lg:py-10 2xl:px-12
            ">
                <header className="
                    mb-8 flex items-center justify-between gap-6
                ">
                    <div className="min-w-0">
                        <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#9486a3]">
                            KARMASS / MY WORKSPACE
                        </p>

                        <p className="mt-2 truncate text-sm text-[#857990]">
                            {props.user.email || "Welcome to your account"}
                        </p>
                    </div>

                    <div className="flex shrink-0 items-center gap-2">
                        <Link
                            href="/dashboard/notifications"
                            aria-label="View notifications"
                            className="
                                flex h-11 w-11 items-center
                                justify-center rounded-xl
                                border border-[#eee7f5] bg-white
                                text-[#766986] transition
                                hover:border-[#d8c4f5]
                                hover:text-[#7008E7]
                            "
                        >
                            <Bell size={19} />
                        </Link>

                        <Link
                            href="/marketplace"
                            className="
                                inline-flex min-h-11 items-center
                                gap-2 rounded-xl bg-[#7008E7]
                                px-4 text-xs font-semibold text-white
                                transition hover:bg-[#5f06c7]
                            "
                        >
                            <Search size={15} />
                            Browse vehicles
                        </Link>
                    </div>
                </header>

                <DesktopMarketplaceBanner firstName={firstName} />

                <div className="
                    mt-9 grid items-start gap-8
                    2xl:grid-cols-[minmax(0,1fr)_300px]
                ">
                    <div className="min-w-0 space-y-9">
                        <section>
                            <div className="
                                mb-5 flex items-end justify-between gap-4
                            ">
                                <DesktopSectionHeading
                                    eyebrow="YOUR ACCOUNT"
                                    title="Your automotive workspace"
                                    description="Everything you need to manage your KARMASS experience."
                                />

                                <Link
                                    href="/dashboard/settings"
                                    className="
                                        hidden min-h-10 shrink-0
                                        items-center gap-2 rounded-xl
                                        px-3 text-xs font-semibold
                                        text-[#7008E7] transition
                                        hover:bg-[#7008E7]/[0.06]
                                        sm:inline-flex
                                    "
                                >
                                    Customize
                                    <ArrowUpRight size={15} />
                                </Link>
                            </div>

                            <div className="
                                grid grid-cols-1 gap-4
                                sm:grid-cols-2 xl:grid-cols-3
                            ">
                                {dashboardLinks.map((item) => (
                                    <DesktopActionCard
                                        key={item.href}
                                        item={item}
                                    />
                                ))}
                            </div>
                        </section>

                        <DesktopNextStepCard />
                    </div>

                    <aside className="hidden 2xl:block">
                        <DesktopAccountPanel {...props} />
                    </aside>
                </div>

                <footer className="
                    mt-10 flex items-center justify-between gap-4
                    border-t border-[#ebe4f2] pt-5
                ">
                    <p className="text-[11px] text-[#a398af]">
                        © {new Date().getFullYear()} KARMASS
                    </p>

                    <p className="
                        text-[10px] font-medium uppercase
                        tracking-[0.16em] text-[#b0a5bb]
                    ">
                        Discover. Connect. Drive.
                    </p>
                </footer>
            </div>
        </div>
    );
}