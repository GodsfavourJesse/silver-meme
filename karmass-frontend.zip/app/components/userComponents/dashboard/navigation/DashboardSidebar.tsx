"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import {
    ArrowUpRight,
    Bell,
    Bookmark,
    CarFront,
    ChevronRight,
    CircleHelp,
    CreditCard,
    LayoutDashboard,
    MessageCircle,
    Settings2,
    ShieldCheck,
    Store,
} from "lucide-react";

import type { LucideIcon } from "lucide-react";

interface NavigationItem {
    label: string;
    href: string;
    icon: LucideIcon;
    badge?: string;
}

interface NavigationGroup {
    label: string;
    items: NavigationItem[];
}

const navigationGroups: NavigationGroup[] = [
    {
        label: "OVERVIEW",
        items: [
            {
                label: "Dashboard",
                href: "/dashboard",
                icon: LayoutDashboard,
            },
            {
                label: "Messages",
                href: "/dashboard/messages",
                icon: MessageCircle,
            },
            {
                label: "Notifications",
                href: "/notifications",
                icon: Bell,
            },
        ],
    },
    {
        label: "MY GARAGE",
        items: [
            {
                label: "My listings",
                href: "/dashboard/my-listings",
                icon: CarFront,
            },
            {
                label: "Saved vehicles",
                href: "/saved-vehicles",
                icon: Bookmark,
            },
            {
                label: "Marketplace",
                href: "/marketplace",
                icon: Store,
            },
        ],
    },
    {
        label: "ACCOUNT",
        items: [
            {
                label: "Subscriptions",
                href: "/subscriptions",
                icon: CreditCard,
            },
            {
                label: "Become a dealer",
                href: "/dealer-registration",
                icon: ShieldCheck,
            },
            {
                label: "Settings",
                href: "/settings",
                icon: Settings2,
            },
        ],
    },
];

function isActiveRoute(
    pathname: string,
    href: string,
): boolean {
    if (href === "/dashboard") {
        return pathname === href;
    }

    return pathname === href || pathname.startsWith(`${href}/`);
}

export default function DashboardSidebar() {
    const pathname = usePathname();

    return (
        <aside
            className="
                sticky top-0 hidden h-screen w-[272px] shrink-0
                flex-col border-r border-[#eee7f8]
                bg-white xl:flex
            "
        >
            {/* Brand */}
            <div className="px-7 pb-8 pt-8">
                <Link
                    href="/dashboard"
                    aria-label="KARMASS dashboard home"
                    className="group inline-flex items-center gap-3"
                >
                    <span
                        className="
                            flex h-11 w-11 items-center justify-center
                            rounded-2xl bg-[#7008E7]
                            text-white shadow-[0_8px_20px_rgba(112,8,231,0.22)]
                            transition-transform duration-300
                            group-hover:scale-[1.04]
                        "
                    >
                        <CarFront size={24} strokeWidth={1.9} />
                    </span>

                    <span className="flex flex-col">
                        <span className="text-[21px] font-extrabold tracking-[-0.07em] text-[#211631]">
                            KARMASS
                        </span>

                        <span className="-mt-0.5 text-[9px] font-semibold uppercase tracking-[0.24em] text-[#8b8199]">
                            Automotive lifestyle
                        </span>
                    </span>
                </Link>
            </div>

            {/* Navigation */}
            <nav
                aria-label="Dashboard navigation"
                className="flex-1 space-y-8 overflow-y-auto px-4 pb-6"
            >
                {navigationGroups.map((group) => (
                    <section key={group.label}>
                        <h2 className="mb-3 px-3 text-[10px] font-bold tracking-[0.19em] text-[#a198ae]">
                            {group.label}
                        </h2>

                        <div className="space-y-1">
                            {group.items.map((item) => {
                                const Icon = item.icon;

                                const active = isActiveRoute(
                                    pathname,
                                    item.href,
                                );

                                return (
                                    <Link
                                        key={item.href}
                                        href={item.href}
                                        aria-current={
                                            active ? "page" : undefined
                                        }
                                        className={`
                                            group relative flex min-h-[46px]
                                            items-center gap-3 rounded-xl
                                            px-3.5 py-3
                                            transition-all duration-200
                                            ${
                                                active
                                                    ? "bg-[#7008E7]/[0.075] text-[#7008E7]"
                                                    : "text-[#71687f] hover:bg-[#f8f5fc] hover:text-[#30213f]"
                                            }
                                        `}
                                    >
                                        {active && (
                                            <span
                                                aria-hidden="true"
                                                className="
                                                    absolute bottom-2 left-0 top-2
                                                    w-[3px] rounded-r-full
                                                    bg-[#7008E7]
                                                "
                                            />
                                        )}

                                        <Icon
                                            size={19}
                                            strokeWidth={active ? 2.2 : 1.8}
                                            className={`
                                                shrink-0 transition-transform
                                                duration-200
                                                ${
                                                    active
                                                        ? ""
                                                        : "group-hover:scale-105"
                                                }
                                            `}
                                            aria-hidden="true"
                                        />

                                        <span
                                            className={`
                                                min-w-0 flex-1 text-[13px]
                                                ${
                                                    active
                                                        ? "font-semibold"
                                                        : "font-medium"
                                                }
                                            `}
                                        >
                                            {item.label}
                                        </span>

                                        {active && (
                                            <ChevronRight
                                                size={15}
                                                className="text-[#7008E7]/65"
                                                aria-hidden="true"
                                            />
                                        )}
                                    </Link>
                                );
                            })}
                        </div>
                    </section>
                ))}
            </nav>

            {/* Premium dealer card */}
            <div className="px-4 pb-4">
                <div className="relative overflow-hidden rounded-2xl border border-[#eee3ff] bg-gradient-to-br from-[#faf6ff] via-white to-[#f2eaff] p-4">
                    <div
                        aria-hidden="true"
                        className="
                            pointer-events-none absolute -right-8 -top-10
                            h-28 w-28 rounded-full bg-[#7008E7]/[0.07]
                            blur-2xl
                        "
                    />

                    <div className="relative">
                        <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-xl bg-white text-[#7008E7] shadow-sm ring-1 ring-[#eee3ff]">
                            <ShieldCheck size={19} />
                        </div>

                        <h3 className="text-sm font-semibold text-[#30213f]">
                            Elevate your presence
                        </h3>

                        <p className="mt-1.5 text-xs leading-5 text-[#81758f]">
                            Become a verified dealer and build trust with
                            serious automotive buyers.
                        </p>

                        <Link
                            href="/dealer-registration"
                            className="
                                mt-4 inline-flex min-h-10 w-full
                                items-center justify-center gap-2
                                rounded-xl bg-[#7008E7] px-3
                                text-xs font-semibold text-white
                                shadow-[0_5px_14px_rgba(112,8,231,0.17)]
                                transition-all duration-200
                                hover:bg-[#5f06c7]
                                hover:shadow-[0_7px_20px_rgba(112,8,231,0.23)]
                                active:scale-[0.98]
                            "
                        >
                            Explore dealer access
                            <ArrowUpRight size={15} />
                        </Link>
                    </div>
                </div>
            </div>

            {/* Help */}
            <div className="border-t border-[#f0ebf6] px-4 py-3">
                <Link
                    href="/support"
                    className="
                        flex min-h-11 items-center gap-3 rounded-xl
                        px-3 text-sm font-medium text-[#81758f]
                        transition-colors hover:bg-[#f8f5fc]
                        hover:text-[#7008E7]
                    "
                >
                    <CircleHelp size={18} />

                    <span className="flex-1">
                        Help & support
                    </span>

                    <ChevronRight size={15} />
                </Link>
            </div>
        </aside>
    );
}