import Link from "next/link";

interface AuthBrandVisualProps {
    mode: "register" | "login";
}

export function AuthBrandVisual({
    mode,
}: AuthBrandVisualProps) {
    const headline =
        mode === "register"
            ? "Your next drive starts here."
            : "Good to have you back.";

    const description =
        mode === "register"
            ? "Discover exceptional vehicles. Connect with trusted sellers. Find the car that feels like it was made for you."
            : "Your automotive journey continues here. Sign in to pick up right where you left off.";

    return (
        <section className="relative hidden min-h-[760px] overflow-hidden bg-[#171816] lg:flex lg:flex-col">
            {/* Automotive photography */}
            <div
                className="absolute inset-0 bg-cover bg-center"
                style={{
                    backgroundImage:
                        "url('https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1800&q=90')",
                }}
                aria-hidden="true"
            />

            {/* Cinematic overlays */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-black/80" />

            <div className="absolute inset-0 bg-gradient-to-r from-black/25 via-transparent to-transparent" />

            {/* Top brand bar */}
            <div className="relative z-10 flex items-center justify-between px-12 py-10 xl:px-16">
                <Link
                    href="/"
                    aria-label="KARMASS home"
                    className="inline-flex items-center gap-3"
                >
                    <span className="flex h-10 w-10 items-center justify-center border border-white/50 text-sm font-semibold tracking-[-0.08em] text-white">
                        K.
                    </span>

                    <span className="text-lg font-semibold tracking-[0.2em] text-white">
                        KARMASS
                    </span>
                </Link>

                <span className="text-[10px] font-medium uppercase tracking-[0.28em] text-white/75">
                    The art of finding your drive
                </span>
            </div>

            {/* Editorial content */}
            <div className="relative z-10 mt-auto px-12 pb-12 xl:px-16 xl:pb-16">
                <div className="mb-8 flex items-center gap-3">
                    <span className="h-px w-10 bg-[#C4B0F2]" />

                    <span className="text-[10px] font-semibold uppercase tracking-[0.3em] text-white/85">
                        The KARMASS experience
                    </span>
                </div>

                <h1 className="max-w-[600px] text-5xl font-medium leading-[1.06] tracking-[-0.055em] text-white xl:text-7xl">
                    {headline}
                </h1>

                <p className="mt-6 max-w-[440px] text-sm leading-7 text-white/75 xl:text-base">
                    {description}
                </p>

                <div className="mt-12 flex items-center justify-between border-t border-white/25 pt-6">
                    <p className="text-[10px] font-medium uppercase tracking-[0.24em] text-white/65">
                        Discover. Connect. Drive.
                    </p>

                    <div
                        className="flex items-center gap-2"
                        aria-label="Automotive editorial"
                    >
                        <span className="h-1 w-8 bg-white" />
                        <span className="h-1 w-3 bg-white/40" />
                        <span className="h-1 w-3 bg-white/40" />
                    </div>
                </div>
            </div>
        </section>
    );
}