"use client";

import { useState } from "react";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import {
    ArrowRight,
    CheckCircle2,
    LoaderCircle,
    Mail,
} from "lucide-react";

import Link from "next/link";

import { authService } from "@/app/services/user/auth/auth.service";
import { ApiError } from "@/app/lib/api/api-error";

const forgotPasswordSchema = z.object({
    email: z
        .string()
        .trim()
        .email("Enter a valid email address"),
});

type ForgotPasswordValues = z.infer<typeof forgotPasswordSchema>;

export function ForgotPasswordForm() {
    const [submitted, setSubmitted] = useState(false);
    const [serverError, setServerError] = useState<string | null>(null);

    const {
        register,
        handleSubmit,
        formState: { errors, isSubmitting },
    } = useForm<ForgotPasswordValues>({
        resolver: zodResolver(forgotPasswordSchema),
        defaultValues: {
            email: "",
        },
    });

    const onSubmit: SubmitHandler<ForgotPasswordValues> = async (
        values,
    ) => {
        setServerError(null);

        try {
            await authService.forgotPassword({
                email: values.email.trim().toLowerCase(),
            });

            setSubmitted(true);
        } catch (error) {
            if (error instanceof ApiError) {
                setServerError(
                    error.message || "We couldn't process your request.",
                );
            } else {
                setServerError(
                    "We couldn't connect to KARMASS. Check your connection and try again.",
                );
            }
        }
    };

    if (submitted) {
        return (
            <div className="text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#7008E7]/10">
                    <CheckCircle2
                        size={30}
                        className="text-[#7008E7]"
                    />
                </div>

                <h2 className="mt-6 text-xl font-semibold text-[#292522]">
                    Check your inbox.
                </h2>

                <p className="mt-3 text-sm leading-6 text-[#858078]">
                    If an account exists for that email address, you'll
                    receive instructions to reset your password. Check your
                    inbox and spam folder.
                </p>

                <Link
                    href="/login"
                    className="mt-7 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#7008E7] px-5 text-sm font-semibold text-white transition-colors hover:bg-[#5B06BC]"
                >
                    Return to sign in
                    <ArrowRight size={17} />
                </Link>

                <button
                    type="button"
                    onClick={() => setSubmitted(false)}
                    className="mt-5 text-sm font-medium text-[#7008E7] hover:text-[#5B06BC]"
                >
                    Try another email
                </button>
            </div>
        );
    }

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            noValidate
            className="space-y-5"
        >
            <div className="space-y-2">
                <label
                    htmlFor="email"
                    className="block text-sm font-medium text-[#292522]"
                >
                    Email address
                </label>

                <div className="flex h-12 items-center gap-3 border border-[#E5E1DA] bg-white px-3.5 transition-all focus-within:border-[#7008E7] focus-within:ring-2 focus-within:ring-[#7008E7]/10">
                    <Mail
                        size={17}
                        className="shrink-0 text-[#96918B]"
                    />

                    <input
                        {...register("email")}
                        id="email"
                        type="email"
                        autoComplete="email"
                        placeholder="you@example.com"
                        aria-invalid={Boolean(errors.email)}
                        aria-describedby={
                            errors.email ? "forgot-email-error" : undefined
                        }
                        className="h-full min-w-0 flex-1 bg-transparent text-sm text-[#292522] outline-none placeholder:text-[#A6A099]"
                    />
                </div>

                {errors.email && (
                    <p
                        id="forgot-email-error"
                        role="alert"
                        className="text-xs text-red-600"
                    >
                        {errors.email.message}
                    </p>
                )}
            </div>

            {serverError && (
                <p
                    role="alert"
                    className="border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-700"
                >
                    {serverError}
                </p>
            )}

            <button
                type="submit"
                disabled={isSubmitting}
                className="group flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#7008E7] px-5 text-sm font-semibold text-white transition-colors hover:bg-[#5B06BC] disabled:cursor-not-allowed disabled:opacity-60"
            >
                {isSubmitting ? (
                    <>
                        <LoaderCircle size={18} className="animate-spin" />
                        Sending instructions...
                    </>
                ) : (
                    <>
                        Send reset instructions
                        <ArrowRight
                            size={17}
                            className="transition-transform group-hover:translate-x-1"
                        />
                    </>
                )}
            </button>
        </form>
    );
}