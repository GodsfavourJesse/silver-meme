"use client";

import {
    forwardRef,
    useState,
    type ComponentPropsWithoutRef,
} from "react";

import {
    Eye,
    EyeOff,
    LockKeyhole,
} from "lucide-react";

interface PasswordInputProps
    extends Omit<ComponentPropsWithoutRef<"input">, "type"> {
    label?: string;
}

export const PasswordInput = forwardRef<
    HTMLInputElement,
    PasswordInputProps
>(function PasswordInput(
    {
        id,
        name,
        label = "Password",
        placeholder = "Enter your password",
        autoComplete = "current-password",
        required = true,
        className = "",
        ...inputProps
    },
    ref,
) {
    const [isVisible, setIsVisible] = useState(false);

    return (
        <div className="space-y-2">
            <label
                htmlFor={id}
                className="block text-sm font-medium text-[#292522]"
            >
                {label}

                {required && (
                    <span className="ml-1 text-[#7008E7]">
                        *
                    </span>
                )}
            </label>

            <div
                className="
                    group flex h-12 items-center gap-3
                    rounded-xl border border-[#E5E1DA]
                    bg-white px-3.5
                    transition-all duration-200
                    focus-within:border-[#7008E7]
                    focus-within:ring-2
                    focus-within:ring-[#7008E7]/10
                "
            >
                <LockKeyhole
                    size={17}
                    strokeWidth={1.7}
                    className="shrink-0 text-[#96918B]"
                    aria-hidden="true"
                />

                <input
                    {...inputProps}
                    ref={ref}
                    id={id}
                    name={name}
                    type={isVisible ? "text" : "password"}
                    placeholder={placeholder}
                    autoComplete={autoComplete}
                    required={required}
                    className={`
                        h-full min-w-0 flex-1
                        bg-transparent text-sm
                        text-[#292522] outline-none
                        placeholder:text-[#A6A099]
                        ${className}
                    `}
                />

                <button
                    type="button"
                    onClick={() => setIsVisible((current) => !current)}
                    aria-label={
                        isVisible ? "Hide password" : "Show password"
                    }
                    aria-pressed={isVisible}
                    className="
                        flex h-8 w-8 shrink-0 items-center
                        justify-center rounded-lg
                        text-[#858078] transition-colors
                        hover:bg-[#F5F2ED]
                        hover:text-[#7008E7]
                        focus-visible:outline-none
                        focus-visible:ring-2
                        focus-visible:ring-[#7008E7]
                    "
                >
                    {isVisible ? (
                        <EyeOff size={17} strokeWidth={1.7} />
                    ) : (
                        <Eye size={17} strokeWidth={1.7} />
                    )}
                </button>
            </div>
        </div>
    );
});

PasswordInput.displayName = "PasswordInput";