"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ArrowRight, LoaderCircle } from "lucide-react";
import { z } from "zod";

import { authService } from "@/app/services/user/auth/auth.service";
import { PasswordInput } from "@/app/components/auth/PasswordInput";
import { ApiError } from "@/app/lib/api/api-error";
import { registrationSchema } from "@/app/schema/auth/auth.schema";


type RegistrationFormValues = z.infer<typeof registrationSchema>;

export function RegistrationForm() {
    const router = useRouter();

    const [serverError, setServerError] = useState<string | null>(null);

    const {
        register,
        handleSubmit,
        watch,
        setError,
        formState: {
            errors,
            isSubmitting,
        },
    } = useForm<RegistrationFormValues>({
        resolver: zodResolver(registrationSchema),
        defaultValues: {
            firstName: "",
            lastName: "",
            email: "",
            phone: "",
            password: "",
            confirmPassword: "",
        },
        mode: "onBlur",
    });

    const password = watch("password");
    const confirmPassword = watch("confirmPassword");

    const passwordsMatch =
        Boolean(password) &&
        Boolean(confirmPassword) &&
        password === confirmPassword;

    const onSubmit: SubmitHandler<RegistrationFormValues> = async (
        values,
    ) => {
        setServerError(null);

        try {
            const response = await authService.register({
                firstName: values.firstName.trim(),
                lastName: values.lastName.trim(),
                email: values.email.trim().toLowerCase(),
                phone: values.phone?.trim() || undefined,
                password: values.password,
            });

            const result = response.data;

            if (!result?.user?.email) {
                setServerError(
                    "Your account may have been created, but we couldn't confirm the response. Please try signing in or contact support before registering again.",
                );
                return;
            }

            if (result.requiresEmailVerification) {
                sessionStorage.setItem(
                    "karmass_verification_email",
                    result.user.email,
                );

                router.push(
                    `/verify-email?email=${encodeURIComponent(result.user.email)}`,
                );

                return;
            }

            router.push("/login");
        } catch (error: unknown) {
            if (error instanceof ApiError) {
                const message = error.message || "Registration failed.";

                if (/email/i.test(message) && /already|exist|registered/i.test(message)) {
                    setError("email", {
                        type: "server",
                        message,
                    });
                    return;
                }

                setServerError(message);
                return;
            }

            setServerError(
                "We couldn't connect to KARMASS. Check your internet connection and try again.",
            );
        }
    };

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            noValidate
            className="space-y-5"
        >
            {serverError && (
                <div
                    role="alert"
                    className="border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-700"
                >
                    {serverError}
                </div>
            )}

            {/* Name fields */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                    <label
                        htmlFor="firstName"
                        className="block text-xs font-semibold text-[#30322D]"
                    >
                        First name
                    </label>

                    <input
                        {...register("firstName")}
                        id="firstName"
                        autoComplete="given-name"
                        placeholder="John"
                        aria-invalid={Boolean(errors.firstName)}
                        aria-describedby={
                            errors.firstName ? "firstName-error" : undefined
                        }
                        className={`h-12 w-full border bg-transparent px-4 text-sm outline-none transition placeholder:text-[#A2A399] focus:border-[#7008E7] focus:ring-2 focus:ring-[#7008E7]/10 ${
                            errors.firstName
                                ? "border-red-400"
                                : "border-[#DEDED6]"
                        }`}
                    />

                    {errors.firstName && (
                        <p
                            id="firstName-error"
                            role="alert"
                            className="text-xs text-red-600"
                        >
                            {errors.firstName.message}
                        </p>
                    )}
                </div>

                <div className="space-y-2">
                    <label
                        htmlFor="lastName"
                        className="block text-xs font-semibold text-[#30322D]"
                    >
                        Last name
                    </label>

                    <input
                        {...register("lastName")}
                        id="lastName"
                        autoComplete="family-name"
                        placeholder="Doe"
                        aria-invalid={Boolean(errors.lastName)}
                        aria-describedby={
                            errors.lastName ? "lastName-error" : undefined
                        }
                        className={`h-12 w-full border bg-transparent px-4 text-sm outline-none transition placeholder:text-[#A2A399] focus:border-[#7008E7] focus:ring-2 focus:ring-[#7008E7]/10 ${
                            errors.lastName
                                ? "border-red-400"
                                : "border-[#DEDED6]"
                        }`}
                    />

                    {errors.lastName && (
                        <p
                            id="lastName-error"
                            role="alert"
                            className="text-xs text-red-600"
                        >
                            {errors.lastName.message}
                        </p>
                    )}
                </div>
            </div>

            {/* Email */}
            <div className="space-y-2">
                <label
                    htmlFor="email"
                    className="block text-xs font-semibold text-[#30322D]"
                >
                    Email address
                </label>

                <input
                    {...register("email")}
                    id="email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? "email-error" : undefined}
                    className={`h-12 w-full border bg-transparent px-4 text-sm outline-none transition placeholder:text-[#A2A399] focus:border-[#7008E7] focus:ring-2 focus:ring-[#7008E7]/10 ${
                        errors.email
                            ? "border-red-400"
                            : "border-[#DEDED6]"
                    }`}
                />

                {errors.email && (
                    <p
                        id="email-error"
                        role="alert"
                        className="text-xs text-red-600"
                    >
                        {errors.email.message}
                    </p>
                )}
            </div>

            {/* Phone */}
            <div className="space-y-2">
                <label
                    htmlFor="phone"
                    className="block text-xs font-semibold text-[#30322D]"
                >
                    Phone number{" "}
                    <span className="font-normal text-[#898A82]">
                        (optional)
                    </span>
                </label>

                <input
                    {...register("phone")}
                    id="phone"
                    type="tel"
                    autoComplete="tel"
                    placeholder="+234 800 000 0000"
                    aria-invalid={Boolean(errors.phone)}
                    aria-describedby={errors.phone ? "phone-error" : undefined}
                    className={`h-12 w-full border bg-transparent px-4 text-sm outline-none transition placeholder:text-[#A2A399] focus:border-[#7008E7] focus:ring-2 focus:ring-[#7008E7]/10 ${
                        errors.phone
                            ? "border-red-400"
                            : "border-[#DEDED6]"
                    }`}
                />

                {errors.phone && (
                    <p
                        id="phone-error"
                        role="alert"
                        className="text-xs text-red-600"
                    >
                        {errors.phone.message}
                    </p>
                )}
            </div>

            {/* Password */}
            <div className="space-y-2">
                <PasswordInput
                    {...register("password")}
                    id="password"
                    name="password"
                    label="Password"
                    placeholder="Create a secure password"
                    autoComplete="new-password"
                />

                {errors.password && (
                    <p role="alert" className="text-xs text-red-600">
                        {errors.password.message}
                    </p>
                )}

                <p className="text-[11px] text-[#898A82]">
                    Use at least 8 characters.
                </p>
            </div>

            {/* Confirm password */}
            <div className="space-y-2">
                <PasswordInput
                    {...register("confirmPassword")}
                    id="confirmPassword"
                    name="confirmPassword"
                    label="Confirm password"
                    placeholder="Enter your password again"
                    autoComplete="new-password"
                />

                {errors.confirmPassword && (
                    <p role="alert" className="text-xs text-red-600">
                        {errors.confirmPassword.message}
                    </p>
                )}

                {password &&(
                    <p className="text-xs font-medium text-[#7008E7]">
                        Passwords match.
                    </p>
                )}
            </div>

            {/* Submit */}
            <button
                type="submit"
                disabled={isSubmitting}
                className="group flex h-[52px] w-full items-center justify-center gap-3 bg-[#7008E7] cursor-pointer px-5 text-sm font-semibold text-white transition hover:bg-[#5B06BC] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7008E7] focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60"
            >
                {isSubmitting ? (
                    <>
                        <LoaderCircle size={18} className="animate-spin" />
                        Creating your account...
                    </>
                ) : (
                    <>
                        Create account
                        <ArrowRight
                            size={17}
                            className="transition-transform group-hover:translate-x-1"
                        />
                    </>
                )}
            </button>

            <p className="pt-1 text-center text-[11px] leading-5 text-[#898A82]">
                By creating an account, you agree to our{" "}
                <Link
                    href="/terms"
                    className="font-medium text-[#7008E7] underline-offset-2 hover:underline"
                >
                    Terms
                </Link>{" "}
                and{" "}
                <Link
                    href="/privacy"
                    className="font-medium text-[#7008E7] underline-offset-2 hover:underline"
                >
                    Privacy Policy
                </Link>
                .
            </p>
        </form>
    );
}