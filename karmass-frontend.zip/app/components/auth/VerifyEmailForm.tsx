"use client";

import {
    useCallback,
    useEffect,
    useRef,
    useState,
} from "react";

import Link from "next/link";
import { useSearchParams } from "next/navigation";

import {
    ArrowLeft,
    ArrowRight,
    CheckCircle2,
    LoaderCircle,
    Mail,
    RefreshCw,
    ShieldCheck,
} from "lucide-react";

import { authService } from "@/app/services/user/auth/auth.service";
import { ApiError } from "@/app/lib/api/api-error";

type VerificationStatus =
    | "idle"
    | "verifying"
    | "success"
    | "error";

function getErrorMessage(error: unknown): string {
    if (error instanceof ApiError) {
        return error.message || "The request could not be completed.";
    }

    return "Something went wrong. Please try again.";
}

export function VerifyEmailForm() {
    const searchParams = useSearchParams();

    const token = searchParams.get("token");
    const queryEmail = searchParams.get("email");

    const tokenAttempted = useRef(false);

    const [email, setEmail] = useState("");
    const [code, setCode] = useState("");

    const [status, setStatus] = useState<VerificationStatus>("idle");

    const [message, setMessage] = useState<string | null>(null);

    const [isResending, setIsResending] = useState(false);
    const [resendMessage, setResendMessage] = useState<string | null>(null);
    const [resendError, setResendError] = useState<string | null>(null);

    const [isSubmittingCode, setIsSubmittingCode] = useState(false);

    /*
     * Restore the email saved during registration.
     *
     * The email query parameter takes precedence when present.
     */
    useEffect(() => {
        const storedEmail =
            typeof window !== "undefined"
                ? sessionStorage.getItem("karmass_verification_email")
                : null;

        const initialEmail = queryEmail || storedEmail || "";

        if (initialEmail) {
            setEmail(initialEmail);
        }
    }, [queryEmail]);

    /*
     * Verify automatically when the user opens a verification link.
     *
     * The ref prevents duplicate requests during the component's
     * lifetime, including React Strict Mode's development effect cycle.
     */
    const verifyToken = useCallback(async (verificationToken: string) => {
        if (tokenAttempted.current) {
            return;
        }

        tokenAttempted.current = true;

        setStatus("verifying");
        setMessage(null);

        try {
            await authService.verifyEmailWithToken(verificationToken);

            setStatus("success");
            setMessage("Your email address has been verified successfully.");

            if (typeof window !== "undefined") {
                sessionStorage.removeItem("karmass_verification_email");
            }
        } catch (error) {
            setStatus("error");
            setMessage(getErrorMessage(error));
        }
    }, []);

    useEffect(() => {
        if (token) {
            void verifyToken(token);
        }
    }, [token, verifyToken]);

    /*
     * Verify using the code received by email.
     */
    const handleCodeVerification = async (
        event: React.FormEvent<HTMLFormElement>,
    ) => {
        event.preventDefault();

        setMessage(null);
        setStatus("idle");

        const normalizedEmail = email.trim().toLowerCase();
        const normalizedCode = code.trim();

        if (!normalizedEmail) {
            setMessage("Enter the email address you registered with.");
            return;
        }

        if (!/^\d+$/.test(normalizedCode)) {
            setMessage("Enter the verification code from your email.");
            return;
        }

        setIsSubmittingCode(true);

        try {
            await authService.verifyEmailWithCode({
                email: normalizedEmail,
                code: normalizedCode,
            });

            setStatus("success");
            setMessage("Your email address has been verified successfully.");

            if (typeof window !== "undefined") {
                sessionStorage.removeItem("karmass_verification_email");
            }
        } catch (error) {
            setStatus("error");
            setMessage(getErrorMessage(error));
        } finally {
            setIsSubmittingCode(false);
        }
    };

    /*
     * Request another verification email.
     */
    const handleResendVerification = async () => {
        setResendMessage(null);
        setResendError(null);

        const normalizedEmail = email.trim().toLowerCase();

        if (!normalizedEmail) {
            setResendError("Enter your registered email address first.");
            return;
        }

        setIsResending(true);

        try {
            await authService.resendVerification({
                email: normalizedEmail,
            });

            setResendMessage(
                "If your account requires verification, a new verification email should arrive shortly.",
            );

            if (typeof window !== "undefined") {
                sessionStorage.setItem(
                    "karmass_verification_email",
                    normalizedEmail,
                );
            }
        } catch (error) {
            setResendError(getErrorMessage(error));
        } finally {
            setIsResending(false);
        }
    };

    /*
     * Automatic verification: loading state.
     */
    if (status === "verifying") {
        return (
            <div className="py-8 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#7008E7]/10">
                    <LoaderCircle
                        size={30}
                        className="animate-spin text-[#7008E7]"
                    />
                </div>

                <h2 className="mt-6 text-xl font-semibold text-[#292522]">
                    Verifying your email
                </h2>

                <p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-[#858078]">
                    We're confirming your email address. This should only
                    take a moment.
                </p>
            </div>
        );
    }

    /*
     * Successful verification.
     */
    if (status === "success") {
        return (
            <div className="py-5 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#7008E7]/10">
                    <CheckCircle2
                        size={32}
                        strokeWidth={1.7}
                        className="text-[#7008E7]"
                    />
                </div>

                <p className="mt-6 text-xs font-semibold uppercase tracking-[0.2em] text-[#7008E7]">
                    Verification complete
                </p>

                <h2 className="mt-3 text-2xl font-semibold tracking-tight text-[#292522]">
                    You're all set.
                </h2>

                <p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-[#858078]">
                    {message ||
                        "Your email address has been verified successfully."}
                    {" "}You can now continue to your KARMASS account.
                </p>

                <Link
                    href="/login"
                    className="
                        group mt-8 flex h-12 w-full
                        items-center justify-center gap-2
                        rounded-xl bg-[#7008E7] px-5
                        text-sm font-semibold text-white
                        transition-colors hover:bg-[#5B06BC]
                    "
                >
                    Continue to sign in
                    <ArrowRight
                        size={17}
                        className="transition-transform group-hover:translate-x-1"
                    />
                </Link>
            </div>
        );
    }

    return (
        <div>
            {/* Intro */}
            <div className="text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#7008E7]/10">
                    <Mail
                        size={29}
                        strokeWidth={1.6}
                        className="text-[#7008E7]"
                    />
                </div>

                <p className="mt-6 text-xs font-semibold uppercase tracking-[0.2em] text-[#7008E7]">
                    One last step
                </p>

                <h2 className="mt-3 text-2xl font-semibold tracking-tight text-[#292522]">
                    Verify your email.
                </h2>

                <p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-[#858078]">
                    Enter the verification code we sent to your email
                    address to activate your KARMASS account.
                </p>
            </div>

            {/* Verification error */}
            {status === "error" && message && (
                <div
                    role="alert"
                    className="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-700"
                >
                    {message}
                </div>
            )}

            {/* Verification code form */}
            <form
                onSubmit={handleCodeVerification}
                className="mt-8 space-y-5"
            >
                <div className="space-y-2">
                    <label
                        htmlFor="verification-email"
                        className="block text-sm font-medium text-[#292522]"
                    >
                        Email address
                    </label>

                    <input
                        id="verification-email"
                        type="email"
                        autoComplete="email"
                        value={email}
                        onChange={(event) => setEmail(event.target.value)}
                        placeholder="you@example.com"
                        required
                        className="
                            h-12 w-full rounded-xl
                            border border-[#E5E1DA]
                            bg-white px-4 text-sm
                            text-[#292522] outline-none
                            transition-all
                            placeholder:text-[#A6A099]
                            focus:border-[#7008E7]
                            focus:ring-2
                            focus:ring-[#7008E7]/10
                        "
                    />
                </div>

                <div className="space-y-2">
                    <label
                        htmlFor="verification-code"
                        className="block text-sm font-medium text-[#292522]"
                    >
                        Verification code
                    </label>

                    <input
                        id="verification-code"
                        type="text"
                        inputMode="numeric"
                        autoComplete="one-time-code"
                        value={code}
                        onChange={(event) => {
                            setCode(
                                event.target.value.replace(/\D/g, ""),
                            );
                        }}
                        placeholder="Enter your code"
                        required
                        aria-describedby="verification-code-hint"
                        className="
                            h-14 w-full rounded-xl
                            border border-[#E5E1DA]
                            bg-white px-4 text-center
                            text-xl font-semibold
                            tracking-[0.3em] text-[#292522]
                            outline-none transition-all
                            placeholder:text-sm
                            placeholder:font-normal
                            placeholder:tracking-normal
                            placeholder:text-[#A6A099]
                            focus:border-[#7008E7]
                            focus:ring-2
                            focus:ring-[#7008E7]/10
                        "
                    />

                    <p
                        id="verification-code-hint"
                        className="text-xs leading-5 text-[#858078]"
                    >
                        Use the code from your KARMASS verification email.
                    </p>
                </div>

                {status === "error" && message && (
                    <p className="text-xs leading-5 text-red-600">
                        Check the email and code, then try again.
                    </p>
                )}

                <button
                    type="submit"
                    disabled={isSubmittingCode || isResending}
                    className="
                        group flex h-12 w-full
                        items-center justify-center gap-2
                        rounded-xl bg-[#7008E7] px-5
                        text-sm font-semibold text-white
                        transition-colors hover:bg-[#5B06BC]
                        disabled:cursor-not-allowed
                        disabled:opacity-60
                    "
                >
                    {isSubmittingCode ? (
                        <>
                            <LoaderCircle
                                size={17}
                                className="animate-spin"
                            />
                            Verifying...
                        </>
                    ) : (
                        <>
                            Verify email
                            <ArrowRight size={17} />
                        </>
                    )}
                </button>
            </form>

            {/* Resend verification */}
            <div className="mt-7 border-t border-[#E9E5DE] pt-6">
                <p className="text-center text-sm text-[#858078]">
                    Didn't receive the email?
                </p>

                <button
                    type="button"
                    onClick={handleResendVerification}
                    disabled={isResending || isSubmittingCode}
                    className="
                        mx-auto mt-3 flex items-center
                        justify-center gap-2
                        text-sm font-semibold text-[#7008E7]
                        transition-colors hover:text-[#5B06BC]
                        disabled:cursor-not-allowed
                        disabled:opacity-60
                    "
                >
                    {isResending ? (
                        <>
                            <LoaderCircle
                                size={16}
                                className="animate-spin"
                            />
                            Sending email...
                        </>
                    ) : (
                        <>
                            <RefreshCw size={15} />
                            Resend verification email
                        </>
                    )}
                </button>

                {resendMessage && (
                    <p
                        role="status"
                        className="mt-3 text-center text-xs leading-5 text-green-700"
                    >
                        {resendMessage}
                    </p>
                )}

                {resendError && (
                    <p
                        role="alert"
                        className="mt-3 text-center text-xs leading-5 text-red-600"
                    >
                        {resendError}
                    </p>
                )}
            </div>

            {/* Security reassurance */}
            <div className="mt-7 flex items-start gap-2.5 rounded-xl bg-[#F0EAF9] p-3.5">
                <ShieldCheck
                    size={17}
                    className="mt-0.5 shrink-0 text-[#7008E7]"
                />

                <p className="text-xs leading-5 text-[#665B73]">
                    For your security, verification links expire.
                    If yours has expired, request a new verification email.
                </p>
            </div>

            <Link
                href="/login"
                className="
                    mt-7 flex items-center justify-center
                    gap-2 text-sm text-[#858078]
                    transition-colors hover:text-[#292522]
                "
            >
                <ArrowLeft size={15} />
                Back to sign in
            </Link>
        </div>
    );
}