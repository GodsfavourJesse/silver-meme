import type { ReactNode } from "react";
import Link from "next/link";

import { AuthBrandVisual } from "./AuthBrandVisual";
import { AuthFormHeader } from "./AuthFormHeader";
import { CurrentYear } from "./CurrentYear";

interface AuthExperienceProps {
    mode: "register" | "login";
    children: ReactNode;
}

export function AuthExperience({
    mode,
    children,
}: AuthExperienceProps) {
    const isRegister = mode === "register";

    return (
        <main className="min-h-screen bg-[#F7F6F2] text-[#20211E] antialiased">
            <div className="grid min-h-screen lg:grid-cols-[1.08fr_0.92fr]">
                {/* Brand experience */}
                <AuthBrandVisual mode={mode} />

                {/* Form experience */}
                <section className="relative flex min-h-screen flex-col px-6 py-6 sm:px-10 sm:py-8 lg:px-12 xl:px-20">
                    {/* Mobile brand */}
                    <div className="mb-10 flex items-center justify-between lg:hidden">
                        <Link
                            href="/"
                            aria-label="KARMASS home"
                            className="inline-flex items-center gap-3"
                        >
                            <span className="flex h-9 w-9 items-center justify-center border border-[#30322D] text-sm font-semibold tracking-[-0.08em]">
                                K.
                            </span>

                            <span className="text-base font-semibold tracking-[0.18em]">
                                KARMASS
                            </span>
                        </Link>

                        <span className="text-[9px] font-medium uppercase tracking-[0.18em] text-[#777870]">
                            Find your drive
                        </span>
                    </div>

                    {/* Desktop top navigation */}
                    <div className="hidden items-center justify-end lg:flex">
                        <p className="text-xs text-[#777870]">
                            {isRegister
                                ? "Already a member?"
                                : "New to KARMASS?"}
                        </p>

                        <Link
                            href={isRegister ? "/login" : "/register"}
                            className="ml-2 text-xs font-semibold text-[#6941C6] underline-offset-4 transition hover:text-[#50309B] hover:underline"
                        >
                            {isRegister
                                ? "Sign in"
                                : "Create an account"}
                        </Link>
                    </div>

                    {/* Form area */}
                    <div className="flex flex-1 items-center justify-center py-6 lg:py-12">
                        <div className="w-full max-w-[430px]">
                            <AuthFormHeader mode={mode} />

                            {children}
                        </div>
                    </div>

                    {/* Footer */}
                    <footer className="flex flex-col gap-3 border-t border-[#E5E3DC] pt-5 text-[11px] text-[#898A82] sm:flex-row sm:items-center sm:justify-between">
                        <p>
                            © <CurrentYear /> KARMASS
                        </p>

                        <div className="flex items-center gap-5">
                            <Link
                                href="/privacy"
                                className="transition hover:text-[#6941C6]"
                            >
                                Privacy
                            </Link>

                            <Link
                                href="/terms"
                                className="transition hover:text-[#315C45]"
                            >
                                Terms
                            </Link>
                        </div>
                    </footer>
                </section>
            </div>
        </main>
    );
}