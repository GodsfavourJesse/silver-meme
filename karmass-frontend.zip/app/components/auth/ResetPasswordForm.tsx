"use client";

import { useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import {
    ArrowRight,
    CheckCircle2,
    LoaderCircle,
    ShieldCheck,
} from "lucide-react";

import { authService } from "@/app/services/user/auth/auth.service";
import { PasswordInput } from "@/app/components/auth/PasswordInput";
import { ApiError } from "@/app/lib/api/api-error";

const resetPasswordSchema = z
    .object({
        newPassword: z
            .string()
            .min(8, "Password must contain at least 8 characters")
            .max(128, "Password cannot exceed 128 characters"),

        confirmPassword: z
            .string()
            .min(1, "Please confirm your new password"),
    })
    .refine(
        (values) => values.newPassword === values.confirmPassword,
        {
            message: "Passwords do not match",
            path: ["confirmPassword"],
        },
    );

type ResetPasswordValues = z.infer<typeof resetPasswordSchema>;

export function ResetPasswordForm() {
    const searchParams = useSearchParams();

    const token = searchParams.get("token");

    const [completed, setCompleted] = useState(false);
    const [serverError, setServerError] = useState<string | null>(null);

    const {
        register,
        handleSubmit,
        formState: { errors, isSubmitting },
    } = useForm<ResetPasswordValues>({
        resolver: zodResolver(resetPasswordSchema),
        defaultValues: {
            newPassword: "",
            confirmPassword: "",
        },
    });

    const onSubmit: SubmitHandler<ResetPasswordValues> = async (
        values,
    ) => {
        setServerError(null);

        if (!token) {
            setServerError(
                "This password-reset link is missing its token. Request a new reset link to continue.",
            );
            return;
        }

        try {
            await authService.resetPassword({
                token,
                newPassword: values.newPassword,
            });

            setCompleted(true);
        } catch (error) {
            if (error instanceof ApiError) {
                setServerError(
                    error.message ||
                        "We couldn't reset your password. Your reset link may have expired.",
                );
            } else {
                setServerError(
                    "We couldn't connect to KARMASS. Check your connection and try again.",
                );
            }
        }
    };

    if (completed) {
        return (
            <div className="text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#7008E7]/10">
                    <CheckCircle2
                        size={30}
                        className="text-[#7008E7]"
                    />
                </div>

                <h2 className="mt-6 text-xl font-semibold text-[#292522]">
                    Password updated.
                </h2>

                <p className="mt-3 text-sm leading-6 text-[#858078]">
                    Your password has been changed successfully. You can
                    now sign in using your new password.
                </p>

                <Link
                    href="/login"
                    className="mt-7 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#7008E7] px-5 text-sm font-semibold text-white transition-colors hover:bg-[#5B06BC]"
                >
                    Continue to sign in
                    <ArrowRight size={17} />
                </Link>
            </div>
        );
    }

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            noValidate
            className="space-y-5"
        >
            {!token && (
                <div
                    role="alert"
                    className="border border-amber-200 bg-amber-50 px-4 py-3 text-sm leading-6 text-amber-800"
                >
                    Your reset link is missing its token. Request a new
                    password-reset email to continue.
                    <Link
                        href="/forgot-password"
                        className="ml-1 font-semibold underline underline-offset-4"
                    >
                        Request a new link
                    </Link>
                </div>
            )}

            <div className="space-y-2">
                <PasswordInput
                    {...register("newPassword")}
                    id="newPassword"
                    label="New password"
                    placeholder="Create a new password"
                    autoComplete="new-password"
                    aria-invalid={Boolean(errors.newPassword)}
                    aria-describedby={
                        errors.newPassword ? "new-password-error" : undefined
                    }
                />

                {errors.newPassword && (
                    <p
                        id="new-password-error"
                        role="alert"
                        className="text-xs text-red-600"
                    >
                        {errors.newPassword.message}
                    </p>
                )}

                <p className="text-xs leading-5 text-[#858078]">
                    Use at least 8 characters.
                </p>
            </div>

            <div className="space-y-2">
                <PasswordInput
                    {...register("confirmPassword")}
                    id="confirmPassword"
                    label="Confirm new password"
                    placeholder="Enter your new password again"
                    autoComplete="new-password"
                    aria-invalid={Boolean(errors.confirmPassword)}
                    aria-describedby={
                        errors.confirmPassword
                            ? "confirm-password-error"
                            : undefined
                    }
                />

                {errors.confirmPassword && (
                    <p
                        id="confirm-password-error"
                        role="alert"
                        className="text-xs text-red-600"
                    >
                        {errors.confirmPassword.message}
                    </p>
                )}
            </div>

            {serverError && (
                <div
                    role="alert"
                    className="border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-700"
                >
                    {serverError}
                </div>
            )}

            <button
                type="submit"
                disabled={isSubmitting || !token}
                className="group flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#7008E7] px-5 text-sm font-semibold text-white transition-colors hover:bg-[#5B06BC] disabled:cursor-not-allowed disabled:opacity-60"
            >
                {isSubmitting ? (
                    <>
                        <LoaderCircle size={18} className="animate-spin" />
                        Updating password...
                    </>
                ) : (
                    <>
                        Update password
                        <ArrowRight
                            size={17}
                            className="transition-transform group-hover:translate-x-1"
                        />
                    </>
                )}
            </button>

            <div className="flex items-start gap-2.5 border-t border-[#E9E5DE] pt-4">
                <ShieldCheck
                    size={17}
                    className="mt-0.5 shrink-0 text-[#7008E7]"
                />

                <p className="text-xs leading-5 text-[#858078]">
                    Choose a strong password that you don't use for other
                    accounts.
                </p>
            </div>
        </form>
    );
}