"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import {
    ArrowRight,
    LoaderCircle,
    Mail,
    ShieldCheck,
} from "lucide-react";

import { authService } from "@/app/services/user/auth/auth.service";
import { ApiError } from "@/app/lib/api/api-error";

import { PasswordInput } from "@/app/components/auth/PasswordInput";
import { useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "@/app/lib/query/query-keys";

const loginSchema = z.object({
    email: z
        .string()
        .trim()
        .email("Enter a valid email address"),

    password: z
        .string()
        .min(1, "Enter your password")
        .max(128, "Password cannot exceed 128 characters"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export function LoginForm() {
    const router = useRouter();

    const queryClient = useQueryClient();

    const [serverError, setServerError] = useState<string | null>(null);

    const {
        register,
        handleSubmit,
        setError,
        formState: {
            errors,
            isSubmitting,
        },
    } = useForm<LoginFormValues>({
        resolver: zodResolver(loginSchema),
        defaultValues: {
            email: "",
            password: "",
        },
    });

    const onSubmit: SubmitHandler<LoginFormValues> = async (values) => {
        setServerError(null);

        try {
            await authService.login({
                email: values.email.trim().toLowerCase(),
                password: values.password,
            });

            // Fetch the authenticated user using the new session.
            const currentUser = await queryClient.fetchQuery({
                queryKey: queryKeys.auth.currentUser(),
                queryFn: async () => {
                    const response = await authService.getCurrentUser();
                    return response.data.user;
                },
                staleTime: 0,
            });

            // Do not navigate if the session was not established.
            if (!currentUser) {
                throw new Error(
                    "Login succeeded, but the authenticated user could not be loaded.",
                );
            }

            // The current-user query now contains the authenticated user.
            router.replace("/dashboard");
            router.refresh();
        } catch (error) {
            if (error instanceof ApiError) {
                const message = error.message || "Unable to sign in.";

                if (
                    message.toLowerCase().includes("verif")
                ) {
                    setServerError(
                        "Your email address has not been verified yet. Verify your email before signing in.",
                    );

                    return;
                }

                if (error.status === 401) {
                    setError("password", {
                        type: "server",
                        message: "Your email or password is incorrect.",
                    });

                    return;
                }

                if (error.status === 403) {
                    setServerError(
                        "Your account cannot sign in at the moment. Please check your account status or contact support.",
                    );

                    return;
                }

                setServerError(message);
                return;
            }

            setServerError(
                "We couldn't connect to KARMASS. Check your connection and try again.",
            );
        }
    };

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            noValidate
            className="space-y-6"
        >
            {/* Server error */}
            {serverError && (
                <div
                    role="alert"
                    className="
                        rounded-xl border border-red-200
                        bg-red-50 px-4 py-3
                        text-sm leading-6 text-red-700
                    "
                >
                    <p>{serverError}</p>

                    {serverError.toLowerCase().includes("verify") && (
                        <Link
                            href="/verify-email"
                            className="
                                mt-2 inline-flex items-center
                                gap-1 font-semibold
                                underline underline-offset-4
                            "
                        >
                            Verify your email
                            <ArrowRight size={14} />
                        </Link>
                    )}
                </div>
            )}

            {/* Email */}
            <div className="space-y-2">
                <label
                    htmlFor="email"
                    className="block text-sm font-medium text-[#292522]"
                >
                    Email address
                    <span className="ml-1 text-[#7008E7]">*</span>
                </label>

                <div
                    className={`
                        group flex h-12 items-center gap-3
                        rounded-xl border bg-white px-3.5
                        transition-all duration-200
                        focus-within:border-[#7008E7]
                        focus-within:ring-2
                        focus-within:ring-[#7008E7]/10
                        ${
                            errors.email
                                ? "border-red-400"
                                : "border-[#E5E1DA]"
                        }
                    `}
                >
                    <Mail
                        size={17}
                        strokeWidth={1.7}
                        className="shrink-0 text-[#96918B]"
                        aria-hidden="true"
                    />

                    <input
                        {...register("email")}
                        id="email"
                        type="email"
                        autoComplete="email"
                        placeholder="you@example.com"
                        aria-invalid={Boolean(errors.email)}
                        aria-describedby={
                            errors.email ? "email-error" : undefined
                        }
                        className="
                            h-full min-w-0 flex-1
                            bg-transparent text-sm
                            text-[#292522] outline-none
                            placeholder:text-[#A6A099]
                        "
                    />
                </div>

                {errors.email && (
                    <p
                        id="email-error"
                        className="text-xs text-red-600"
                    >
                        {errors.email.message}
                    </p>
                )}
            </div>

            {/* Password */}
            <div className="space-y-2">
                <div className="flex items-center justify-between gap-3">
                    <label
                        htmlFor="password"
                        className="text-sm font-medium text-[#292522]"
                    >
                        Password
                        <span className="ml-1 text-[#7008E7]">*</span>
                    </label>

                    <Link
                        href="/forgot-password"
                        className="
                            text-xs font-semibold
                            text-[#7008E7] transition-colors
                            hover:text-[#5B06BC]
                        "
                    >
                        Forgot password?
                    </Link>
                </div>

                <PasswordInput
                    {...register("password")}
                    id="password"
                    label=""
                    placeholder="Enter your password"
                    autoComplete="current-password"
                    aria-invalid={Boolean(errors.password)}
                    aria-describedby={
                        errors.password ? "password-error" : undefined
                    }
                />

                {errors.password && (
                    <p
                        id="password-error"
                        className="text-xs text-red-600"
                    >
                        {errors.password.message}
                    </p>
                )}
            </div>

            {/* Submit */}
            <button
                type="submit"
                disabled={isSubmitting}
                className="
                    group flex h-13 w-full items-center
                    justify-center gap-2.5 rounded-xl
                    bg-[#7008E7] px-5 py-3.5
                    text-sm font-semibold text-white
                    shadow-[0_8px_20px_rgba(112,8,231,0.16)]
                    transition-all duration-200
                    hover:bg-[#5B06BC]
                    hover:shadow-[0_10px_25px_rgba(112,8,231,0.24)]
                    focus-visible:outline-none
                    focus-visible:ring-2
                    focus-visible:ring-[#7008E7]
                    focus-visible:ring-offset-2
                    disabled:cursor-not-allowed
                    disabled:opacity-60
                "
            >
                {isSubmitting ? (
                    <>
                        <LoaderCircle
                            size={18}
                            className="animate-spin"
                        />
                        Signing you in...
                    </>
                ) : (
                    <>
                        Sign in to KARMASS
                        <ArrowRight
                            size={17}
                            className="transition-transform group-hover:translate-x-1"
                        />
                    </>
                )}
            </button>

            {/* Security reassurance */}
            <div className="flex items-start gap-2.5 pt-1">
                <ShieldCheck
                    size={17}
                    strokeWidth={1.7}
                    className="mt-0.5 shrink-0 text-[#7008E7]"
                />

                <p className="text-xs leading-5 text-[#858078]">
                    Your account is protected by KARMASS security.
                    Never share your password with anyone.
                </p>
            </div>
        </form>
    );
}