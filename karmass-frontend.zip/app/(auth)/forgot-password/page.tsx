"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import {
    ArrowLeft,
    CheckCircle2,
    Mail,
    ShieldCheck,
} from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import {
    useForm,
    type SubmitHandler,
} from "react-hook-form";
import { z } from "zod";

import { ApiError } from "@/app/lib/api/api-error";
import { authService } from "@/app/services/user/auth/auth.service";
import { AuthLayout } from "@/app/components/userComponents/auth/AuthLayout";
import { AuthAlert } from "@/app/components/userComponents/auth/AuthAlert";

const forgotPasswordSchema = z.object({
    email: z
        .string()
        .trim()
        .email("Enter a valid email address.")
        .max(254, "Email address is too long."),
});

type ForgotPasswordFormValues = z.infer<
    typeof forgotPasswordSchema
>;

export default function ForgotPasswordPage() {
    const [submitted, setSubmitted] = useState(false);
    const [requestError, setRequestError] = useState("");

    const {
        register,
        handleSubmit,
        formState: {
            errors,
            isSubmitting,
        },
    } = useForm<ForgotPasswordFormValues>({
        resolver: zodResolver(forgotPasswordSchema),
        defaultValues: {
            email: "",
        },
    });

    const onSubmit: SubmitHandler<
        ForgotPasswordFormValues
    > = async (values) => {
        setRequestError("");

        try {
            await authService.forgotPassword({
                email: values.email.trim().toLowerCase(),
            });

            setSubmitted(true);
        } catch (error) {
            if (
                error instanceof ApiError &&
                error.status === 429
            ) {
                setRequestError(
                    "Too many requests. Please wait a little while before trying again.",
                );

                return;
            }

            setRequestError(
                "We couldn't process your request right now. Please try again.",
            );
        }
    };

    return (
        <AuthLayout
            title={
                submitted
                    ? "Check your inbox"
                    : "Forgot your password?"
            }
            description={
                submitted
                    ? "If an account exists for that email address, you'll receive instructions to reset your password."
                    : "It happens. Enter the email address associated with your KARMASS account and we'll help you get back in."
            }
            footerText="Remember your password?"
            footerLinkText="Log in"
            footerHref="/login"
        >
            {submitted ? (
                <div className="space-y-6">
                    <div className="flex flex-col items-center rounded-2xl border border-kar-border bg-kar-surface p-7 text-center">
                        <div className="mb-4 flex size-14 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-500">
                            <CheckCircle2
                                size={30}
                                aria-hidden="true"
                            />
                        </div>

                        <h2 className="text-lg font-semibold text-kar-text">
                            Request received
                        </h2>

                        <p className="mt-2 max-w-sm text-sm leading-6 text-kar-muted">
                            Check your inbox and spam folder
                            for further instructions. For your
                            security, we don&apos;t reveal whether
                            an email address is registered.
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={() => {
                            setSubmitted(false);
                            setRequestError("");
                        }}
                        className="w-full rounded-xl border border-kar-border bg-kar-surface px-4 py-3.5 text-sm font-semibold text-kar-text transition hover:border-kar-accent/40 hover:bg-kar-accent/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-kar-accent/30"
                    >
                        Try another email address
                    </button>

                    <Link
                        href="/login"
                        className="flex items-center justify-center gap-2 text-sm font-semibold text-kar-accent transition hover:opacity-80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-kar-accent/30"
                    >
                        <ArrowLeft
                            size={16}
                            aria-hidden="true"
                        />

                        Return to login
                    </Link>
                </div>
            ) : (
                <form
                    onSubmit={handleSubmit(onSubmit)}
                    className="space-y-5"
                    noValidate
                >
                    {requestError ? (
                        <AuthAlert
                            variant="error"
                            message={requestError}
                        />
                    ) : null}

                    <div>
                        <label
                            htmlFor="email"
                            className="mb-2 block text-sm font-semibold text-kar-text"
                        >
                            Email address
                        </label>

                        <div className="group relative">
                            <Mail
                                size={18}
                                aria-hidden="true"
                                className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-kar-muted transition-colors group-focus-within:text-kar-accent"
                            />

                            <input
                                id="email"
                                type="email"
                                autoComplete="email"
                                autoCapitalize="none"
                                autoCorrect="off"
                                spellCheck={false}
                                inputMode="email"
                                placeholder="you@example.com"
                                aria-invalid={Boolean(errors.email)}
                                aria-describedby={
                                    errors.email
                                        ? "email-error"
                                        : undefined
                                }
                                {...register("email")}
                                className={[
                                    "w-full rounded-xl border bg-kar-surface py-3.5 pl-11 pr-4",
                                    "text-sm text-kar-text outline-none transition",
                                    "placeholder:text-kar-muted/70",
                                    "focus:border-kar-accent focus:ring-4 focus:ring-kar-accent/10",
                                    errors.email
                                        ? "border-red-400 focus:border-red-500 focus:ring-red-500/10"
                                        : "border-kar-border",
                                ].join(" ")}
                            />
                        </div>

                        {errors.email ? (
                            <p
                                id="email-error"
                                role="alert"
                                className="mt-2 text-sm text-red-500"
                            >
                                {errors.email.message}
                            </p>
                        ) : null}
                    </div>

                    <button
                        type="submit"
                        disabled={isSubmitting}
                        className={[
                            "flex min-h-12 w-full items-center justify-center gap-2",
                            "rounded-xl bg-gradient-to-r from-violet-700 to-purple-800",
                            "px-4 py-3.5 text-sm font-semibold text-white",
                            "shadow-lg shadow-purple-900/15 transition",
                            "hover:-translate-y-0.5 hover:shadow-xl",
                            "focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-kar-accent/25",
                            "active:translate-y-0",
                            "disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:translate-y-0",
                        ].join(" ")}
                    >
                        {isSubmitting ? (
                            <>
                                <span
                                    aria-hidden="true"
                                    className="size-4 animate-spin rounded-full border-2 border-white/40 border-t-white"
                                />

                                Sending request...
                            </>
                        ) : (
                            <>
                                <Mail
                                    size={17}
                                    aria-hidden="true"
                                />

                                Send reset instructions
                            </>
                        )}
                    </button>

                    <div className="flex items-start gap-3 rounded-xl border border-purple-100 bg-purple-50/60 p-4">
                        <ShieldCheck
                            size={20}
                            aria-hidden="true"
                            className="mt-0.5 shrink-0 text-kar-accent"
                        />

                        <p className="text-xs leading-5 text-kar-muted">
                            Your account security matters.
                            Password-reset requests are handled
                            securely, and your existing password
                            is never displayed or sent back to you.
                        </p>
                    </div>

                    <Link
                        href="/login"
                        className="flex items-center justify-center gap-2 py-1 text-sm font-semibold text-kar-muted transition hover:text-kar-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-kar-accent/30"
                    >
                        <ArrowLeft
                            size={16}
                            aria-hidden="true"
                        />

                        Back to login
                    </Link>
                </form>
            )}
        </AuthLayout>
    );
}