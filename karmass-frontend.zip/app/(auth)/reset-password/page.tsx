import { Suspense } from "react";

import { AuthRecoveryLayout } from "@/app/components/auth/AuthRecoveryLayout";
import { ResetPasswordForm } from "@/app/components/auth/ResetPasswordForm";

function ResetPasswordLoading() {
    return (
        <div className="flex min-h-48 items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-[#7008E7]/20 border-t-[#7008E7]" />
        </div>
    );
}

export default function ResetPasswordPage() {
    return (
        <AuthRecoveryLayout
            eyebrow="Account security"
            title="Create a new password."
            description="Choose a new password for your KARMASS account. Your new password will replace the old one."
        >
            <Suspense fallback={<ResetPasswordLoading />}>
                <ResetPasswordForm />
            </Suspense>
        </AuthRecoveryLayout>
    );
}