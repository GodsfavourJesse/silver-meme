import type { Metadata } from "next";
import { Outfit } from "next/font/google";
import { KarmassAdminLogo } from "@/app/utils/adminUtils/karmass-admin-logo";
import { AdminLoginForm } from "@/app/components/adminComponents/admin-login-form";
import { CurrentYear } from "@/app/components/auth/CurrentYear";

const outfit = Outfit({
    subsets: ["latin"],
    display: "swap",
});

export const metadata: Metadata = {
    title: "Administrator sign in | KARMASS",
    robots: {
        index: false,
        follow: false,
    },
};

export default function AdminLoginPage() {
    return (
        <main
            className={`${outfit.className} relative flex min-h-screen items-center justify-center overflow-hidden bg-kar-bg px-5 py-12 text-kar-text`}
        >
            {/* Royal glow */}
            <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-[radial-gradient(55%_45%_at_50%_0%,rgba(107,63,217,0.35),transparent),radial-gradient(40%_35%_at_85%_100%,rgba(169,140,255,0.14),transparent)]"
            />

            <div className="relative z-10 flex w-full max-w-md flex-col items-center gap-8">
                <KarmassAdminLogo />

                <AdminLoginForm />

                <p className="text-center text-xs leading-5 text-kar-muted/70">
                    © <CurrentYear /> KARMASS. Authorized personnel
                    only. Unauthorized access is prohibited.
                </p>
            </div>
        </main>
    );
}