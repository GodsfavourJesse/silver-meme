import { DashboardView } from "@/app/components/adminComponents/dashboard-view";

export default function AdminDashboardPage() {
    return <DashboardView />;
}